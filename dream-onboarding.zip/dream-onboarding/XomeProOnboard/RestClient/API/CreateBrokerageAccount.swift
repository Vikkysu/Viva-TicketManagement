//
//  CreateBrokerageAccount.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/21/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class createBrokerageAccount {
    typealias Callback = (JSON, NSError?) -> ()
    
    
    func getParams()->[String:AnyObject]? {
        
        let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
        
        /* get all the neccessary field values */
        let brokerObj: DPBrokeragePersonalInfoObj? = brokerOnboardingInfo.loadBrokerageCustomObjectWithKey()
        let brokerEmailObj: DPBrokerageEmailObj? = brokerOnboardingInfo.loadCustomObjectWithKey()
        let brokerLicenseObj: DPBrokerageLicenseInfo? = brokerOnboardingInfo.loadBrokerageLicenseCustomObjectWithKey()
        let brokerDict: DPBrokerageLicenseObj = brokerLicenseObj?.brokerLicenseArr[0] as! DPBrokerageLicenseObj

        let brokerMLSObj: DPBrokerageMLSInfo? = brokerOnboardingInfo.loadBrokerageMLSCustomObjectWithKey()
        let brokerMLSDict: DPBrokerageMLSObj = brokerMLSObj?.brokerMLSInfoArr[0] as! DPBrokerageMLSObj
        var websiteAdd: String? = ""
        if let brokerBrandingWebsiteInfo: DPBrandingWebsiteAddrObj = brokerOnboardingInfo.loadBrokerageBrandingWebsiteObjectWithKey() {
            websiteAdd = brokerBrandingWebsiteInfo.websiteAddressStr
        }
        
        var primaryColor: String = UIColor.toHexString(UIColor.baoPrimaryColor())

        if let brokerColorInfoObj: DPBrandingColorObj = brokerOnboardingInfo.loadBrokerageBrandingColorObjectWithKey() {
            primaryColor = brokerColorInfoObj.bioPrimaryColor!
        }
        let brokerPersonalInfoInfo: DPBrandingBioObj = brokerOnboardingInfo.loadBrokerageBrandingBioObjectWithKey()!

        let officeAddress = [
            "StreetNumber": " ",
            "StreetDirPrefix": "",
            "StreetName": " ",
            "StreetAdditionalInfo": "",
            "StreetDirSuffix": "",
            "StreetSuffix": " ",
            "UnitNumber": " ",
            "Unstructured": brokerObj?.brokerageAddress as! AnyObject,
            "City": brokerObj?.brokerageCity as! AnyObject,
            "StateOrProvince": brokerObj?.brokerageState as! AnyObject,
            "Country": "USA",
            "PostalCode": brokerObj?.brokerageZipcode as! AnyObject
        ]

        let OfficePhone = [ [
                "Phone": [
                    "PhoneType": "MainOffice",
                    "PhoneNumber": brokerObj?.brokeragePhone as! AnyObject,
                    "Extension": "",
                    "Preferred": true
                ]
            ]
        ]
        
        let webSiteInfo = [
            "Name": "Louie Rowlett Website",
            "ProfessionalProfile": brokerPersonalInfoInfo.bioStr as! AnyObject,
            "PrimaryColor": primaryColor as AnyObject,
            "Urls": [websiteAdd as! AnyObject]
        ]
        
        // format the MLS into array
//        let mlsArray: NSMutableArray = []
//        var count = 0
//        for (count; count < brokerMLSObj?.brokerMLSInfoArr.count; count++ )  {
//            let brokerMLSDict: DPBrokerageMLSObj = brokerMLSObj?.brokerMLSInfoArr[count] as! DPBrokerageMLSObj
//            let MLSObj = [
//                "ListingSource": brokerMLSDict.brokerageMLSName,
//                "MemberID": brokerMLSDict.brokerageMLSID
//                ]
//            let MLSInfoObj = ["MLSCode": MLSObj]
//            mlsArray.addObject(MLSInfoObj)
//        }
        
        let mlsCodesOffice = [
            [
                "MLSCode": [
                    "ListingSource": brokerMLSDict.brokerageMLSName,
                    "MemberID": brokerMLSDict.brokerageMLSID
                ]
            ]
        ]
        
        let emailOffice = [
            "EmailType": "Primary",
            "EmailAddress": brokerEmailObj?.emailStr as! AnyObject
        ]
        
        let office = [
            "OfficeName": brokerObj?.brokerageName as! AnyObject,
            "IsAllianceOffice": false,
            "OfficeAddress": officeAddress,
            "Phones": OfficePhone as AnyObject,
            "Email": emailOffice as AnyObject,
            "MLSCodes": mlsCodesOffice as AnyObject,
            "Website": webSiteInfo as AnyObject
        ]
        
        let brokerPerObj: DPBrokerProfileObj? = brokerOnboardingInfo.loadBrokerProfileObjectWithKey()

        let brokerPassObj: DPBrokerageEmailObj? = brokerOnboardingInfo.loadCustomObjectWithKey()
        
        let brokerPMLSObj: DPBrokerMLSInfo? = brokerOnboardingInfo.loadBrokerMLSCustomObjectWithKey()
        let brokerPMLSDict: DPBrokerageMLSObj = brokerPMLSObj?.brokerMLSInfoArr[0] as! DPBrokerageMLSObj
        //let brokerBrandingWebsiteInfo: DPBrandingWebsiteYoutubeAddrObj = brokerOnboardingInfo.loadBrokerageBrandingWebsiteYoutubeObjectWithKey()!
        
        let brokerPLicenseObj: DPBrokerLicenseInfo? = brokerOnboardingInfo.loadBrokerLicenseCustomObjectWithKey()
        let brokerPDict: DPBrokerageLicenseObj = brokerPLicenseObj?.brokerLicenseArr[0] as! DPBrokerageLicenseObj

        
        let phoneBrokers = [
            "PhoneType": "DirectOffice",
            "PhoneNumber": brokerPerObj?.phonenoStr as! AnyObject,
            "Extension": "",
            "Preferred": true
        ]
        
        let phoneDet = [
            [
                "Phone": phoneBrokers
            ]
        ]
        
        //let urls = [ brokerBrandingWebsiteInfo.websiteAddressStr as! AnyObject]
        
        let webSiteBroker = [
            "Name": "Louie Rowlett Website",
            "ProfessionalProfile": "",
            "PrimaryColor": "RED",
            "Urls": ["http://www.lardkingrealty.com/"]
        ]
        
        let brokerEmails = [
            [
                "Email": [
                    "EmailType": "Primary",
                    "EmailAddress": brokerPerObj?.emailStr as! AnyObject
                ]
            ]
        ]
        
        let mlsBrokerCodes = [
            [
                "MLSCode": [
                    "ListingSource": brokerPMLSDict.brokerageMLSName,
                    "MemberID": brokerPMLSDict.brokerageMLSID
                ]
            ]
        ]
        
        let brokerLicenses = [
            [
                "StateCode": brokerPDict.brokerageLicenseState,
                "LicenseNumber": brokerPDict.brokerageLicenseNumber
            ]
        ]
        
        let broker = [
            "FirstName": brokerPerObj?.firstNameStr as! AnyObject,
            "LastName": brokerPerObj?.lastNameStr as! AnyObject,
            "AgentCode": "LOU" as AnyObject,
            "Emails": brokerEmails,
            "Login": brokerPassObj?.emailStr as! AnyObject,
            "Password": brokerPassObj?.passwordStr as! AnyObject,
            "OfficeAddress": officeAddress,
            "Phones": phoneDet as AnyObject,
            "MLSCodes": mlsBrokerCodes as AnyObject,
            "LicensedInStates": "WA" as AnyObject,
            "YearsOfExperience": "10" as AnyObject,
            "Website": webSiteBroker as AnyObject,
            "Licenses": brokerLicenses as AnyObject
        ]
        
        let parsm = ["Office": office, "Broker": broker]
        return parsm
    }
    
    
    func createBroker(cb: Callback) {
        let parsm: [ String : AnyObject] = getParams()!
        
        let request1 = NSMutableURLRequest(URL: NSURL(string:"\(stageDomain)Brokerage")!)
        request1.HTTPMethod = "POST"
        request1.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request1.setValue("application/json", forHTTPHeaderField: "Accept")
        request1.setValue("00000000-0000-0000-0000-000000001111", forHTTPHeaderField: "x-xome-dream-invitation-code")
        request1.setValue(apiKey, forHTTPHeaderField: "X-RED-APIKey")
        
        request1.HTTPBody = try! NSJSONSerialization.dataWithJSONObject(parsm, options: [])

        
        Alamofire.request(request1)
            .responseJSON { response in
                print(response.request)  // original URL request
                print(response.response) // URL response
                print(response.data)     // server data
                print(response.result)   // result of response serialization
                
                if let httpResponse = response.response {
                    print("error \(httpResponse.statusCode)")
                    if httpResponse.statusCode > 199 && httpResponse.statusCode < 300 {
                        if let JSON1 = response.result.value {
                            print("JSON: \(JSON1)")
                            let json = JSON(JSON1)
                            cb(json, nil)
                        }
                    }
                    else {
                        //let messageStr = NSString(data: response.data, encoding: UInt)
                        
                        let alertView : UIAlertView = UIAlertView(title: "Error!!!", message:response.description , delegate: nil, cancelButtonTitle: "Ok")
                        alertView.show()
                        cb(nil, response.result.error)
                    }
                }
        }
    }
}
