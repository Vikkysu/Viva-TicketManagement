//
//  PropertyDetailsModel.swift
//  XomeRestClient
//
//  Created by David Parton on 1/19/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class PropertyDetailsModel: PropertyModel {
    public var propertyDescription: String?
    public var agentFirstName: String?
    public var disclaimer: String?
    public var mortgageCalculatorURL: NSURL?
    public var info: [PropertyDetailsInfoModel] = []
    public var listingId: String?
    public var aor: String?

    required public init?(_ map: Map) {
        super.init(map)
    }

    override public func mapping(map: Map) {
        super.mapping(map)

        propertyDescription <- map["publicRemarks"]
        agentFirstName <- map["listAgentFirstName"]
        disclaimer <- map["idxDisclaimer"]
        mortgageCalculatorURL <- (map["mortgageCalculatorUrl"], URLTransform())
        info <- (map["fieldData.items"], PropertyDetailsInfoTransform())
        aor <- map["listAor"]
        listingId <- map["listingId"]
    }

    // MARK: Computed properties
    public var listingInfo: PropertyDetailsListingInfoModel? {
        return info.flatMap { $0 as? PropertyDetailsListingInfoModel }.first
    }

    public var roomInfo: PropertyDetailsRoomInfoModel? {
        return info.flatMap { $0 as? PropertyDetailsRoomInfoModel }.first
    }

    public var interiorInfo: PropertyDetailsInteriorInfoModel? {
        return info.flatMap{ $0 as? PropertyDetailsInteriorInfoModel }.first
    }

    public var exteriorInfo: PropertyDetailsExteriorInfoModel? {
        return info.flatMap { $0 as? PropertyDetailsExteriorInfoModel }.first
    }

    public var schoolInfo: PropertyDetailsSchoolInfoModel? {
        return info.flatMap { $0 as? PropertyDetailsSchoolInfoModel }.first
    }

    public var financeInfo: PropertyDetailsFinanceInfoModel? {
        return info.flatMap { $0 as? PropertyDetailsFinanceInfoModel }.first
    }

    public var communityInfo: PropertyDetailsCommunityInfoModel? {
        return info.flatMap { $0 as? PropertyDetailsCommunityInfoModel }.first
    }
}
