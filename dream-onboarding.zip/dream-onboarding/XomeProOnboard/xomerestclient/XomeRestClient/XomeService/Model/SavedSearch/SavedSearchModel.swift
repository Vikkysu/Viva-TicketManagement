//
//  SavedSearchModel.swift
//  XomeRestClient
//
//  Created by Xome on 2/2/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class SavedSearchModel: Mappable {
    public var name: String?
    public var description: String?
    public var doCcAgent: Bool?
    public var savedSearchesKey: String?
    public var originatedByAgent: Bool?
    public var sendEmailMileStoneFlags: NSArray?
    public var createdDateTime: String?
    public var lastModifiedTime: String?
    public var id: String?
    public var newListingsSinceLastRun: Int?
    public var criteriaDetails: SavedSearchCriteriaModel?

    required public init?(_ map: Map) {

    }

    public func mapping(map: Map) {
        name <- map["name"]
        description <- map["description"]
        doCcAgent <- map["doCcAgent"]
        savedSearchesKey <- map["savedSearchKey"]
        originatedByAgent <- map["originatedByAgent"]
        sendEmailMileStoneFlags <- map["sendEmailMileStoneFlags"]
        createdDateTime <- map["createdDtm"]
        lastModifiedTime <- map["modifiedDtm"]
        newListingsSinceLastRun <- map["newListingsSinceLastRun"]
        id <- map["id"]
        criteriaDetails <- map["criteria"]
    }
}