//
//  CreateAgentAccount.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/26/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class createAgentAccount {
    typealias Callback = (JSON, NSError?) -> ()
    
    
    func getParams()->[String:AnyObject]? {
        
        let agentOnboardingInfo: DPAgentOnBoardingModel = DPAgentOnBoardingModel.sharedInstance
        
        /* get all the neccessary field values */
        let brokerPerObj: DPBrokerProfileObj? = agentOnboardingInfo.loadBrokerProfileObjectWithKey()
        
        let brokerPMLSObj: DPBrokerMLSInfo? = agentOnboardingInfo.loadBrokerMLSCustomObjectWithKey()
        let brokerPMLSDict: DPBrokerageMLSObj = brokerPMLSObj?.brokerMLSInfoArr[0] as! DPBrokerageMLSObj
        let agentWebsiteInfo: DPBrandingWebsiteYoutubeAddrObj = agentOnboardingInfo.loadBrokerageBrandingWebsiteYoutubeObjectWithKey()!
        let brokerPLicenseObj: DPBrokerLicenseInfo? = agentOnboardingInfo.loadBrokerLicenseCustomObjectWithKey()
        let brokerPDict: DPBrokerageLicenseObj = brokerPLicenseObj?.brokerLicenseArr[0] as! DPBrokerageLicenseObj
        
        
        let phoneBrokers = [
            "PhoneType": "DirectOffice",
            "PhoneNumber": brokerPerObj?.phonenoStr as! AnyObject,
            "Extension": "",
            "Preferred": true
        ]
        
        let phoneDet = [
            [
                "Phone": phoneBrokers
            ]
        ]
        
        //let urls = [ brokerBrandingWebsiteInfo.websiteAddressStr as! AnyObject]
        
        let webSiteBroker = [
            "Name": "Louie Rowlett Website",
            "ProfessionalProfile": "",
            "PrimaryColor": "RED",
            "Urls": [agentWebsiteInfo.websiteAddressStr as! AnyObject, agentWebsiteInfo.YoutubeStr as! AnyObject]
        ]
        
        let brokerEmails = [
            [
                "Email": [
                    "EmailType": "Primary",
                    "EmailAddress": brokerPerObj?.emailStr as! AnyObject
                ]
            ]
        ]
        
        let mlsBrokerCodes = [
            [
                "MLSCode": [
                    "ListingSource": brokerPMLSDict.brokerageMLSName,
                    "MemberID": brokerPMLSDict.brokerageMLSID
                ]
            ]
        ]
        
        let brokerLicenses = [
            [
                "StateCode": brokerPDict.brokerageLicenseState,
                "LicenseNumber": brokerPDict.brokerageLicenseNumber
            ]
        ]
        
        
        let officeInfo = [
            "StreetNumber": "string",
            "StreetDirPrefix": "string",
            "StreetName": "string",
            "StreetAdditionalInfo": "string",
            "StreetDirSuffix": "string",
            "StreetSuffix": "string",
            "UnitNumber": "string",
            "Unstructured": "string",
            "City": "string",
            "StateOrProvince": "string",
            "Country": "string",
            "PostalCode": "string"
        ]
        
            let agentCreation =
                [
                    "FirstName": brokerPerObj?.firstNameStr as! AnyObject,
                    "LastName": brokerPerObj?.lastNameStr as! AnyObject,
                    "MarketingName": "string",
                    "Title": "string",
                    "Login": brokerPerObj?.emailStr as! AnyObject,
                    "Password": brokerPerObj?.password as! AnyObject,
                    "AgentCode": "string",
                    "IsListed": true,
                    "OfficeAddress":officeInfo,
                    "Phones": phoneDet,
                    "Emails": brokerEmails,
                    "MLSCodes": mlsBrokerCodes,
                    "Website": webSiteBroker,
                    "Licenses": brokerLicenses,
            ]
        
        let parsm = ["Agent": agentCreation]
        return parsm
    }
    
    
    func createAgent(cb: Callback) {
        let parsm: [ String : AnyObject] = getParams()!
        
        let loginToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzY2hlbWFWZXJzaW9uIjoiMS4xIiwiSUQiOiJjbWFya3Vzb24iLCJub25jZSI6ImQ1MzIzMzAyMGU5YjcwMDQ1MDg3NGFiNmMzOGQ3NTI4ODRhZDY0NmYwY2ZiNDU2MDAyZGRiZjExMGU0YThiNjg4NWEwM2ExOTI1NjAwMGZiNjgzNTJkMzk3MDVhY2UzODE2YjY3MDlkZGQyOWU3MjU0Y2MzNDM0MTg4YzNjNjg1IiwiZXhwIjoxNDQ1OTgzNzE2LCJ1c2VySWQiOiJmNDE3MDEwNi0zZTcwLTRmZTQtODZmYS04NjVkMTE3ZWY4N2MiLCJ1c2VyVHlwZSI6IkFnZW50IiwidGVuYW50IjoiYWJjcmVhbHR5Iiwic2VydmljZUNsYWltcyI6W10sImlhdCI6MTQ0NTk4MDExN30.suQ33gEMHq0Q-CsZ7JwDkfsVXE3QgUmKUWCU8RQyeNRwynr4nrKg5bXm8oFuyar3jcm_5RUh9MOYTWXrqTPsRxXpnih0O3sefbOMyN6Hl1sbqZ_16UCSow6PtodRuRk4flesh5aPu3WgHuTJJtMx_pdEV8YMv3hco2HRmEGF54O2LbwNAZpAyNqYB9XgbuuolCbIavnQLuTC11Q9jORB4hJdhUaPmljr-cRt1QoUYSnt0OobJmJsqqfrDHCiIWf6xfMG_yQvK9TQl84vq08WnaiWoF7MRNgdteXfOh7Pm6rMfXbVuyLQrgooC--SXuYICehW5nzwdLPaU5r-hh-6rA"
        
        //POST /api/v1/Brokerage/{id}/Agents/
        let request1 = NSMutableURLRequest(URL: NSURL(string:"\(stageDomain)Brokerage/Agents/")!)
        request1.HTTPMethod = "PUT"
        request1.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request1.setValue("application/json", forHTTPHeaderField: "Accept")
        request1.setValue(loginToken, forHTTPHeaderField: "x-xome-dream-invitation-code")
        request1.setValue(apiKey, forHTTPHeaderField: "X-RED-APIKey")
        
        request1.HTTPBody = try! NSJSONSerialization.dataWithJSONObject(parsm, options: [])
        
        
        Alamofire.request(request1)
            .responseJSON { response in
                print(response.request)  // original URL request
                print(response.response) // URL response
                print(response.data)     // server data
                print(response.result)   // result of response serialization
                
                if let httpResponse = response.response {
                    print("error \(httpResponse.statusCode)")
                    if httpResponse.statusCode > 199 && httpResponse.statusCode < 300 {
                        if let JSON1 = response.result.value {
                            print("JSON: \(JSON1)")
                            let json = JSON(JSON1)
                            cb(json, nil)
                        }
                    }
                    else {
                        //let messageStr = NSString(data: response.data, encoding: UInt)
                        
                        let alertView : UIAlertView = UIAlertView(title: "Error!!!", message:response.description , delegate: nil, cancelButtonTitle: "Ok")
                        alertView.show()
                        cb(nil, response.result.error)
                    }
                }
        }
    }
}
