//
//  ACBrokarageStep3ViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 9/29/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

public enum flowState {
    case BROKERAGE, MANAGEBROKER, EDITFLOW
}

public enum flowStateInvite {
    case IAGENT, ICLIENT
}

class ACBrokarageStep3ViewController: DPAccountCreationBaseViewController {
    
    var eState: flowState = .BROKERAGE
    
    override func nextViewC1(sender: UIBarButtonItem) {
        //setDataFields
        let accountViewCntrl = self.childViewControllers[0] as! ACBrokerStep3TableViewController
        if accountViewCntrl.setDataFields() == true {
        let nextViewController: ACBrokarageStep4ViewController = ACBrokarageStep4ViewController()
            nextViewController.eState = eState
        self.navigationItem.backBarButtonItem?.title = " "
        self.navigationController?.pushViewController(nextViewController, animated: true)
        }
    }
    
    func geteState()->flowState {
        return eState
    }
   
    func changeeState(lState : flowState) {
         eState = lState
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
                
        self.navigationItem.title = "Create an Account"

        self.view.backgroundColor = UIColor.lightGrayColor()

        let tablecontr: ACBrokerStep3TableViewController = ACBrokerStep3TableViewController()
        self.addChildViewController(tablecontr)
        self.view.addSubview(tablecontr.view)
        tablecontr.didMoveToParentViewController(self)
        
        tablecontr.view.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self.view).offset(138)
            make.leading.equalTo(self.view).offset(5)
            make.trailing.equalTo(self.view).offset(-5)
            make.bottom.equalTo(self.view).offset(-5)
        }
        
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            self.setStepIndication(tagStep1, state: 5)
            self.setStepIndication(tagStep2, state: 3)
            return
        }
        
        if eState == .BROKERAGE {
            self.setStepIndication(tagStep1, state: 3)
        }
        else {
            self.setStepIndication(tagStep1, state: 5)
            self.setStepIndication(tagStep2, state: 5)
            self.setStepIndication(tagStep3, state: 2)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
        /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
