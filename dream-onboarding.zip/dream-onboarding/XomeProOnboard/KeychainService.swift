//
//  Keychain.swift
//  ProfessionalTools
//
//  Created by Thomas De Leon on 10/21/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import Security

public class KeychainService {

    /** KeychainService errors */
    public enum KeychainError:ErrorType {
        case FailedToSave(code:OSStatus)
        case FailedToLoad(code:OSStatus)
        case ItemNotFound
        case FailedToDelete(code:OSStatus)
        case FailedToClear(code:OSStatus)
    }
    
    /**
    Save a new key in the Keychain

    - parameter key: The key to save
    - parameter data: The data to save for the key
    - throws: `OSStatus` from SecItemAdd() for anything other than `erSecSuccess`
    */
    public static func save(key:String, data:NSData) throws {
        // create a query
        let query = [
            kSecClass as String : kSecClassGenericPassword as String,
            kSecAttrAccount as String : key,
            kSecValueData as String : data]
        
        // if there was an existing item, delete it
        SecItemDelete(query as CFDictionaryRef)
        
        // add the new item
        let status = SecItemAdd(query as CFDictionaryRef, nil)
        
        guard status == errSecSuccess else {
            throw KeychainError.FailedToSave(code: status)
        }
    }
    
    /**
    Load an item from the Keychain
    
    - parameter key: The key of the item to load
    - returns: The item if found
    - throws: `OSStatus` value from SecItemCopyMatching(), including if the key is not found
    */
    public static func load(key:String)throws ->NSData {
        // create a query
        let query = [
            kSecClass as String : kSecClassGenericPassword as String,
            kSecAttrAccount as String : key,
            kSecReturnData as String : kCFBooleanTrue,
            kSecMatchLimit as String : kSecMatchLimitOne]
        
        // run the query
        var rawResult :AnyObject?
        
        let status = SecItemCopyMatching(query, &rawResult)
        
        // if anything other than noErr, handle the error
        guard status == noErr else {
            if status == errSecItemNotFound {
                throw KeychainError.ItemNotFound
            }
            else {
                throw KeychainError.FailedToLoad(code: status)
            }
        }
        
        return rawResult as! NSData
    }
    
    /**
    Delete an item from the Keychain
    
    - parameter key: The item to delete
    - throws: `OSStatus` value from SecItemDelete(), for anything other than `noErr`
    */
    public static func delete(key:String) throws {
        // create a query
        let query = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: key]
        
        // delete
        let status = SecItemDelete(query as CFDictionaryRef)
        
        // handle the error
        guard status == noErr else {
            throw KeychainError.FailedToDelete(code: status)
        }
    }
    
    /**
    Clear all items from the Keychain
    
    - throws: `OSStatus` value from SecItemDelete(), for anything other than `noErr`
    */
    public static func clear() throws {
        // create a query for all generic password items
        let query = [kSecClass as String : kSecClassGenericPassword]
        
        // delete
        let status = SecItemDelete(query as CFDictionaryRef)
        
        // handle the error
        guard status == noErr else {
            throw KeychainError.FailedToClear(code: status)
        }
    }
}
