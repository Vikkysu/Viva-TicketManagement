//
//  UIImageCustom.swift
//  XomeProOnboard
//
//  Created by Vikas on 10/26/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class UIImageCustom : NSObject {
    func getImageFromString(string: String)->UIImage? {
        let bundle = NSBundle(forClass: self.dynamicType)
        let image: UIImage? = UIImage(named: string, inBundle: bundle, compatibleWithTraitCollection: nil)
        return image
    }
//
}
