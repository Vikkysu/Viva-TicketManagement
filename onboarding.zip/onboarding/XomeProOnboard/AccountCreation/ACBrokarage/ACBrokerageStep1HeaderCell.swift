//
//  ACBrokerageStep1HeaderCell.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/3/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class ACBrokerageStep1HeaderCell: UITableViewCell {
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String!)
    {
        super.init(style: UITableViewCellStyle.Value1, reuseIdentifier: reuseIdentifier)
        var labelText : UILabel
        labelText = UILabel()
        labelText.numberOfLines=0
        labelText.textAlignment = .Center
        labelText.tag=34
        labelText.textColor=UIColor.baoGunmetalColor()
        labelText.backgroundColor=UIColor.clearColor()
        labelText.font = UIFont(name: MuseoSansRounded100Font, size: 20.0)
        self.addSubview(labelText)
        
        let separatorLine: UIView = UIView()
        separatorLine.backgroundColor = UIColor.baoTableBorderColor()
        self.addSubview(separatorLine)
        
        labelText.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self).offset(10)
            make.bottom.equalTo(self).offset(-10)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
            
        }
        
        separatorLine.snp_makeConstraints {(make) -> Void in
            make.bottom.equalTo(labelText).offset(4)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-1)
            make.height.equalTo(1)
        }
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setSelected(selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
}
