//
//  XomeServiceAssembly.swift
//  XomeRestClient
//
//  Created by Brendan Farrington on 12/2/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import XomeAssembly

public class XomeServiceAssembly : TyphoonAssembly, XomeAssemblyInitialComponent {
    var restAssembly: XomeRestClientAssembly!

    public dynamic func xomeService() -> AnyObject {
        return TyphoonDefinition.withClass(XomeService.self) {
            (definition) in
            definition.scope = .Singleton
            definition.injectProperty("operationFactory", with: self.restAssembly.operationFactory())
            definition.injectProperty("environment", with: self.restAssembly.serviceEnvironment())
            definition.injectProperty("imageService", with: self.imageService())
            definition.injectProperty("mapLayerData", with: self.mapLayerData())
        }
    }

    public dynamic func imageService() -> AnyObject {
        return TyphoonDefinition.withClass(ImageService.self, configuration: { (definition: TyphoonDefinition!) in
            definition.scope = .LazySingleton
            definition.useInitializer("initWithCache:") { (method) in
                method.injectParameterWith(self.imageServiceCache())
            }
            definition.injectProperty("operationFactory")
        })
    }

    private dynamic func imageServiceCache() -> AnyObject {
        return TyphoonDefinition.withClass(DefaultImageCache.self, configuration: { (definition: TyphoonDefinition!) in
        })
    }


}
