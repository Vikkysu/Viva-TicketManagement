//
//  MakeAnOffer.swift
//  XomeRestClient
//
//  Created by Shivakumar Chandramouli on 2/5/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper
import CoreLocation
import PromiseKit


public extension XomeService {

    public func makeAnOffer(model: MakeAnOfferRequestModel) -> Promise<MakeAnOfferModel>
    {
        let path = "MyAccount/MakeAnOffer"
        guard let offerModel = Mapper().toJSONString(model)?.dataUsingEncoding(NSUTF8StringEncoding) else {
            return Promise(error: NSError(domain: "JSON Serialization", code: 0, userInfo: [NSLocalizedDescriptionKey:"Failed to serialize MakeAnOfferRequestModel"]))
        }
        return operationFactory.promise(.POST, path: path, queryParameters: nil, bodyData: offerModel)
    }

    public func scheduleTour(model: ScheduleTourModel) -> Promise<TourModel>
    {
        let path = "MyAccount/RequestTour"
        guard let postData = Mapper().toJSONString(model)?.dataUsingEncoding(NSUTF8StringEncoding) else {
            return Promise(error: NSError(domain: "JSON Serialization", code: 0, userInfo: [NSLocalizedDescriptionKey:"Failed to serialize ScheduleTourModel"]))
        }
        return operationFactory.promise(.POST, path: path, queryParameters: nil, bodyData: postData)
    }

    public func getRecommendedAgent(listingId:String, postalCode:String, propertyValue:String) -> Promise<RecommendedAgents> {
        
        let path = "MyAccount/getSelectedAgent?listingId=\(listingId)&propertyId=0&propertyPostalCode=\(postalCode)&propertyValue=\(propertyValue)&forBuy=true"
        return operationFactory.promise(.GET, path: path, queryParameters: nil, bodyData: nil)
    }
    
    public func getAgent(listingId:String, propertyValue:String) -> Promise<GetAgentsModel> {
        
        let path = "MyAccount/GetAgents?listingId=\(listingId)&propertyId=0&propertyValue=\(propertyValue)&forBuy=true"
        return operationFactory.promise(.GET, path: path, queryParameters: nil, bodyData: nil)
    }
    
    public func selectAgent(model: SelectAgentRequestModel) -> Promise <SelectAgentResponse> {
        
        let path = "MyAccount/SelectAgent"
        let postParamsString: String = NSDictionary(dictionary: ["isBuyAgent": "true", "listingId" : model.listingId!, "agentId": model.agentId!,
            "operation": model.operation!]).toQueryString()
        let postParamsData = postParamsString.dataUsingEncoding(NSUTF8StringEncoding)
        
        return self.operationFactory.promise(.POST, path: path, queryParameters: nil, bodyData: postParamsData) { request in
            request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        }
    }
}
