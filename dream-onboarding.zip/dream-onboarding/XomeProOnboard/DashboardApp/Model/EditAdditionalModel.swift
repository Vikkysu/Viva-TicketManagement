//
//  EditProfileModel.swift
//  ProfessionalTools
//
//  Created by MACMINI4 on 23/10/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class EditAdditionalModel: NSObject {
    
    typealias Callback = (EditAdditionalModel) -> ()

    var addr1:String!
    var addr2:String!
    var addrCity:String!
    var addrState:String!
    var zipCode:String!
    
    func fillProfile(profileModel: ProfileModel, cb: Callback) {
        let profileAdditionalModel = EditAdditionalModel()
        profileAdditionalModel.addr1 = profileModel.addr1
        profileAdditionalModel.addr2 = profileModel.addr2
        profileAdditionalModel.addrCity = profileModel.addrCity
        profileAdditionalModel.addrState = profileModel.addrState
        profileAdditionalModel.zipCode = profileModel.zipCode
        
        cb(profileAdditionalModel)
    }
}