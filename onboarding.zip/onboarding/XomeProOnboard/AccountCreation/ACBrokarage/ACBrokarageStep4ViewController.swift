//
//  ACBrokarageStep4ViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 9/29/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class ACBrokarageStep4ViewController: DPAccountCreationBaseViewController {

    @IBOutlet weak var mlsBrokerInfoTable: UITableView!
    var brokerLicenseArr: NSMutableArray = NSMutableArray()
    var eState: flowState = .BROKERAGE

    override func nextViewC1(sender: UIBarButtonItem) {
        //setDataFields
        let accountViewCntrl = self.childViewControllers[0] as! ACBrokerStep4TableViewController
        if accountViewCntrl.setDataFields() == true {
            //DPBrokerWebsiteVideoTableViewController
            
            //in case of Agent
            if userRoleInfo.getUserRole() == userType.InvitedAgent {
                let step2Bio: DPBrokerWebsiteViewController = DPBrokerWebsiteViewController()
                self.navigationController?.pushViewController(step2Bio, animated: true)
                return
            }

            if eState == flowState.MANAGEBROKER {
                let step2Bio: DPBrokerWebsiteViewController = DPBrokerWebsiteViewController()
                self.navigationController?.pushViewController(step2Bio, animated: true)
            }
            else {
                let step2Bio: DPBrandingColorPickerViewController = DPBrandingColorPickerViewController()
                self.navigationController?.pushViewController(step2Bio, animated: true)
            }
        }
    }
    
    func geteState()->flowState {
        return eState
    }
    
    func changeeState(lState : flowState) {
        eState = lState
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Create an Account"

        self.view.backgroundColor = UIColor.lightGrayColor()

        // Do any additional setup after loading the view.
        brokerLicenseArr.addObject("MLS BROKERAGE ID")
        brokerLicenseArr.addObject("MLS NAME")
        
        let tablecontr: ACBrokerStep4TableViewController = ACBrokerStep4TableViewController()
        self.addChildViewController(tablecontr)
        self.view.addSubview(tablecontr.view)
        tablecontr.didMoveToParentViewController(self)
        
        tablecontr.view.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self.view).offset(138)
            make.leading.equalTo(self.view).offset(5)
            make.trailing.equalTo(self.view).offset(-5)
            make.bottom.equalTo(self.view).offset(-5)
        }
        
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            self.setStepIndication(tagStep1, state: 5)
            self.setStepIndication(tagStep2, state: 4)
            return
        }
        
        if eState == .BROKERAGE {
            self.setStepIndication(tagStep1, state: 4)
        }
        else {
            self.setStepIndication(tagStep1, state: 5)
            self.setStepIndication(tagStep2, state: 5)
            self.setStepIndication(tagStep3, state: 3)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
