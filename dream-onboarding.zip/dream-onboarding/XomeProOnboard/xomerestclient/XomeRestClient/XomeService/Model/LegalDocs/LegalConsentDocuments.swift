//
//  LegalConsentDocuments.swift
//  XomeRestClient
//
//  Created by Shivakumar Chandramouli on 3/31/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public enum LegalDocumentStatus: String {
    
    case NeedReview = "Need Review"
}

@objc public class LegalConsentDocuments: NSObject, Mappable {
    
    public var consentStatus : Bool?
    public var documentId: Double?
    public var disclosureType: Double?
    public var version: String?
    public var documentHtml: String?
    public var consentDate: String?
    public var documentTitle: String?
    public var displayConsentStatus: LegalDocumentStatus?
    
    override public init() {
        
    }
    
    required public init?(_ map: Map) {
        
    }
    
    public func mapping(map: Map) {
        
        consentStatus <- map["consentStatus"]
        documentId <- map["documentId"]
        disclosureType <- map["disclosureType"]
        version <- map["version"]
        documentHtml <- map["documentHtml"]
        documentTitle <- map["documentTitle"]
        displayConsentStatus <- map["displayConsentStatus"]
    }
}
