//
//  SelectAgentResponse.swift
//  XomeRestClient
//
//  Created by Shivakumar Chandramouli on 2/16/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class SelectAgentResponse: Mappable {
    
    public var agentId: Double?
    
    public init() {
        
    }
    
    required public init?(_ map: Map) {
        
    }
    
    public func mapping(map: Map) {
        
        agentId <- map["agentId"]
    }
}
