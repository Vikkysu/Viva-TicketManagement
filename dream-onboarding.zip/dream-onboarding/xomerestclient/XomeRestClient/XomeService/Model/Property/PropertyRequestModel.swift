//
//  RequestModels.swift
//  XomeRestClient
//
//  Created by Vikas on 12/16/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import ObjectMapper
import CoreLocation

public class PropertyRequestModel: PropertySearchFilter {
    public var sortId: PropertySortOption?
    public var searchMapNeLat: Double?
    public var searchMapNeLong: Double?
    public var searchMapSwLat: Double?
    public var searchMapSwLong: Double?

    private var locations: [[PropertyRequestLocationModel]]?

    public init(sortId: PropertySortOption? = nil,
        searchMapNe: CLLocationCoordinate2D? = nil,
        searchMapSw: CLLocationCoordinate2D? = nil,
        searchFilter: PropertySearchFilter)
    {
        super.init(other: searchFilter)

        self.sortId = sortId
        self.searchMapNeLong = searchMapNe?.longitude
        self.searchMapNeLat = searchMapNe?.latitude
        self.searchMapSwLong = searchMapSw?.longitude
        self.searchMapSwLat = searchMapSw?.latitude
    }

    required public init?(_ map: Map) {
        super.init(map)
    }

    public override func mapping(map: Map) {
        super.mapping(map)

        sortId <- map["sortId"]
        searchMapNeLat <- map["searchMapNeLat"]
        searchMapNeLong <- map["searchMapNeLong"]
        searchMapSwLat <- map["searchMapSwLat"]
        searchMapSwLong <- map["searchMapSwLong"]
        locations <- map["locations"]
    }

    public func setLocation(location: PropertyRequestLocationModel?) {
        if let loc = location {
            locations = [[loc]]
        } else {
            locations = nil
        }
    }

    public func addLocation(location: PropertyRequestLocationModel) {
        if locations == nil { locations = [[]] }
        locations![0].append(location)
    }
}
