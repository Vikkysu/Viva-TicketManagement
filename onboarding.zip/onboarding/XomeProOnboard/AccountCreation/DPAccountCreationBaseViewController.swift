//
//  DPAccountCreationBaseViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 9/28/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

let  tagStep1: Int = 200
let  tagStep2: Int = 201
let  tagStep3: Int = 202
let  tagStep4: Int = 203


/* this class implements the header part which includes the Navigation Items, Step indication header */
/* call createNextbutton to navigate to next screen, override nextViewC1 */
/* call createSkipbutton to navigate to next screen, override skipViewC1 */
/* call hideNavigationButtons to hide the naviagtion buttons */

class DPAccountCreationBaseViewController: UIViewController {
    
    //override this method to trigger the next action
    func nextViewC1(sender: UIBarButtonItem) {
        
    }
    
    //override this method to trigger the next action
    func skipViewC1(sender: UIBarButtonItem) {
        
    }
    
    func setStepIndication(tagIdentification: Int, state: Int)
    {
//        let StepIndicationView: DPStepIndicationBarView = DPStepIndicationBarView.sharedInstance
//        StepIndicationView.setStepIndication(tagIdentification, state: state)
        let stepLabel: UIImageView = self.view.viewWithTag(tagIdentification) as! UIImageView
        let myColor : UIColor = UIColor.grayColor()
        stepLabel.layer.borderColor = myColor.CGColor
        
        //TODO: set the angle based on the CALCULATION
        let startAngle: CGFloat = CGFloat(3*M_PI/2)
        var endAngle: CGFloat = CGFloat(2*M_PI)
        if state == 3 {
            endAngle = CGFloat(M_PI/2)
        } else if state == 4 {
            endAngle = CGFloat(M_PI)
        } else if state == 5 {
            endAngle = CGFloat(45)
        }
        
        if state > 1 {
            let circle: CAShapeLayer = CAShapeLayer();
            let circlePath : UIBezierPath = UIBezierPath(arcCenter: CGPointMake(15, 15), radius: 15, startAngle: startAngle, endAngle: endAngle, clockwise: true)
            circle.path = circlePath.CGPath
            circle.fillColor=UIColor.clearColor().CGColor;
            let greenCol = UIColor.baoDarkLimeGreenColor()
            
            circle.strokeColor=greenCol.CGColor;
            circle.lineWidth=2;
            
            let animation: CABasicAnimation = CABasicAnimation(keyPath: "strokeEnd")
            animation.duration=0.5;
            animation.removedOnCompletion=false;
            animation.fromValue = (0);
            animation.toValue = (1);
            animation.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionLinear)
            circle.addAnimation(animation, forKey: "drawCircleAnimation")
            
            stepLabel.layer.sublayers?.removeAll()
            stepLabel.layer.addSublayer(circle)
            
        }
        
        if state == 5 {
            stepLabel.image = UIImageCustom().getImageFromString("stepCompletion")
        }
    }
    
    func createViewForStepIndication(rect: CGRect, stepNum: String, stepName: String, tagIdentification: Int) ->UIView {
        let stepView = UIView(frame: rect)
        stepView.backgroundColor = UIColor.clearColor()
        
        let stepLayer = UIImageView(frame: CGRectMake(rect.size.width/2-15, 5, 30, 30))
        stepLayer.tag = tagIdentification
        stepLayer.image = UIImageCustom().getImageFromString(stepNum)
        stepView.addSubview(stepLayer)
        
        let stepLayerLabel = UILabel(frame: CGRectMake(0, stepLayer.frame.size.height+5, rect.size.width, 20))
        stepLayerLabel.text = stepName
        stepLayerLabel.textAlignment = NSTextAlignment.Center
        stepLayerLabel.font = UIFont.systemFontOfSize(8)
        stepLayerLabel.textColor = UIColor.lightGrayColor()
        stepView.addSubview(stepLayerLabel)
        return stepView
    }
    
    
    /* display the navigation rightbar button */
    func createNextbutton(titleStr: String?) {
        var nextItem: UIBarButtonItem = UIBarButtonItem()
        if let titleString = titleStr {
           nextItem = UIBarButtonItem(title: titleString, style: UIBarButtonItemStyle.Plain, target: self, action: Selector("nextViewC1:"))
        }
        else {
            nextItem = UIBarButtonItem(title: "Next", style: UIBarButtonItemStyle.Plain, target: self, action: Selector("nextViewC1:"))
        }
        self.navigationItem.rightBarButtonItem = nextItem
        self.navigationItem.rightBarButtonItem?.tintColor = UIColor.whiteColor()
    }
    
    /* display the navigation rightbar button */
    func createSkipbutton() {
        let nextItem = UIBarButtonItem(title: "Skip", style: UIBarButtonItemStyle.Plain, target: self, action: Selector("skipViewC1:"))
        self.navigationItem.rightBarButtonItem = nextItem
        self.navigationItem.rightBarButtonItem?.tintColor = UIColor.whiteColor()
    }

    /* this func hides the top navigation bar buttons */
    func hideNavigationButtons() {
        let nextItem = UIBarButtonItem(title: " ", style: UIBarButtonItemStyle.Plain, target: self, action: Selector("skipViewC1:"))
        nextItem.enabled = false
        self.navigationItem.rightBarButtonItem = nextItem
        self.navigationItem.rightBarButtonItem?.tintColor = UIColor.whiteColor()
        self.navigationItem.setHidesBackButton(true, animated: false)
        let fontStyle : UIFont = UIFont(name: "MuseoSansRounded-300", size: 18.0)!
        let titleDict: NSDictionary = [NSForegroundColorAttributeName: UIColor.whiteColor(), NSFontAttributeName: fontStyle]
        self.navigationItem.rightBarButtonItem!.setTitleTextAttributes(titleDict as? [String : AnyObject], forState: .Normal)

    }
    
    func setNavigationPreferences(color: UIColor) {
        UINavigationBar.appearance().backgroundColor = UIColor.baoPrimaryColor()
        UINavigationBar.appearance().barTintColor = UIColor.baoPrimaryColor()
        UINavigationBar.appearance().tintColor = UIColor.whiteColor()
        self.navigationController!.navigationBar.barTintColor =   UIColor.baoPrimaryColor();

        let fontStyle : UIFont = UIFont(name: MuseoSansRounded300Font, size: 18.0)!
        
        let titleDict: NSDictionary = [NSForegroundColorAttributeName: UIColor.whiteColor(), NSFontAttributeName: fontStyle]
        UINavigationBar.appearance().titleTextAttributes = titleDict as? [String : AnyObject]
        self.navigationController?.navigationBar.titleTextAttributes = titleDict as? [String: AnyObject]
        
        self.createNextbutton(NEXTBUTTON)
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .Plain, target: nil, action: nil)
        self.navigationItem.rightBarButtonItem!.setTitleTextAttributes(titleDict as? [String : AnyObject], forState: .Normal)
    }
    
    func createStepIndicationBar() {
        let exampleView = UIView(frame: CGRectMake(0, 64, self.view.frame.size.width, 70))
        exampleView.backgroundColor = UIColor.whiteColor()
        
        let myColor : UIColor = UIColor.lightGrayColor()
        exampleView.layer.borderWidth = 1
        exampleView.layer.borderColor = myColor.CGColor
        
        self.view.addSubview(exampleView)
        
        let heightRect: CGFloat = 50.0
        let width: CGFloat = (self.view.frame.width/4)
        
        //TODO:- Need to support agent creation
//        let userRoleInstance: userRoleInfo = userRoleInfo.sharedInstance
        let stepIndicationValues : NSArray = userRoleInfo.getStepIndicationData(userRoleInfo.getUserRole()!)
        
        exampleView.addSubview(self.createViewForStepIndication(CGRectMake(0, 5, width, heightRect), stepNum: "step1", stepName: stepIndicationValues[0] as! String, tagIdentification: tagStep1))
        exampleView.addSubview(self.createViewForStepIndication(CGRectMake(width, 5, width, heightRect), stepNum: "step2", stepName: stepIndicationValues[1] as! String, tagIdentification: tagStep2))
        exampleView.addSubview(self.createViewForStepIndication(CGRectMake(width*2, 5, width, heightRect), stepNum: "step3", stepName: stepIndicationValues[2] as! String, tagIdentification: tagStep3))
        exampleView.addSubview(self.createViewForStepIndication(CGRectMake(width*3, 5, width, heightRect), stepNum: "step4", stepName: stepIndicationValues[3] as! String, tagIdentification: tagStep4))
    }
    
    //Calls this function when the tap is recognized.
    func DismissKeyboard(){
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        //TODO:- Make the step indocation bar static
        // Do any additional setup after loading the view.
//        let StepIndicationClass: DPStepIndicationBarView = DPStepIndicationBarView.sharedInstance
//        let stepIndicationView: UIView = StepIndicationClass.createStepIndicationBar()
//        stepIndicationView.frame = CGRectMake(stepIndicationView.frame.origin.x, 68, stepIndicationView.frame.size.width,  stepIndicationView.frame.size.height)
//        self.view.addSubview(stepIndicationView)
        self.createStepIndicationBar()
        
        //set navigation options
        // creating next button view
        self.setNavigationPreferences(UIColor.blackColor())
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "DismissKeyboard")
        view.addGestureRecognizer(tap)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
