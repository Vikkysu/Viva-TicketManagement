//
//  UpdateConsentResponse.swift
//  XomeRestClient
//
//  Created by Shivakumar Chandramouli on 4/4/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper


public class UpdateConsentResponse: NSObject, Mappable {

    public var response: Bool?
    
    
    override public init() {
        
    }
    
    required public init?(_ map: Map) {
        
    }
    
    public func mapping(map: Map) {
        
        
        response <- map["success"]
    }

}
