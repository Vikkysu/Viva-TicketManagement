//
//  DPLoginAPI.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/23/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import SwiftyJSON
import Alamofire

class DPLoginAPI {
    typealias Callback = (JSON, NSError?) -> ()

    func getBrokerList(username: String, cb: Callback) {
        Alamofire.request(.GET, "\(stageDomain)LoginNames/\(username)/Tenants")
            .responseJSON { response in
                if let httpResponse = response.response {
                    print("error \(httpResponse.statusCode)")
                    if httpResponse.statusCode > 199 && httpResponse.statusCode < 300 {
                        if let JSON1 = response.result.value {
                            print("JSON: \(JSON1)")
                            let json = JSON(JSON1)
                            cb(json, nil)
                        }
                    }
                    else {
                        //let messageStr = NSString(data: response.data, encoding: UInt)
                        
                        let alertView : UIAlertView = UIAlertView(title: "Error!!!", message:response.description , delegate: nil, cancelButtonTitle: "Ok")
                        alertView.show()
                        cb(nil, response.result.error)
                    }
                }
        }
    }
}

