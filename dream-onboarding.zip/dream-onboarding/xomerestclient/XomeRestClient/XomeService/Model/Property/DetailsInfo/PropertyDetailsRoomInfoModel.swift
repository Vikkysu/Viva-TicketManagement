//
//  PropertyDetailsRoomInfoModel.swift
//  XomeRestClient
//
//  Created by Vikas on 1/19/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class PropertyDetailsRoomInfoModel : PropertyDetailsInfoModel {
    public struct InfoSection {
        public let sectionName: String
        public let entries: [String]
        public init(name: String, entries: [String]) {
            self.sectionName = name
            self.entries = entries
        }
    }
    public var infoSections : [InfoSection]

    public init?(sections: [InfoSection], map: Map) {
        infoSections = sections
        super.init(map)
    }

    public required init?(_ map: Map) {
        infoSections = []
        super.init(map)
    }

    public override func mapping(map: Map) {
        super.mapping(map)
    }

    public override var items : [(String, String)] {
        return infoSections.map { ($0.sectionName, $0.entries.joinWithSeparator("\n")) }
    }
}