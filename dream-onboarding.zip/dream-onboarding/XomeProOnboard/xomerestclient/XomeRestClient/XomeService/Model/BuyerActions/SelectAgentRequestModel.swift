//
//  SelectAgentRequestModel.swift
//  XomeRestClient
//
//  Created by Shivakumar Chandramouli on 2/16/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class SelectAgentRequestModel: Mappable {
    
    public var isBuyAgent: Bool?
    public var listingId: String?
    public var agentId: String?
    public var operation: String?
    public var propertyValue: String?
    
    public init() {
        
    }
    
    required public init?(_ map: Map) {
        
    }
    
    public func mapping(map: Map) {
        
        isBuyAgent <- map["isBuyAgent"]
        listingId <- map["listingId"]
        agentId <- map["agentId"]
        operation <- map["operation"]
        propertyValue <- map["propertyValue"]
    }
}
