//
//  ValuationRecords.swift
//  XomeRestClient
//
//  Created by Xome on 2/4/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class ValuationRecords: Mappable {
    
    public var propertyId: Double?
    public var estimatedValue: Double?
    public var estimationDate: String?
    public var priceRangeMin: Double?
    public var priceRangeMax: Double?
    public var latitude: Double?
    public var longitude: Double?
    public var propertyValuationHistoryPoints: [PropertyValuationHistoryPoints]?
    
    required public init?(_ map: Map) {
        
    }
    
    public func mapping(map: Map) {
        
        propertyId <- map["propertyId"]
        estimatedValue <- map["estimatedValue"]
        estimationDate <- map["estimationDate"]
        priceRangeMin <- map["priceRangeMin"]
        priceRangeMax <- map["priceRangeMax"]
        latitude <- map["latitude"]
        longitude <- map["longitude"]
        propertyValuationHistoryPoints <- map["propertyValuationHistoryPoints"]
    }
}