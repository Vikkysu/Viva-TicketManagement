//
//  POIModel.swift
//  XomeRestClient
//
//  Created by Thomas De Leon on 2/16/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import MapKit
import ObjectMapper
import PromiseKit
import DreamLogging

public enum POIType:Int {
    case ChildCare = 5
    case Schools
    case Restaurant
    case Shopping
    case Grocery
    case Bank
    case Entertainment
    case Medical
    case Transportation
    case Hotel
    case Worship
    case Police
    case Fire
    case Library
    case Mail
    case Cultural
}

@objc public class POIModel: NSObject, MKAnnotation, Mappable {
    
    private struct Keys {
        private static let POIType = "pinID"
        private static let Name = "name"
        private static let Address = "address"
        private static let Phone = "phoneNumber"
        private static let Latitude = "latitude"
        private static let Longitude = "longitude"
    }
    
    public var name:String
    public var address:String
    public var phone:String
    public var coordinate:CLLocationCoordinate2D
    public var poiType:POIType
    
    private let transformPOIType = TransformOf<POIType, String>(fromJSON: {
        POIModel.poiType($0) ?? nil
        }, toJSON: {
            $0.map { String($0.rawValue)}
    })
    
    required public init?(_ map:Map) {
        // There is a crash in here and it's not entirely obvious what is wrong. Add some additional information:
        DRLogCrashInfo("POIModel.init? map information: \(NSDictionary(dictionary: map.JSONDictionary).description)")

        let typeString:String = map[Keys.POIType].valueOr("")
        let poi = POIModel.poiType(typeString)
        poiType = poi ?? .ChildCare
        name = map[Keys.Name].valueOr("")
        address = map[Keys.Address].valueOr("")
        phone = map[Keys.Phone].valueOr("")
        coordinate = CLLocationCoordinate2D(latitude: map[Keys.Latitude].valueOrFail(), longitude: map[Keys.Longitude].valueOrFail())
        super.init()
        guard poi != nil && address != "" && name != "" else {
            return nil
        }
    }
    
    public func mapping(map: Map) {
        poiType <- (map[Keys.POIType], transformPOIType)
        name <- map[Keys.Name]
        address <- map[Keys.Address]
        phone <- map[Keys.Phone]
        var latitude: Double?
        var longitude: Double?
        latitude <- map[Keys.Latitude]
        longitude <- map[Keys.Longitude]
        
        if let latitude = latitude, let longitude = longitude {
            coordinate = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        }
    }
    
    override public var hashValue: Int {
        return name.hashValue ^ coordinate.latitude.hashValue ^ coordinate.longitude.hashValue
    }
    
    override public func isEqual(object: AnyObject?) -> Bool {
        if let rhs = object as? POIModel {
            return hashValue == rhs.hashValue
        }
        return false
    }
    
    // helper to convert pinID string to MapAnnotation enum
    private static func poiType(pinID:String?)->POIType? {
        // The first part of the pinID field is the pin type followed by an id, in the format "5_0, 5_1", etc
        guard let pinID = pinID,
            let first = pinID.componentsSeparatedByString("_").first,
            let typeInt = Int(first),
            let type = POIType(rawValue: typeInt) else {
                return nil
        }
        return type
    }
}

func ==(lhs: POIModel, rhs: POIModel) -> Bool {
    return lhs.hashValue == rhs.hashValue
}
