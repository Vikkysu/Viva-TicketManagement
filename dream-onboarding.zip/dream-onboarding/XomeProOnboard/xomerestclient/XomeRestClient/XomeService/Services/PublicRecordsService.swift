//
//  PublicRecordsService.swift
//  XomeRestClient
//
//  Created by Xome on 2/4/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import UIKit
import Foundation
import PromiseKit
import ObjectMapper
import CoreLocation

public extension XomeService {
    
    // MARK: Public Records Detail
    
    private func loadPublicRecordDetails(listingKey: String) -> Promise<PublicRecordsDetailModel>
    {
        let path = "publicpropertyrecords/\(listingKey)"
        return operationFactory.promise(.GET, path: path, queryParameters: nil, bodyData: nil)
    }
    
    public func completePublicPropertyDetails(listingKey: String) -> Promise<PublicRecordsDetailModel> {
        
        return loadPublicRecordDetails(listingKey).then { details -> PublicRecordsDetailModel in
            if let record = details.assessorRecord {
                let lat = record.latitude, lon = record.longitude

                let closedModel = tap(PropertyFilterModel()) {
                    $0.residentialType = PropertyFilterModel.ResidentialTypes.HomeTypes
                    $0.status = .Closed
                }
                details.additionalInfo.nearbySoldProperties = self.search(radius: 0.2, center: CLLocationCoordinate2DMake(lat, lon), pageSize: 10, filterModel: closedModel)

                let activeModel = tap(PropertyFilterModel()) {
                    $0.residentialType = PropertyFilterModel.ResidentialTypes.HomeTypes
                    $0.status = .ForSale
                }
                details.additionalInfo.nearbyActiveProperties = self.search(radius: 10, center: CLLocationCoordinate2DMake(lat, lon), pageSize: 3, filterModel: activeModel)
            }

            return details
        }
    }
}