//
//  LeadDetailViewController.swift
//  DreamLeadInjection
//
//  Created by Developer on 22/10/15.
//  Copyright © 2015 Developer. All rights reserved.
//

import UIKit

class LeadDetailViewController: UIViewController {

    var leadName                :String!
    var leadDetailModel         :LeadsDetailModel = LeadsDetailModel()
    var leadDetailView          :LeadDetailView   = LeadDetailView()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.loadLeadDetail()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func loadLeadDetail(){
        
        let leadDetails     :NSMutableArray    = leadDetailModel.fetchLeadData(leadName)
        leadDetailView.loadLeadDetailUI(self, inDataDictionary: leadDetails[0] as! NSMutableDictionary)
        
    }

}
