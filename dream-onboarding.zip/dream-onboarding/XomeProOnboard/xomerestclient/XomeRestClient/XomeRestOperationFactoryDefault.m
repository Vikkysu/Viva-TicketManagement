//
//  XomeRestOperationFactoryDefault.m
//  Xome
//
//  Created by David Parton on 6/26/15.
//  Copyright (c) 2015 Xome. All rights reserved.
//

#import "XomeRestOperationFactoryDefault.h"

@import DreamLogging;

XOME_OBJECT_ASSOCIATION_KEY(kConnectionLifetimeAssociation);

static NSRunLoop* XomeRestOperationRunLoop = nil;
@interface XomeRestOperationThread : NSObject
@end

@implementation XomeRestOperationThread

+ (NSRunLoop*)runLoop {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        dispatch_semaphore_t threadReady = dispatch_semaphore_create(0);
        NSThread* thread = [[NSThread alloc] initWithTarget:self selector:@selector(threadLoop:) object:threadReady];
        [thread start];
        dispatch_semaphore_wait(threadReady, DISPATCH_TIME_FOREVER);
    });
    return XomeRestOperationRunLoop;
}

+ (void)threadLoop:(dispatch_semaphore_t)semaphore {
    XomeRestOperationRunLoop = [NSRunLoop currentRunLoop];
    dispatch_semaphore_signal(semaphore);
    
    [XomeRestOperationRunLoop addPort:[NSMachPort port] forMode:NSRunLoopCommonModes]; // this port prevents the runloop from spinning as it acts as a null input source
    for ([XomeRestOperationRunLoop run]; ;[XomeRestOperationRunLoop run]) {
        DRLogErr(@"XomeRestOperationRunLoop returned! This is bad!");
    }
}

@end

@interface XomeRestOperation : NSObject <XomeRestOperation, NSURLConnectionDelegate, NSURLConnectionDataDelegate>
@property (nonatomic) NSURLRequest* urlRequest;
@property (nonatomic) NSMutableData* data;
@property (nonatomic) BOOL shouldCallbackOnMainThread;
@property (nonatomic,assign) NSUInteger responseStatusCode;
@property (nonatomic,copy) XomeRestOperationSuccessHandler successHandler;
@property (nonatomic,copy) XomeRestOperationErrorHandler errorHandler;
@property (nonatomic,copy) XomeRestOperationFinallyHandler finallyHandler;
@property (nonatomic,weak) NSOperationQueue* operationQueue;
@end

@implementation XomeRestOperation

- (instancetype)initWithURLRequest:(NSURLRequest*)request operationQueue:(NSOperationQueue*)operationQueue {
    if ((self = [super init])) {
        _urlRequest = [request copy];
        _operationQueue = operationQueue;
    }
    return self;
}

- (id<XomeRestOperation>)handleSuccess:(XomeRestOperationSuccessHandler)handler {
    self.successHandler = handler;
    return self;
}

- (id<XomeRestOperation>)handleError:(XomeRestOperationErrorHandler)handler {
    self.errorHandler = handler;
    return self;
}

- (id<XomeRestOperation>)finally:(XomeRestOperationFinallyHandler)handler {
    self.finallyHandler = handler;
    return self;
}

- (id<XomeRestOperation>)callbackOnMainThread {
    self.shouldCallbackOnMainThread = YES;
    return self;
}

- (void)start {
    [self.operationQueue addOperationWithBlock:^{
        NSURLConnection* connection = [[NSURLConnection alloc] initWithRequest:self.urlRequest delegate:self startImmediately:NO];
        [connection associateObject:self withKey:kConnectionLifetimeAssociation policy:XomeObjectAssociationPolicy_RETAIN_NONATOMIC];
        [connection scheduleInRunLoop:XomeRestOperationThread.runLoop forMode:NSRunLoopCommonModes];
        [connection start];
    }];
}

- (void)fail:(NSError *)error {
    XomeRestOperationErrorHandler errorHandler = self.errorHandler;
    XomeRestOperationFinallyHandler finallyHandler = self.finallyHandler;
    self.errorHandler = nil;
    self.finallyHandler = nil;
    
    [self executeCallback:^{
        if (errorHandler) {
            errorHandler(error);
        }
        if (finallyHandler) {
            finallyHandler(self);
        }
    }];
}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    NSHTTPURLResponse* httpResponse = (NSHTTPURLResponse*)response;
    self.responseStatusCode = [httpResponse statusCode];
    self.data = self.data ?: [NSMutableData new];
    [self.data setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    self.data = self.data ?: [NSMutableData new];
    [self.data appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    if (self.responseStatusCode / 100 == 2) {
        XomeRestOperationSuccessHandler successHandler = self.successHandler;
        XomeRestOperationFinallyHandler finallyHandler = self.finallyHandler;
        self.successHandler = nil;
        self.finallyHandler = nil;
        
        [self executeCallback:^{
            if (successHandler) {
                successHandler(self.data);
            }
            if (finallyHandler) {
                finallyHandler(self);
            }
        }];
    } else {
        NSDictionary* userInfo = @{ NSLocalizedDescriptionKey: [NSHTTPURLResponse localizedStringForStatusCode:self.responseStatusCode],
                                    NSLocalizedFailureReasonErrorKey: [[NSString alloc] initWithData:self.data encoding:NSUTF8StringEncoding] };
        [self connection:connection didFailWithError:[[NSError alloc] initWithDomain:self.urlRequest.URL.absoluteString code:self.responseStatusCode userInfo:userInfo]];
    }
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    DRLogErr(@"REST error: %@", error);
    [self fail:error];
}

- (void)executeCallback:(VoidBlock)callback {
    if (self.shouldCallbackOnMainThread) {
        dispatch_async(dispatch_get_main_queue(), callback);
    } else {
        callback();
    }
}

@end

@interface XomeRestOperationFactoryDefault ()
@property (nonatomic) NSOperationQueue* operationQueue;
@end

@implementation XomeRestOperationFactoryDefault

- (instancetype)init {
    if ((self = [super init])) {
        _operationQueue = [[NSOperationQueue alloc] init];
        _operationQueue.maxConcurrentOperationCount = 2;
    }
    return self;
}

- (id<XomeRestOperation>)operation:(NSString *)operation resourcePath:(NSString *)resourcePath queryParameters:(NSDictionary *)queryParameters postData:(NSData *)data {
    return [self operation:operation host:nil resourcePath:resourcePath queryParameters:queryParameters postData:data mutateRequestHandler:nil];
}

- (id<XomeRestOperation>)operation:(NSString *)operation host:(NSString *)host resourcePath:(NSString *)resourcePath queryParameters:(NSDictionary *)queryParameters postData:(NSData *)data {
    return [self operation:operation host:host resourcePath:resourcePath queryParameters:queryParameters postData:data mutateRequestHandler:nil];
}

- (id<XomeRestOperation>)operation:(NSString *)operation host:(NSString *)host resourcePath:(NSString *)resourcePath queryParameters:(NSDictionary *)queryParameters postData:(NSData *)data mutateRequestHandler:(XomeRestOperationFactoryFinalRequestMutationHandler)handler {
    NSURL* url = [self _buildURL:host resourcePath:resourcePath queryParameters:queryParameters];
    NSMutableURLRequest* outgoingRequest = [[NSMutableURLRequest alloc] initWithURL:url
                                                                        cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                                    timeoutInterval:60];
    outgoingRequest.HTTPMethod = operation ?: @"GET";
    outgoingRequest.HTTPBody = data;
    
    [outgoingRequest setValue:self.environment.apiKey forHTTPHeaderField:@"X-RED-APIKey"];
    [outgoingRequest setValue:@"application/json" forHTTPHeaderField:@"Accept"];
    [outgoingRequest setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    if (handler) handler(outgoingRequest);
    return [[XomeRestOperation alloc] initWithURLRequest:outgoingRequest operationQueue:self.operationQueue];
}

- (NSURL*)_buildURL:(NSString*)host resourcePath:(NSString*)resourcePath queryParameters:(NSDictionary*)queryParameters {
    NSURL* hostURL = [NSURL URLWithString:host];
    hostURL = hostURL.scheme ? hostURL : nil;
    
    NSURL* baseURL = hostURL ?: host ? [NSURL URLWithString:[@"//" stringByAppendingString:host] relativeToURL:self.environment.apiEndpointURL]
    : self.environment.apiEndpointURL;
    
    NSString* queryString = queryParameters.toQueryString;
    queryString = queryString.length ? [@"?" stringByAppendingString:queryString] : @"";
    resourcePath = [resourcePath hasPrefix:@"/"] ? [resourcePath substringFromIndex:1] : resourcePath;
    
    NSString* pathQuery = [NSString stringWithFormat:@"%@%@", resourcePath ?: @"", queryString];
    return [[[NSURL alloc] initWithString:pathQuery relativeToURL:baseURL] absoluteURL];
}

@end
