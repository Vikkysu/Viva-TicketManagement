//
//  DPBrandingInviteTableViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/20/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrandingInviteTableViewController: UITableViewController, UITextViewDelegate {
    var brokerBioInfo: UITextView!
    
    func setDataFields() -> Bool
    {
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        tableView.delegate=self
        tableView.dataSource=self
        tableView.showsHorizontalScrollIndicator=false
        tableView.showsVerticalScrollIndicator=false
        tableView.separatorStyle = .None
        tableView.registerClass(ACBrokerageStep1HeaderCell.self, forCellReuseIdentifier: "reuseIdentifier")
        tableView.registerClass(DPBrandingInviteTableViewCell.self, forCellReuseIdentifier: "DPBrandingInviteTableViewCellIdentiifer")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Tableview delegates
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 2
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 100
        }
        return tableView.frame.height-100
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        // fill the fields if saved offline
        if(indexPath.row == 0)
        {
            let cell: ACBrokerageStep1HeaderCell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath) as! ACBrokerageStep1HeaderCell
            let label: UILabel? = cell.viewWithTag(34) as? UILabel
            let parentViewC : DPBrandingInviteViewController =  self.parentViewController as! DPBrandingInviteViewController
            
            var textHeader = "Invite Your Agents"
            if parentViewC.geteState() == flowStateInvite.ICLIENT {
                textHeader = "Invite Your Clients"
            }

            label!.text = textHeader
            
            cell.selectionStyle = .None
            return cell
        }
        
        //DPBrandingBioCell
        let cell: DPBrandingInviteTableViewCell = tableView.dequeueReusableCellWithIdentifier("DPBrandingInviteTableViewCellIdentiifer", forIndexPath: indexPath) as! DPBrandingInviteTableViewCell
        let textFieldInfo : UITextView? = cell.viewWithTag(60) as? UITextView
        
        brokerBioInfo = textFieldInfo
        brokerBioInfo.delegate=self
        cell.selectionStyle = .None
        
        return cell
    }
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        if text == "\n" {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    func textViewDidEndEditing(textView: UITextView) {
        let parentViewC : DPBrandingInviteViewController =  self.parentViewController as! DPBrandingInviteViewController
        if !textView.text.isEmpty {
            parentViewC.createNextbutton(INVITEBUTTON)
        }
        else {
            parentViewC.createSkipbutton()
        }
    }
    
    func textViewDidBeginEditing(textView: UITextView) {
        textView.attributedText = NSAttributedString()
        textView.text = ""
        textView.textColor = UIColor.baoGunmetalColor()
        let parentViewC : DPBrandingInviteViewController =  self.parentViewController as! DPBrandingInviteViewController
        parentViewC.createNextbutton(INVITEBUTTON)
        
    }
}
