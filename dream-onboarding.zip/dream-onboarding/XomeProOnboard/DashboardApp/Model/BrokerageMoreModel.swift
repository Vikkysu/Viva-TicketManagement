//
//  BrokerageMoreModel.swift
//  ProfessionalTools
//
//  Created by Pike Dev 01 on 25/10/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class BrokerageMoreModel: NSObject {
    var brokerageDataArray      :NSMutableArray = NSMutableArray()
    
    var sectionArray      :NSMutableArray = NSMutableArray()

    var brokerageDataDictionary  :NSMutableDictionary   = NSMutableDictionary()
    
    func createAndGetDataSample()->NSMutableArray{
        
        
        brokerageDataDictionary["imgName"]        = "iconSwap@3x.png"
        brokerageDataDictionary["name"]       = "Switch to Agent View"
        brokerageDataDictionary["sectionName"]            = "PROFILES"
        sectionArray.addObject(brokerageDataDictionary)
        brokerageDataArray.addObject(sectionArray)
        brokerageDataDictionary = NSMutableDictionary(capacity: 0)
        sectionArray                     = NSMutableArray(capacity: 0)
        
        brokerageDataDictionary["imgName"]        = "iconHomeList@3x.png"
        brokerageDataDictionary["name"]       = "Listings"
        brokerageDataDictionary["sectionName"]            = "PROPERTIES"
        
        sectionArray.addObject(brokerageDataDictionary)
        brokerageDataArray.addObject(sectionArray)

        brokerageDataDictionary = NSMutableDictionary(capacity: 0)
        sectionArray                     = NSMutableArray(capacity: 0)

        brokerageDataDictionary["imgName"]        = "myProfileCopy2@3x.png"
        brokerageDataDictionary["name"]               = "Agents"
        brokerageDataDictionary["sectionName"]   = ""
        
        sectionArray.addObject(brokerageDataDictionary)
        brokerageDataDictionary = NSMutableDictionary(capacity: 0)
        
        brokerageDataDictionary["imgName"]        = "discover@3x.png"
        brokerageDataDictionary["name"]               = "Leads"
        brokerageDataDictionary["sectionName"]   = ""
        
        sectionArray.addObject(brokerageDataDictionary)
        brokerageDataArray.addObject(sectionArray)
        
        brokerageDataDictionary = NSMutableDictionary(capacity: 0)
        sectionArray                     = NSMutableArray(capacity: 0)
        
        brokerageDataDictionary["imgName"]        = "list@3x.png"
        brokerageDataDictionary["name"]               = "Tasks"
        brokerageDataDictionary["sectionName"]   = ""
        
        sectionArray.addObject(brokerageDataDictionary)
        brokerageDataArray.addObject(sectionArray)
        brokerageDataDictionary = NSMutableDictionary(capacity: 0)
        sectionArray                     = NSMutableArray(capacity: 0)
        
        brokerageDataDictionary["imgName"]        = "iconHomeCheck@3x.png"
        brokerageDataDictionary["name"]       = "Transactions"
        brokerageDataDictionary["tag"]            = ""
        
        sectionArray.addObject(brokerageDataDictionary)
        brokerageDataArray.addObject(sectionArray)
        
        
        brokerageDataDictionary = NSMutableDictionary(capacity: 0)
        sectionArray                     = NSMutableArray(capacity: 0)

        brokerageDataDictionary["imgName"]        = "documents@3x.png"
        brokerageDataDictionary["name"]               = "Documents"
        brokerageDataDictionary["sectionName"]   = ""
        
        sectionArray.addObject(brokerageDataDictionary)
        brokerageDataArray.addObject(sectionArray)

        return brokerageDataArray
    }
}
