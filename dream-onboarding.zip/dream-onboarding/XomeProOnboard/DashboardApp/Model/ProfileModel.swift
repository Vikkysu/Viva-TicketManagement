//
//  ProfileModel.swift
//  ProfessionalTools
//
//  Created by Developer on 23/10/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

class ProfileModel: NSObject {
    
    typealias Callback = (JSON, NSError?, ProfileModel) -> ()
    
    var shopperFirstName:String!
    var shopperLastName:String!
    var agentName:String!
    var contactEmail:String!
    var contactPhone:String!
    var addr1:String!
    var addr2:String!
    var addrCity:String!
    var addrState:String!
    var zipCode:String!
    var interest:String!
    
    func fillProfile(cb: Callback) {
        let profileModel = ProfileModel()
        profileModel.shopperFirstName = "Dustin"
        profileModel.shopperLastName = "Andrews"
        profileModel.agentName = "Jennifer Smith"
        profileModel.contactEmail = "dustinAndrews@gmail.com"
        profileModel.contactPhone = "(206) 393-0539"
        profileModel.addr1 = "1234 Glen Cove"
        profileModel.addr2 = ""
        profileModel.addrCity = "Seatle"
        profileModel.addrState = "WA"
        profileModel.zipCode = "12345"
        profileModel.interest = "Buying"
        
        cb(nil, nil, profileModel)
    }
    
}