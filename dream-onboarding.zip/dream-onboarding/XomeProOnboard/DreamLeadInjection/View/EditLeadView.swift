//
//  EditLeadView.swift
//  DreamLeadInjection
//
//  Created by Developer on 25/10/15.
//  Copyright © 2015 Developer. All rights reserved.
//

import UIKit

class EditLeadView: NSObject {

    var searchType                  :String!
    var vwController                :UIViewController!
    
    var cgScreenWidth               :CGFloat!
    var cgScreenHeight              :CGFloat!
    
    var vwMain                      :UIView!
    var vwHeader                    :UIView!
    
    var vwTopSection                :UIView!
    var vwMiddleSection             :UIView!
    var vwBottomSection             :UIView!
    
    var btnXheader                  :UIButton!
    var lblHeader                   :UILabel!
    var btnHeaderRight              :UIButton!
    
    var lblTopHeader                :UILabel!
    var lblNotesLegend              :UILabel!
    var txtFirstName                :UITextField!
    var txtLastName                 :UITextField!
    var txtEmail                    :UITextField!
    var txtMobile                   :UITextField!
    var txtLeadType                 :UITextField!
    var lblNotes                    :UILabel!
    var txtNotesLegend              :UITextView!
    
    var lblFirstName                :UILabel!
    var lblLastName                 :UILabel!
    var lblEmail                    :UILabel!
    var lblMobile                   :UILabel!
    var lblLeadType                 :UILabel!
    
    var vwLine1                     :UIView!
    var vwLine2                     :UIView!
    var vwLine3                     :UIView!
    var vwLine4                     :UIView!
    
    func loadEditLeadUI(inViewController:UIViewController){
        
        vwController = inViewController
        
        getScreenDimensions()
        createUIElements()
        setProperties()
        //            setProfileData()
        addElements2UI()
    }
    
    func getScreenDimensions(){
        
        let screenDimensions = UIScreen.mainScreen().bounds
        cgScreenWidth        = screenDimensions.width
        cgScreenHeight       = screenDimensions.height
    }
    
    func centreX(inWidth: CGFloat)->CGFloat{
        
        let tWidth:CGFloat  = cgScreenWidth - CGFloat(inWidth)
        let pX: CGFloat     = tWidth/2
        
        return pX
    }
    
    func centreY(inHeight: CGFloat)->CGFloat{
        
        let tHeight:CGFloat  = cgScreenHeight - CGFloat(inHeight)
        let pY: CGFloat      = tHeight/2
        
        return pY
    }
    
    func centreInView(inViewHeight: CGFloat, inHeight:CGFloat)->CGFloat{
        let tCentre :CGFloat = (inViewHeight - inHeight)/2
        return tCentre
    }
    
    func convert2Pixels(points:CGFloat)->CGFloat{
        
        let pixels  :CGFloat = points * 96 / 72
        return pixels
    }
    
    func createUIElements(){
        
        let hdrVwHeight :CGFloat = self.convert2Pixels(65)
        let hdrWidth    :CGFloat = self.convert2Pixels(80)
        let hdrHeight   :CGFloat = self.convert2Pixels(22)
        let hdRtWidth   :CGFloat = self.convert2Pixels(30)
        let hdRtHeight  :CGFloat = self.convert2Pixels(30)
        let hdRtX       :CGFloat = cgScreenWidth - hdRtWidth - 20 //constraint set to hdRtWidth
        let hdRTY       :CGFloat = self.convert2Pixels(31)
        let hdrX        :CGFloat = self.centreX(hdrWidth)
        let hdrY        :CGFloat = self.convert2Pixels(31)
        let topY        :CGFloat = hdrVwHeight+10
        let vwTopHeight :CGFloat = self.convert2Pixels(65)
        let vwTopWidth  :CGFloat = cgScreenWidth-10
        let topHdrHeight:CGFloat = 20
        let topHeaderY  :CGFloat = self.centreInView(vwTopHeight, inHeight: topHdrHeight)
        let medY        :CGFloat = topY+vwTopHeight+10
        let vwMedHeight :CGFloat = cgScreenHeight - hdrVwHeight - vwTopHeight - 275
        let fieldWidth  :CGFloat = vwTopWidth-10
        let lblFNY      :CGFloat = 30
        let lblFNWidth  :CGFloat = fieldWidth/2
        let lblFNHeight :CGFloat = 35
        let lblLNX      :CGFloat = lblFNWidth+5
        let lblEmY      :CGFloat = lblFNY+lblFNHeight+25
        let lblMobY     :CGFloat = lblEmY+lblFNHeight+25
        let lblTypeY    :CGFloat = lblMobY+lblFNHeight+25
        let lblNotesY   :CGFloat = lblTypeY+lblFNHeight+25
        let botY        :CGFloat = medY+vwMedHeight+10
        let botWidth    :CGFloat = cgScreenWidth - 10
        let botHeight   :CGFloat = cgScreenHeight - hdrVwHeight - vwTopHeight - vwMedHeight
        
        
        vwMain              = UIView(frame:CGRectMake(0, 0, cgScreenWidth, cgScreenHeight))
        vwHeader            = UIView(frame:CGRectMake(0, 0, cgScreenWidth, hdrVwHeight))
        btnXheader          = UIButton(frame:CGRectMake(0, hdrY, 33, 33))
        lblHeader           = UILabel(frame:CGRectMake(hdrX, hdrY, hdrWidth, hdrHeight))
        btnHeaderRight      = UIButton(frame:CGRectMake(hdRtX, hdRTY, hdRtWidth, hdRtHeight))
        
        vwTopSection        = UIView(frame:CGRectMake(5, topY, vwTopWidth, vwTopHeight))
        lblTopHeader        = UILabel(frame:CGRectMake(5, topHeaderY, vwTopWidth, topHdrHeight))
        
        vwMiddleSection     = UIView(frame:CGRectMake(5, medY, vwTopWidth, vwMedHeight))
        
        vwBottomSection     = UIView(frame:CGRectMake(5, botY, botWidth, botHeight))
        
        txtFirstName        = UITextField(frame:CGRectMake(5, lblFNY, lblFNWidth, lblFNHeight))
        txtLastName         = UITextField(frame:CGRectMake(lblLNX, lblFNY, lblFNWidth, lblFNHeight))
        vwLine1             = UIView(frame:CGRectMake(0, lblFNY+lblFNHeight+2, botWidth,2))
        txtEmail            = UITextField(frame:CGRectMake(5, lblEmY, fieldWidth, lblFNHeight))
        vwLine2             = UIView(frame:CGRectMake(0, lblEmY+lblFNHeight+2, botWidth,2))
        txtMobile           = UITextField(frame:CGRectMake(5, lblMobY, fieldWidth, lblFNHeight))
        vwLine3             = UIView(frame:CGRectMake(0, lblMobY+lblFNHeight+2, botWidth,2))
        txtLeadType         = UITextField(frame:CGRectMake(5, lblTypeY, fieldWidth, lblFNHeight))
        vwLine4             = UIView(frame:CGRectMake(0, lblTypeY+lblFNHeight+2, botWidth,2))
        lblNotes            = UILabel(frame:CGRectMake(5, lblNotesY, fieldWidth, lblFNHeight))
        lblNotesLegend      = UILabel(frame:CGRectMake(lblFNWidth+40, lblNotesY, fieldWidth, lblFNHeight))
        txtNotesLegend      = UITextView(frame:CGRectMake(0, 0, botWidth, botHeight))
        
        lblFirstName        = UILabel(frame:CGRectMake(5, lblFNY-lblFNHeight+10, lblFNWidth, lblFNHeight))
        lblLastName         = UILabel(frame:CGRectMake(lblLNX, lblFNY-lblFNHeight+10, lblFNWidth, lblFNHeight))
        lblEmail            = UILabel(frame:CGRectMake(5, lblEmY-lblFNHeight+10, fieldWidth, lblFNHeight))
        lblMobile           = UILabel(frame:CGRectMake(5, lblMobY-lblFNHeight+10, fieldWidth, lblFNHeight))
        lblLeadType         = UILabel(frame:CGRectMake(5, lblTypeY-lblFNHeight+10, fieldWidth, lblFNHeight))
        
    }
    
    func setProperties(){
        
        let uiFont18        :UIFont = UIFont(name: "MuseoSansRounded-300", size: 18.0)!
        let uiFont16        :UIFont = UIFont(name: "MuseoSansRounded-300", size: 16.0)!
        let uiFont15        :UIFont = UIFont(name: "MuseoSansRounded-300", size: 15.0)!
        let uiFont14        :UIFont = UIFont(name: "MuseoSansRounded-300", size: 14.0)!
        let uiFont12        :UIFont = UIFont(name: "MuseoSansRounded-300", size: 12.0)!
        let uiFont11        :UIFont = UIFont(name: "MuseoSansRounded-300", size: 11.0)!
        let uiFont10        :UIFont = UIFont(name: "MuseoSansRounded-300", size: 10.0)!
        
        vwMain.backgroundColor                  = UIColor(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
        
        //setup header
        vwHeader.backgroundColor                = UIColor(red: 217/255, green: 2/255, blue: 9/255, alpha: 1)
        let imgBtnImage     :UIImage            = UIImage(named:"btnSave3.png")!
        btnXheader.setImage(imgBtnImage, forState: .Normal)
        btnXheader.addTarget(self, action: Selector("back"), forControlEvents: UIControlEvents.TouchUpInside)
        
        lblHeader.text                          = "Edit Lead"
        btnHeaderRight.setTitle("Save", forState: .Normal)
        
        lblHeader.font                          = uiFont18
        btnHeaderRight.titleLabel?.font         = uiFont15
        
        lblHeader.textColor                     = UIColor.whiteColor()
        btnHeaderRight.titleLabel?.textColor    = UIColor.whiteColor()
        
        vwTopSection.backgroundColor        = UIColor.whiteColor()
        vwMiddleSection.backgroundColor     = UIColor.whiteColor()
        
        lblTopHeader.text = "Edit Lead Information"
        lblTopHeader.textColor = UIColor(red: 112/255, green: 117/255, blue: 129/255, alpha: 1)
        
        lblTopHeader.textAlignment = .Center
        lblTopHeader.font = uiFont18
        
        lblFirstName.text   = "FIRST NAME"
        lblLastName.text    = "LAST NAME"
        lblEmail.text       = "EMAIL"
        lblMobile.text      = "MOBILE NUMBER"
        lblLeadType.text    = "LEAD TYPE"
 
        lblFirstName.font   = uiFont10
        lblLastName.font    = uiFont10
        lblEmail.font       = uiFont10
        lblMobile.font      = uiFont10
        lblLeadType.font    = uiFont10
 
        lblFirstName.textColor  = UIColor.blackColor()
        lblLastName.textColor   = UIColor.blackColor()
        lblEmail.textColor      = UIColor.blackColor()
        lblMobile.textColor     = UIColor.blackColor()
        lblLeadType.textColor   = UIColor.blackColor()
        
        txtFirstName.placeholder    = "FIRST NAME"
        txtLastName.placeholder     = "LAST NAME"
        txtEmail.placeholder        = "EMAIL"
        txtMobile.placeholder       = "MOBILE NUMBER"
        txtLeadType.placeholder     = "LEAD TYPE"
        lblNotes.text               = "NOTES"
        lblNotesLegend.text         = "Not visible to your customer"
        lblNotesLegend.font         = uiFont12
        lblNotes.textColor          = UIColor.lightGrayColor()
        lblNotesLegend.textColor    = UIColor.lightGrayColor()
        
        txtNotesLegend.editable           = true
        txtNotesLegend.font               = uiFont12
        txtNotesLegend.text               = ""
        txtNotesLegend.backgroundColor    = UIColor(red: 247/255, green: 247/255, blue: 247/255, alpha: 1)
        
        vwLine1.backgroundColor           = UIColor(red: 230/255, green: 230/255, blue: 230/255, alpha: 1)
        vwLine2.backgroundColor           = UIColor(red: 230/255, green: 230/255, blue: 230/255, alpha: 1)
        vwLine3.backgroundColor           = UIColor(red: 230/255, green: 230/255, blue: 230/255, alpha: 1)
        vwLine4.backgroundColor           = UIColor(red: 230/255, green: 230/255, blue: 230/255, alpha: 1)
    }
    
    func addElements2UI(){
        
        vwController.view.addSubview(vwMain)
        vwMain.addSubview(vwHeader)
        vwMain.addSubview(vwTopSection)
        vwMain.addSubview(vwMiddleSection)
        vwMain.addSubview(vwBottomSection)
        
        vwHeader.addSubview(btnXheader)
        vwHeader.addSubview(lblHeader)
        vwHeader.addSubview(btnHeaderRight)
        
        vwTopSection.addSubview(lblTopHeader)
        vwMiddleSection.addSubview(txtFirstName)
        vwMiddleSection.addSubview(txtLastName)
        vwMiddleSection.addSubview(vwLine1)
        vwMiddleSection.addSubview(txtEmail)
        vwMiddleSection.addSubview(vwLine2)
        vwMiddleSection.addSubview(txtMobile)
        vwMiddleSection.addSubview(vwLine3)
        vwMiddleSection.addSubview(txtLeadType)
        vwMiddleSection.addSubview(vwLine4)
        vwMiddleSection.addSubview(lblNotes)
        vwMiddleSection.addSubview(lblNotesLegend)
        vwMiddleSection.addSubview(lblFirstName)
        vwMiddleSection.addSubview(lblLastName)
        vwMiddleSection.addSubview(lblEmail)
        vwMiddleSection.addSubview(lblMobile)
        vwMiddleSection.addSubview(lblLeadType)
        
        vwBottomSection.addSubview(txtNotesLegend)
    }
    
    
    func back(){
        
        vwController.dismissViewControllerAnimated(true, completion: nil)
    }
    
}
