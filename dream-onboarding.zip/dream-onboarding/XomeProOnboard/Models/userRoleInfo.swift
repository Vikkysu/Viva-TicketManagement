//
//  userRoleInfo.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/11/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

public enum userType {
    case Agent, Broker, Consumer
}

public class userRoleInfo: NSObject {
    
    static let sharedInstance = userRoleInfo()
    
    static var userRoleState: userType? = userType.Broker
    
    static func setUserRole(role :userType) {
        userRoleState = role
    }
    
    static func getUserRole()->userType? {
        return userRoleState
    }
    
    static func getStepIndicationData(userTypeInfo: userType) -> NSArray {
        var stepDataArray: NSArray = []
        
        switch userTypeInfo {
        case .Agent:
            stepDataArray = ["PERSONAL", "PROFESSIONAL", "BRANDIT", "INVITES"]
        case .Broker:
            stepDataArray = ["BROKERAGE", "BRANDING", "BROKER", "INVITES"]
        case .Consumer:
            stepDataArray = ["BROKERAGE", "BRANDING", "BROKER", "INVITES"]
        }
        
        return stepDataArray
    }
}
