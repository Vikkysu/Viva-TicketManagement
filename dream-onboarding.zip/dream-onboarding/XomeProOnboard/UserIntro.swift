//
//  ViewController.swift
//  ProfessionalTools
//
//  Created by rluas on 9/18/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class UserIntro: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }
    


}

