//
//  FavoritePropertyListModel.swift
//  XomeRestClient
//
//  Created by Brendan Farrington on 2/4/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class FavoritePropertyListModel: Mappable {
    public var pagingId: String?
    public var pageIndex: Int?
    public var pageCount: Int?
    public var totalCount: Int?

    public var items = [FavoritePropertyModel]()

    public init() {

    }

    required public init?(_ map: Map) {

    }

    public func mapping(map: Map) {
        pagingId <- map["id"]
        pageIndex <- map["page"]
        pageCount <- map["pageCount"]
        totalCount <- map["totalCount"]
        items <- map["items"]
    }
}