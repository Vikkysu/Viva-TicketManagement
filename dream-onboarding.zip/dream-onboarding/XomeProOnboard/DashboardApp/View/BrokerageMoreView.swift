//
//  BrokerageMoreView.swift
//  ProfessionalTools
//
//  Created by Pike Dev 01 on 25/10/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class BrokerageMoreView: NSObject,UITableViewDelegate,UITableViewDataSource {

    var brokerageDataArray       :NSMutableArray!
    var vwController                    :UIViewController!
    var vwMain                            :UIView!
    var vwHeader                       : UIView!
    var tableView               : UITableView!
    var lblHeader                         : UILabel!
    var imgLeft                             : UIImageView!
    var imgRight                           :  UIImageView!
    var cgScreenWidth               :CGFloat!
    var cgScreenHeight              :CGFloat!
    
    
    
    
    func loadBrokerageMoreUI(inViewController :UIViewController, inDataArray :NSMutableArray){
        
        vwController                = inViewController
        brokerageDataArray    = inDataArray
        print(brokerageDataArray)
        getScreenDimensions()
        createUIElements()
        setProperties()
        setProfileData()
        addElements2UI()
    }
    
    
    func getScreenDimensions(){
        
        let screenDimensions = UIScreen.mainScreen().bounds
        cgScreenWidth        = screenDimensions.width
        cgScreenHeight       = screenDimensions.height
    }
    
    func centreX(inWidth: CGFloat)->CGFloat{
        
        let tWidth:CGFloat  = cgScreenWidth - CGFloat(inWidth)
        let pX: CGFloat     = tWidth/2
        
        return pX
    }
    
    func centreY(inHeight: CGFloat)->CGFloat{
        
        let tHeight:CGFloat  = cgScreenHeight - CGFloat(inHeight)
        let pY: CGFloat      = tHeight/2
        
        return pY
    }
    
    func convert2Pixels(points:CGFloat)->CGFloat{
        
        let pixels  :CGFloat = points * 96 / 72
        return pixels
    }
    
    func createUIElements(){
        
        let hdrVwHeight :CGFloat = self.convert2Pixels(65)
        let lblhX       :CGFloat = self.convert2Pixels(137)
        let lblhY      :CGFloat  = self.convert2Pixels(31)
        let lblhW       :CGFloat = self.convert2Pixels(42)
        let lblhH      :CGFloat = self.convert2Pixels(22)
        
        let imgLX       :CGFloat = self.convert2Pixels(16)
        let imgLY      :CGFloat  = self.convert2Pixels(27)
        let imgLW       :CGFloat = self.convert2Pixels(35)
        let imgLH      :CGFloat = self.convert2Pixels(35)
        
        let imgRX       :CGFloat = self.convert2Pixels(260)
        let imgRY      :CGFloat  = self.convert2Pixels(26)
        let imgRW       :CGFloat = self.convert2Pixels(35)
        let imgRH      :CGFloat = self.convert2Pixels(35)
        
        
        
        vwMain              = UIView(frame:CGRectMake(0, 0, cgScreenWidth, cgScreenHeight))
        vwHeader            = UIView(frame:CGRectMake(0, 0, cgScreenWidth, hdrVwHeight))
        tableView           = UITableView(frame: CGRectMake(0, hdrVwHeight+20, cgScreenWidth, cgScreenHeight-hdrVwHeight-10), style: UITableViewStyle.Grouped)
        lblHeader           = UILabel(frame: CGRectMake(lblhX, lblhY, lblhW, lblhH))
        imgLeft             = UIImageView(frame: CGRectMake(imgLX, imgLY, imgLW, imgLH))
        
        imgRight             = UIImageView(frame: CGRectMake(imgRX, imgRY, imgRW, imgRH))

    }
    
    func setProperties(){
        
        vwMain.backgroundColor          = UIColor(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
        vwHeader.backgroundColor        = UIColor(red: 217/255, green: 19/255, blue: 9/255, alpha: 1)
        tableView.dataSource         = self
        tableView.delegate           = self
        
        lblHeader.textColor             = UIColor.whiteColor()
        let headerFont      :UIFont     = UIFont(name: "MuseoSansRounded-300", size: 18.0)!
        lblHeader.font                  = headerFont
        lblHeader.text                  = "More"
        
        imgLeft.image       = UIImageCustom().getImageFromString("merdian.png")
        imgLeft.contentMode = UIViewContentMode.ScaleAspectFit
        
        let tapGestureRecognizer = UITapGestureRecognizer(target:self, action:Selector("profileView:"))
        imgLeft.userInteractionEnabled = true
        imgLeft.addGestureRecognizer(tapGestureRecognizer)

        imgRight.image     = UIImageCustom().getImageFromString("setting.png")
        imgRight.contentMode = UIViewContentMode.ScaleAspectFit

        
        
    }
    
    func profileView(img: AnyObject)
    {
        let brokerProfileView = ProfileViewController()
        
        vwController.presentViewController(brokerProfileView, animated: true, completion: nil)
    }
    
    func setProfileData(){
    }
    func addElements2UI(){
        
        vwController.view.addSubview(vwMain)
        vwMain.addSubview(vwHeader)
        vwHeader.addSubview(lblHeader)
        vwHeader.addSubview(imgLeft)
        vwHeader.addSubview(imgRight)

        vwMain.addSubview(tableView)
        
        
 
        
        
        
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return brokerageDataArray.count
    }
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        let datArray : NSMutableArray = brokerageDataArray.objectAtIndex(section) as! NSMutableArray
        return datArray.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat{
        return 44
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
        
        //variable type is inferred
        var cell = tableView.dequeueReusableCellWithIdentifier("CELL")
        
        if cell == nil {
            cell = UITableViewCell(style: UITableViewCellStyle.Value1, reuseIdentifier: "CELL")
            let typeIcon : UIImageView       = UIImageView(frame: CGRectMake(15, 5, 25, 25))
            typeIcon.contentMode = UIViewContentMode.ScaleAspectFit
            typeIcon.tag                     = 1
            
            let type  :UILabel               = UILabel(frame: CGRectMake(52, 10, 250, 20))
            type.textColor                   = UIColor(red: 51/255, green: 51/255, blue: 51/255, alpha: 1)
            type.font                        = UIFont(name: "MuseoSansRounded-500", size: 15.0)!
            type.tag                         = 2
            
            
            let checkMarkImg : UIImageView   = UIImageView(frame: CGRectMake(cgScreenWidth-45, 25, 10, 7))
            checkMarkImg.image               = UIImageCustom().getImageFromString("path17Copy6@3x.png")
            checkMarkImg.tag                 = 3
            
            cell?.addSubview(typeIcon)
            cell?.addSubview(type)
           // cell?.addSubview(checkMarkImg)
            
        }
        let datArray : NSMutableArray = brokerageDataArray.objectAtIndex(indexPath.section) as! NSMutableArray

        let currentDictionary : NSMutableDictionary = datArray.objectAtIndex(indexPath.row) as! NSMutableDictionary
        let typeIcon   :UIImageView = cell?.viewWithTag(1) as! UIImageView
        let type     :UILabel = cell?.viewWithTag(2) as! UILabel
        
        typeIcon.image  = UIImageCustom().getImageFromString(currentDictionary.objectForKey("imgName") as! String)
        type.text   = currentDictionary.objectForKey("name") as? String


        
        
        
        return cell!
    }

    
    
     func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerLbl = UILabel(frame: CGRectMake(10, 0, tableView.frame.size.width, 40))
        headerLbl.textColor = UIColor(red: 155/255, green: 155/255, blue: 155/255, alpha: 1)
        headerLbl.font                        = UIFont(name: "MuseoSansRounded-300", size: 15.0)!

        
        let datArray : NSMutableArray = brokerageDataArray.objectAtIndex(section) as! NSMutableArray
        let currentDictionary : NSMutableDictionary = datArray.objectAtIndex(0) as! NSMutableDictionary
        headerLbl.text  = currentDictionary.objectForKey("sectionName") as? String
        
        
        return headerLbl
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        let datArray : NSMutableArray = brokerageDataArray.objectAtIndex(section) as! NSMutableArray
        let currentDictionary : NSMutableDictionary = datArray.objectAtIndex(0) as! NSMutableDictionary
        let sectionName = currentDictionary.objectForKey("sectionName") as? String
        if sectionName == ""
        {
            return 0.0
        }
        else
        {
        return 40.0
        }
    }
    


    
    
    
    
}
