//
//  PropertyDetailsListingInfoModel.swift
//  XomeRestClient
//
//  Created by Vikas on 1/20/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation

public class PropertyDetailsListingInfoModel : PropertyDetailsSimpleInfoModel {
}