//
//  ACBrokerLicenseInfoTableViewCell.swift
//  ProfessionalTools
//
//  Created by Vikas on 9/30/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class ACBrokerLicenseInfoTableViewCell: UITableViewCell {
    
    var brokerLicenseStateInfo: UITextField!
    var brokerLicenseInfo: UITextField!
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String!)
    {
        super.init(style: UITableViewCellStyle.Value1, reuseIdentifier: reuseIdentifier)
        var labelTextBL : UILabel
        labelTextBL = UILabel()
        labelTextBL.numberOfLines=0
        labelTextBL.textAlignment = .Center
        labelTextBL.tag=50
        labelTextBL.backgroundColor=UIColor.clearColor()
        labelTextBL.font = UIFont(name: MuseoSansRounded100Font, size: 11.0)
        labelTextBL.text = "BROKERAGE LICENSE NUMBER"
        self.addSubview(labelTextBL)
        
        let textFieldBL : UITextField = UITextField()
        textFieldBL.font = UIFont(name: MuseoSansRounded100Font, size: 20.0)
        textFieldBL.tag=51
        textFieldBL.keyboardType = .Default
        self.addSubview(textFieldBL)
        brokerLicenseInfo = textFieldBL
        
        var labelTextState : UILabel
        labelTextState = UILabel()
        labelTextState.numberOfLines=0
        labelTextState.textAlignment = .Center
        labelTextState.tag=52
        labelTextState.text="STATE"
        labelTextState.backgroundColor=UIColor.clearColor()
        labelTextState.font = UIFont(name: MuseoSansRounded100Font, size: 11.0)
        self.addSubview(labelTextState)
        
        let textFieldState : UITextField = UITextField()
        textFieldState.font = UIFont(name: MuseoSansRounded100Font, size: 20.0)
        textFieldState.tag=53
        self.addSubview(textFieldState)
        brokerLicenseStateInfo = textFieldState
        
        let addLicenseInfo: UIButton = UIButton()
        addLicenseInfo.setBackgroundImage(UIImageCustom().getImageFromString("addLicense"), forState: UIControlState.Normal)
        addLicenseInfo.tag=54
        addLicenseInfo.hidden=true
        self.addSubview(addLicenseInfo)
        
        let separatorLine: UIView = UIView()
        separatorLine.backgroundColor = UIColor.baoTableBorderColor()
        self.addSubview(separatorLine)
        
        labelTextBL.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self).offset(5)
            make.leading.equalTo(self).offset(10)
            make.height.equalTo(25)
        }
        
        textFieldBL.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(labelTextBL).offset(20)
            make.centerX.equalTo(labelTextBL).offset(0)
            make.width.equalTo(labelTextBL)
            make.height.equalTo(30)
        }
        
        labelTextState.snp_makeConstraints { (make) -> Void in
            make.trailing.equalTo(labelTextBL).offset(50)
            make.top.equalTo(labelTextBL).offset(0)
            make.height.equalTo(25)
        }
        
        textFieldState.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(labelTextState).offset(20)
            make.centerX.equalTo(labelTextState).offset(0)
            make.width.equalTo(labelTextState)
            make.height.equalTo(30)
        }
        
        addLicenseInfo.snp_makeConstraints { (make) -> Void in
            make.width.equalTo(25)
            make.height.equalTo(24)
            make.trailing.equalTo(self).offset(-20)
            make.centerY.equalTo(labelTextState).offset(5)
        }
        
        separatorLine.snp_makeConstraints {(make) -> Void in
            make.bottom.equalTo(textFieldBL).offset(4)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-1)
            make.height.equalTo(1)
        }
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
