//
//  LeadDetailView.swift
//  DreamLeadInjection
//
//  Created by Developer on 22/10/15.
//  Copyright © 2015 Developer. All rights reserved.
//

import UIKit

class LeadDetailView: NSObject {

    var profileDataDictionary       :NSMutableDictionary!
    var vwController                :UIViewController!
    
    var vwMain                      :UIView!
    var vwHeader                    :UIView!
    var segOperations               :UISegmentedControl!
    var vwTopSection                :UIView!
    var vwBottomSection             :UIView!
    var vwFooter                    :UIView!
    
    var btnXheader                  :UIButton!
    var lblHeader                   :UILabel!
    var btnHeaderRight              :UIButton!
    
    var imgPropertyIcon             :UIImageView!
    var lblLeadName                 :UILabel!
    var lblLeadOwner                :UILabel!
    var lblSource                   :UILabel!
    
    var lblHeadType                 :UILabel!
    var lblHeadEmail                :UILabel!
    var lblHeadMobile               :UILabel!
    var lblHeadPropInt              :UILabel!
    
    var lblType                     :UILabel!
    var lblEmail                    :UILabel!
    var lblMobile                   :UILabel!
    var lblPropertyInterest         :UILabel!
    var btnInvite                   :UIButton!
    
    var vwOwnerImage                :UIImageView!
    var lblOwnerNoteHeader          :UILabel!
    var lblOwnerNote                :UILabel!
    var lblUpdated                  :UILabel!
    var lblVisibility               :UILabel!
    var imgVisibility               :UIImageView!
    
    var btnArchive                  :UIButton!
    var btnRefer                    :UIButton!
    
    var cgScreenWidth               :CGFloat!
    var cgScreenHeight              :CGFloat!
    
    func loadLeadDetailUI(inViewController :UIViewController, inDataDictionary :NSMutableDictionary){
        
        vwController            = inViewController
        profileDataDictionary   = inDataDictionary
        
        getScreenDimensions()
        createUIElements()
        setProperties()
        setProfileData()
        addElements2UI()
    }
    
    func getScreenDimensions(){
        
        let screenDimensions = UIScreen.mainScreen().bounds
        cgScreenWidth        = screenDimensions.width
        cgScreenHeight       = screenDimensions.height
    }
    
    func centreX(inWidth: CGFloat)->CGFloat{
        
        let tWidth:CGFloat  = cgScreenWidth - CGFloat(inWidth)
        let pX: CGFloat     = tWidth/2
        
        return pX
    }
    
    func centreY(inHeight: CGFloat)->CGFloat{
        
        let tHeight:CGFloat  = cgScreenHeight - CGFloat(inHeight)
        let pY: CGFloat      = tHeight/2
        
        return pY
    }
    
    func convert2Pixels(points:CGFloat)->CGFloat{
        
        let pixels  :CGFloat = points * 96 / 72
        return pixels
    }
    
    func createUIElements(){
        
        let hdrVwHeight :CGFloat = self.convert2Pixels(65)
        let hdrWidth    :CGFloat = self.convert2Pixels(80)
        let hdrHeight   :CGFloat = self.convert2Pixels(22)
        let hdRtWidth   :CGFloat = self.convert2Pixels(30)
        let hdRtHeight  :CGFloat = self.convert2Pixels(30)
        let hdRtX       :CGFloat = cgScreenWidth - hdRtWidth - 20 //constraint set to hdRtWidth
        let hdRTY       :CGFloat = self.convert2Pixels(31)
        let hdrX        :CGFloat = self.centreX(hdrWidth)
        let hdrY        :CGFloat = self.convert2Pixels(31)
        let segMenuItems         = ["Detail", "Activity"]
        let segWidth    :CGFloat = cgScreenWidth - 100 //constraint set to 100
        let segHeight   :CGFloat = self.convert2Pixels(30)
        let segX        :CGFloat = self.centreX(325)
        let segY        :CGFloat = hdrVwHeight+15
        let topY        :CGFloat = segY+segHeight+15
        let vwTopHeight  :CGFloat = self.convert2Pixels(290)
        let imgPrWidth  :CGFloat = self.convert2Pixels(68)
        let imgPrHeight :CGFloat = self.convert2Pixels(48)
        let imgPrX      :CGFloat = self.centreX(imgPrWidth)
        let imgPrY      :CGFloat = self.convert2Pixels(10)
        let lbLeadWidth :CGFloat = cgScreenWidth-10
        let lbLeadHeight:CGFloat = self.convert2Pixels(22)
        let leadY       :CGFloat = imgPrY+imgPrHeight+6
        let ownerHeight :CGFloat = self.convert2Pixels(16)
        let ownerY      :CGFloat = leadY+lbLeadHeight
        let srcY        :CGFloat = ownerY+ownerHeight
        let hTypeX      :CGFloat = self.convert2Pixels(12)
        let hTypeY      :CGFloat = self.convert2Pixels(100)
        let hTyWidth    :CGFloat = self.convert2Pixels(100)
        let hTyHeight   :CGFloat = self.convert2Pixels(12)
        let tyWidth     :CGFloat = self.convert2Pixels(100)
        let tyHeight    :CGFloat = self.convert2Pixels(19)
        let tyY         :CGFloat = hTypeY+hTyHeight+5
        let hEmY        :CGFloat = tyY+tyHeight+10
        let emY         :CGFloat = hEmY+hTyHeight+5
        let hMoY        :CGFloat = emY+tyHeight+10
        let moY         :CGFloat = hMoY+hTyHeight+5
        let hPoiY       :CGFloat = moY+tyHeight+10
        let poiY        :CGFloat = hPoiY+hTyHeight+5
        let botY        :CGFloat = topY+vwTopHeight+15
        let botWidth    :CGFloat = cgScreenWidth - 10
        let botHeight   :CGFloat = cgScreenHeight - hdrHeight - segHeight - vwTopHeight - 45
        let ftWidth     :CGFloat = botWidth
        let ftHeight    :CGFloat = self.convert2Pixels(40)
        let ftBtnWidth  :CGFloat = ftWidth/2
        let ftY         :CGFloat = cgScreenHeight - ftHeight
        let ownImgY     :CGFloat = 5
        let owmImgWidth :CGFloat = 34
        let ownNoHdrWidth   :CGFloat = 200
        let ownNoHdrHeight  :CGFloat = self.convert2Pixels(17)
        let ownNoteHdrX :CGFloat = owmImgWidth+10
        let ownNoteHdrY :CGFloat = ownImgY+((owmImgWidth-ownNoHdrHeight)/2)
        let noteY       :CGFloat = ownNoteHdrY+ownNoHdrHeight+20
        let noteHeight  :CGFloat = 50
        let notifyWidth :CGFloat = (cgScreenWidth-20)/2
        
        vwMain              = UIView(frame:CGRectMake(0, 0, cgScreenWidth, cgScreenHeight))
        vwHeader            = UIView(frame:CGRectMake(0, 0, cgScreenWidth, hdrVwHeight))
        btnXheader          = UIButton(frame:CGRectMake(0, hdrY, 33, 33))
        lblHeader           = UILabel(frame:CGRectMake(hdrX, hdrY, hdrWidth, hdrHeight))
        btnHeaderRight      = UIButton(frame:CGRectMake(hdRtX, hdRTY, hdRtWidth, hdRtHeight))

        segOperations       = UISegmentedControl(items: segMenuItems)
        segOperations.frame = CGRectMake(segX, segY	, segWidth, segHeight)
        
        vwTopSection        = UIView(frame:CGRectMake(5, topY, cgScreenWidth-10, vwTopHeight))
        imgPropertyIcon     = UIImageView(frame:CGRectMake(imgPrX, imgPrY, imgPrWidth, imgPrHeight))
        lblLeadName         = UILabel(frame:CGRectMake(0, leadY, lbLeadWidth, lbLeadHeight))
        lblLeadOwner        = UILabel(frame:CGRectMake(0, ownerY,lbLeadWidth, ownerHeight))
        lblSource           = UILabel(frame:CGRectMake(0, srcY,lbLeadWidth, ownerHeight))
        
        //headings and data fields
        lblHeadType         = UILabel(frame:CGRectMake(hTypeX, hTypeY,hTyWidth, hTyHeight))
        lblHeadEmail        = UILabel(frame:CGRectMake(hTypeX, hEmY,hTyWidth, hTyHeight))
        lblHeadMobile       = UILabel(frame:CGRectMake(hTypeX, hMoY,hTyWidth, hTyHeight))
        lblHeadPropInt      = UILabel(frame:CGRectMake(hTypeX, hPoiY,hTyWidth, hTyHeight))
        
        lblType             = UILabel(frame:CGRectMake(hTypeX, tyY,tyWidth, tyHeight))
        lblEmail            = UILabel(frame:CGRectMake(hTypeX, emY,tyWidth, tyHeight))
        lblMobile           = UILabel(frame:CGRectMake(hTypeX, moY,tyWidth, tyHeight))
        lblPropertyInterest = UILabel(frame:CGRectMake(hTypeX, poiY,cgScreenWidth-20, tyHeight))
        btnInvite           = UIButton(frame:CGRectMake(hTypeX, poiY+tyHeight+5, cgScreenWidth-40, ftHeight))
        vwBottomSection     = UIView(frame:CGRectMake(5, botY, botWidth, botHeight))
        vwFooter            = UIView(frame:CGRectMake(5, ftY, ftWidth, ftHeight))
        
        vwOwnerImage        = UIImageView(frame:CGRectMake(5, ownImgY, owmImgWidth, owmImgWidth))
        lblOwnerNoteHeader  = UILabel(frame:CGRectMake(ownNoteHdrX, ownNoteHdrY, ownNoHdrWidth, ownNoHdrHeight))
        lblOwnerNote        = UILabel(frame:CGRectMake(5, noteY, cgScreenWidth-20, noteHeight))

        lblUpdated          = UILabel(frame:CGRectMake(5, noteY+noteHeight+5, notifyWidth, 15))
        lblVisibility       = UILabel(frame:CGRectMake(notifyWidth+20, noteY+noteHeight+5, notifyWidth, 15))
        //imgVisibility       = UIImageView(frame:CGRectMake(notifyWidth+5, noteY+noteHeight+5, 20, 15))
        
        btnArchive          = UIButton(frame:CGRectMake(0, 0, ftBtnWidth, ftHeight))
        btnRefer            = UIButton(frame:CGRectMake(ftBtnWidth, 0, ftBtnWidth, ftHeight))
    }
    
    
    func setProperties(){

        let uiFont18        :UIFont = UIFont(name: "MuseoSansRounded-300", size: 18.0)!
        let uiFont16        :UIFont = UIFont(name: "MuseoSansRounded-300", size: 16.0)!
        let uiFont15        :UIFont = UIFont(name: "MuseoSansRounded-300", size: 15.0)!
        let uiFont14        :UIFont = UIFont(name: "MuseoSansRounded-300", size: 14.0)!
        let uiFont12        :UIFont = UIFont(name: "MuseoSansRounded-300", size: 12.0)!
        let uiFont11        :UIFont = UIFont(name: "MuseoSansRounded-300", size: 11.0)!
        let uiFont10        :UIFont = UIFont(name: "MuseoSansRounded-300", size: 10.0)!
        
        vwMain.backgroundColor          = UIColor(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
        
        //setup header
        vwHeader.backgroundColor        = UIColor(red: 217/255, green: 2/255, blue: 9/255, alpha: 1)
        let imgBtnImage     :UIImage    = UIImage(named:"btnSave3.png")!
        btnXheader.setImage(imgBtnImage, forState: .Normal)
        btnXheader.addTarget(self, action: Selector("back"), forControlEvents: UIControlEvents.TouchUpInside)
        
        lblHeader.text              = "Lead Detail"
 
        btnHeaderRight.setTitle("Edit", forState: .Normal)
        btnHeaderRight.addTarget(self, action: Selector("editLeadDetail"), forControlEvents: UIControlEvents.TouchUpInside)
        
        lblHeader.font              = uiFont18
        btnHeaderRight.titleLabel?.font         = uiFont15
        
        lblHeader.textColor         = UIColor.whiteColor()
        btnHeaderRight.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        
        //setup segmented menu
        segOperations.selectedSegmentIndex  = 0
        segOperations.tintColor             = UIColor(red: 217/255, green: 2/255, blue: 9/255, alpha: 1)
        segOperations.backgroundColor       = UIColor.whiteColor()
        
        //set top view
        vwTopSection.backgroundColor    = UIColor.whiteColor()
        let imgProperty :UIImage        = UIImage(named:"propertyIcon.png")!
        imgPropertyIcon.image           = imgProperty
        lblLeadName.textColor           = UIColor.blackColor()
        lblLeadOwner.textColor          = UIColor.blackColor()
        lblSource.textColor             = UIColor.blackColor()
        lblLeadName.font                = uiFont18
        lblLeadOwner.font               = uiFont12
        lblSource.font                  = uiFont12
        lblLeadName.textAlignment       = .Center
        lblLeadOwner.textAlignment      = .Center
        lblSource.textAlignment         = .Center
        
        //headings and data
        lblHeadType.text    = "TYPE"
        lblHeadEmail.text   = "EMAIL"
        lblHeadMobile.text  = "MOBILE NUMBER"
        lblHeadPropInt.text = "PROPERTY OF INTEREST"
        
        lblHeadType.textColor       = UIColor.lightGrayColor()
        lblHeadEmail.textColor      = UIColor.lightGrayColor()
        lblHeadMobile.textColor     = UIColor.lightGrayColor()
        lblHeadPropInt.textColor    = UIColor.lightGrayColor()
        
        lblHeadType.font    = uiFont10
        lblHeadEmail.font   = uiFont10
        lblHeadMobile.font  = uiFont10
        lblHeadPropInt.font = uiFont10
        
        lblType.textColor               = UIColor.blackColor()
        lblEmail.textColor              = UIColor.blackColor()
        lblMobile.textColor             = UIColor.blackColor()
        lblPropertyInterest.textColor   = UIColor.blackColor()
            
        lblType.font             = uiFont16
        lblEmail.font            = uiFont16
        lblMobile.font           = uiFont16
        lblPropertyInterest.font = uiFont16
        lblPropertyInterest.numberOfLines = 0
        
        btnInvite.backgroundColor = UIColor.redColor()
        btnInvite.setTitle("Invite", forState: .Normal)
        btnInvite.titleLabel?.textColor = UIColor.whiteColor()
        
        //setup bottom section
        vwBottomSection.backgroundColor = UIColor.whiteColor()
        vwOwnerImage.backgroundColor    = UIColor.grayColor()
//        vwOwnerImage
        lblOwnerNoteHeader.textColor    = UIColor.blackColor()
        lblOwnerNote.textColor          = UIColor.blackColor()
        lblOwnerNoteHeader.font         = uiFont14
        lblOwnerNote.font               = uiFont15
        lblOwnerNote.textAlignment      = .Left
        lblOwnerNote.numberOfLines      = 0

        lblUpdated.textColor    = UIColor.grayColor()
        lblVisibility.textColor = UIColor.grayColor()
        lblUpdated.font         = uiFont11
        lblVisibility.font      = uiFont11
        lblUpdated.textColor    = UIColor.grayColor()
        lblVisibility.textColor = UIColor.grayColor()
        lblVisibility.text      = "Not visible to your customer"
        //let imgEye     :UIImage = UIImage(named:"eyeVisibility.png")!
        //imgVisibility.image     = imgEye
       
        vwFooter.backgroundColor = UIColor(red: 245/255, green: 245/255, blue: 245/255, alpha: 1)
        btnArchive.setTitle ("Archive", forState: .Normal)
        btnRefer.setTitle("Reassign", forState: .Normal)
        btnArchive.setTitleColor(UIColor.redColor(), forState: .Normal)
        btnRefer.setTitleColor(UIColor.redColor(), forState: .Normal)
        btnArchive.titleLabel?.font  = uiFont15
        btnRefer.titleLabel?.font = uiFont15
        
        //debug section
        //vwBottomSection.backgroundColor=UIColor.blueColor()
        lblPropertyInterest.backgroundColor=UIColor.yellowColor()
        //lblOwnerNoteHeader.backgroundColor=UIColor.yellowColor()
        lblOwnerNote.backgroundColor=UIColor.yellowColor()
    }
    
    func setProfileData(){
        
        let strLeadName :String = profileDataDictionary.objectForKey("leadName") as! String
        let strOwner    :String = profileDataDictionary.objectForKey("leadOwner") as! String
        let strSource   :String = profileDataDictionary.objectForKey("leadSource") as! String
        
        lblLeadName.text    = strLeadName
        lblLeadOwner.text   = "Lead Owner: " + strOwner
        lblSource.text      = "Last Source:" + strSource
        
        lblType.text             = profileDataDictionary.objectForKey("leadType") as? String
        lblEmail.text            = profileDataDictionary.objectForKey("leadEmail") as? String
        lblMobile.text           = profileDataDictionary.objectForKey("leadMobile") as? String
        lblPropertyInterest.text = profileDataDictionary.objectForKey("leadPOI") as? String
        
//        vwOwnerImage    
        lblOwnerNoteHeader.text = strLeadName + "'s Note"
        lblOwnerNote.text       = profileDataDictionary.objectForKey("ownerNote") as? String
        let updateText :String  = profileDataDictionary.objectForKey("updated") as! String
        lblUpdated.text         = "Updated " + updateText
        
//        lblVisibility
    }
    
    func addElements2UI(){
        
        vwController.view.addSubview(vwMain)
        vwMain.addSubview(vwHeader)
        vwMain.addSubview(segOperations)
        vwMain.addSubview(vwTopSection)
        vwMain.addSubview(vwBottomSection)
        vwMain.addSubview(vwFooter)
        
        vwHeader.addSubview(btnXheader)
        vwHeader.addSubview(lblHeader)
        vwHeader.addSubview(btnHeaderRight)

        vwTopSection.addSubview(imgPropertyIcon)
        vwTopSection.addSubview(lblLeadName)
        vwTopSection.addSubview(lblLeadOwner)
        vwTopSection.addSubview(lblSource)
        
        vwTopSection.addSubview(lblHeadType)
        vwTopSection.addSubview(lblHeadEmail)
        vwTopSection.addSubview(lblHeadMobile)
        vwTopSection.addSubview(lblHeadPropInt)
        vwTopSection.addSubview(lblType)
        vwTopSection.addSubview(lblEmail)
        vwTopSection.addSubview(lblMobile)
        vwTopSection.addSubview(lblPropertyInterest)
        vwTopSection.addSubview(btnInvite)
        
        vwBottomSection.addSubview(vwOwnerImage)
        vwBottomSection.addSubview(lblOwnerNoteHeader)
        vwBottomSection.addSubview(lblOwnerNote)
        vwBottomSection.addSubview(lblUpdated)
        //vwBottomSection.addSubview(imgVisibility)
        vwBottomSection.addSubview(lblVisibility)
        
        vwFooter.addSubview(btnArchive)
        vwFooter.addSubview(btnRefer)

    }
    
    func back(){

        print("close lead detail view...")
        vwController.dismissViewControllerAnimated(true, completion: nil)
    }
    
    func editLeadDetail() {
        
        print ("edit lead detail...")
        let editDetailObject = BrokerEditLeadViewController()
        
        vwController.presentViewController(editDetailObject, animated: true, completion: nil)
    }
    
}
