//
//  DPBrandingReviewMainHeader.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/8/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrandingReviewMainHeader: UIView {
    
    init(rect: CGRect) {
        let screenRect: CGRect = UIScreen.mainScreen().bounds //[[UIScreen mainScreen] bounds];
        let screenWidth: CGFloat = screenRect.size.width;

        super.init(frame: CGRectMake(0, 68, screenWidth, 70))
    }
    
    func displayHeaderView() -> DPBrandingReviewMainHeader
    {
        self.backgroundColor = UIColor.whiteColor()
        
        var labelText : UILabel
        labelText = UILabel()
        labelText.numberOfLines=0
        labelText.textAlignment = .Center
        labelText.text="Almost Done!"
        labelText.backgroundColor=UIColor.clearColor()
        labelText.font = UIFont(name: MuseoSansRounded100Font, size: 20.0)
        self.addSubview(labelText)
        
        var labelSubText : UILabel
        labelSubText = UILabel()
        labelSubText.numberOfLines=0
        labelSubText.textAlignment = .Center
        labelSubText.text="Review and submit your information."
        labelSubText.backgroundColor=UIColor.clearColor()
        labelSubText.font = UIFont(name: MuseoSansRounded100Font, size: 15.0)
        self.addSubview(labelSubText)
        
//        let separatorLine: UIView = UIView()
//        separatorLine.backgroundColor = UIColor.baoTableBorderColor()
//        self.addSubview(separatorLine)
        
        labelText.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self).offset(10)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
        }
        
        labelSubText.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(labelText).offset(30)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
        }
        
//        separatorLine.snp_makeConstraints {(make) -> Void in
//            make.bottom.equalTo(labelSubText).offset(4)
//            make.leading.equalTo(self).offset(10)
//            make.trailing.equalTo(self).offset(-1)
//            make.height.equalTo(1)
//        }
        
        return self
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }    
}
