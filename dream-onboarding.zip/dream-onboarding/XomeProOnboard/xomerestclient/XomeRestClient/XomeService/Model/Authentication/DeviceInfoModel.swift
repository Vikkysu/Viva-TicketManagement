//
//  DeviceInfoModel.swift
//  XomeRestClient
//
//  Created by Brendan Farrington on 1/27/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class DeviceInfoModel: Mappable {
    public var deviceType: NSNumber = 1
    public var id: String?

    public init() {

    }

    required public init?(_ map: Map) {

    }

    public func mapping(map: Map) {
        deviceType <- map["deviceType"]
        id <- map["id"]
    }
}