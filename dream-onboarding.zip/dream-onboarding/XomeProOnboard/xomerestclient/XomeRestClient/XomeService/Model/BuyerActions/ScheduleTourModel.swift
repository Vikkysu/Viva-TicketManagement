//
//  ScheduleTourModel.swift
//  XomeRestClient
//
//  Created by Brendan Farrington on 2/29/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper


public class ScheduleTourModel: Mappable {
    public var listingId: String?
    public var personId: String?
    public var firstName: String?
    public var lastName: String?
    public var phone: String?
    public var comments: String?
    public var startDate: NSDate?
    public var endDate: NSDate?

    public init() {

    }

    required public init?(_ map: Map) {

    }

    public func mapping(map: Map) {
        listingId <- map["listingId"]
        personId <- map["personId"]
        firstName <- map["firstName"]
        lastName <- map["lastName"]
        phone <- map["phone"]
        comments <- map["comments"]
        let dateTransform = ISO8601DateTransform()
        startDate <- (map["startDate"], dateTransform)
        endDate <- (map["endDate"], dateTransform)
    }
}
