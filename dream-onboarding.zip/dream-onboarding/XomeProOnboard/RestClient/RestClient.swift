import Foundation
import SwiftyJSON

final class RestClient {
    typealias QueryParam = (name: String, val: String)
    typealias QueryParams = [QueryParam]
    typealias Callback = (JSON, NSError?) -> ()

    private unowned let env: Env
    private let session: NSURLSession

    init(env: Env) {
        self.env = env

        // session init
        let config = NSURLSessionConfiguration.defaultSessionConfiguration()
        let headers = [
            "Content-Type": "application/json",
            "Accept": "application/json",
            "X-RED-APIKey": env.apiKey,
        ]
        config.HTTPAdditionalHeaders = headers
        
        self.session = NSURLSession(configuration: config)
    }
    
    // MARK: GET

    func get(path: String, params: QueryParams, cb: Callback) {
        get(env.apiUrl, path: path, params: params, cb: cb)
    }

    func get(url: String, path: String, params: QueryParams, cb: Callback) {
        
        func call(cb: Callback, json: JSON, error: NSError?) {
            dispatch_async(dispatch_get_main_queue()) {
                cb(json, error)
            }
        }
        
        let urlComp = NSURLComponents(string: url)!
        urlComp.path = path
        urlComp.query = queryString(params)

        session.dataTaskWithURL(urlComp.URL!) { data, response, error in
            
            let json = JSON(data: data!)

            if error != nil {
                print("restclient error: \(error) response: \(response) json: \(json)")
                call(cb, json: json, error: error)
                return
            }
            
            if let r = response, e = self.validate(r) {
                print("restclient error: \(e) response: \(response) json: \(json)")
                call(cb, json: json, error: e)
                return
            }
            call(cb, json: json, error: error)
        }.resume()
    }


    // MARK: POST
    
    func post(path: String, params: QueryParams?, body: JSON, cb: Callback) {

        func call(cb: Callback, json: JSON, error: NSError?) {
            dispatch_async(dispatch_get_main_queue()) {
                cb(json, error)
            }
        }
        
        let urlComp = NSURLComponents(string: env.apiUrl)!
        urlComp.path = path
        urlComp.query = queryString(params)

        let request = NSMutableURLRequest()
        request.URL = urlComp.URL!
        request.HTTPMethod = "POST"
        request.HTTPBody = try? body.rawData()
        
        session.dataTaskWithRequest(request) { data, response, error in

            let json = JSON(data: data!)
            
            if error != nil {
                call(cb, json: json, error: error)
                return
            }
            
            if let r = response, e = self.validate(r) {
                call(cb, json: json, error: e)
                return
            }
            
            call(cb, json: json, error: nil)
        }.resume()
    }
    
    // MARK: private

    private func queryString(params: QueryParams?) -> String? {
        if let ps = params {
            let query = ps.map() { p in "\(p.name)=\(p.val)" }
            return query.joinWithSeparator("&")
        }

        return nil
    }
    
    private func validate(response: NSURLResponse) -> NSError? {

        if !(response is NSHTTPURLResponse) {
            let info = [NSLocalizedDescriptionKey: "Invalid response type."]
            return NSError(domain: "com.xome.api.error", code: 0, userInfo: info)
        }
        
        if let r = response as? NSHTTPURLResponse {
            if !(200..<300 ~= r.statusCode) {
                let info = [NSLocalizedDescriptionKey: "Invalid response status code."]
                return NSError(domain: "com.xome.api.error", code: r.statusCode, userInfo: info)
            }
        }
        
        return nil
    }
}
