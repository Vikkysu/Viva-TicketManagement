//
//  FavoritePropertyModel.swift
//  XomeRestClient
//
//  Created by Vikas on 1/21/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class FavoritePropertyModel : Mappable {
    public var listingKey: String?
    public var originatedByAgent: Bool?
    public var doCcAgent: Bool?
    public var contactKey: String?
    public var savedPropertyKey: String?
    public var creationTime: NSDate?
    public var lastModificationTime: NSDate?
    public var propertyDetails: PropertyModel?

    public required init?(_ map: Map) {
    }

    public func mapping(map: Map) {
        listingKey <- map["listingKey"]
        originatedByAgent <- map["originatedByAgent"]
        doCcAgent <- map["doCcAgent"]
        contactKey <- map["contactKey"]
        savedPropertyKey <- map["savedPropertyKey"]
        propertyDetails <- map["propertyDetails"]

        let dateTransform = ISO8601DateTransform()
        creationTime <- (map["createdDtm"], dateTransform)
        lastModificationTime <- (map["modifiedDtm"], dateTransform)
    }
}
