//
//  PasscodeManager.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/21/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import Security

public final class PasscodeManager {
    public let sharedManager = PasscodeManager()
    
    private struct Constants {
        /** Max digits for passcode */
        static let MaxPasscodeLength = 4
        /** Min digits for passcode */
        static let MinPasscodeLength = 4
        /** Keychain Passcode Key */
        static let KeychainPasscodeKey = "AppPasscode"
        /** Error prefix name */
        static let ErrorPrefixName = "PasscodeManager"
    }
    
    /** Passcode creation errors */
    public enum PasscodeError:ErrorType {
        /** The passcode string is less than the minimum length */
        case PasscodeTooShort
        /** The passcode string is more than the maximum length */
        case PasscodeTooLong
        /** The passcode string contains non numeric characters */
        case PasscodeNotNumeric
        
        public var description:String {
            var errorName = ""
            switch self {
            case .PasscodeTooShort:
                errorName = "The passcode is too short"
            case .PasscodeTooLong:
                errorName = "The passcode is too long"
            case .PasscodeNotNumeric:
                errorName = "The passcode must contain numbers only (0-9)"
            }
            return "\(Constants.ErrorPrefixName) - \(errorName)"
        }
    }
    
    /** Passcode Manager errors */
    public enum ManagerError:ErrorType {
        /** Wrong passcode */
        case InvalidPasscode
        /** The app is still locked, unlock the PasscodeManager first and try again */
        case Locked
        /** KeychainServices reported an error saving a new passcode */
        case FailedToSaveInKeychain(code:OSStatus)
        /** KeychainServices reported an error reading a passcode */
        case FailedToReadFromKeychain(code:OSStatus)
        /** No passcode is set */
        case NoPasscode

        
        public var description:String {
            var errorName = ""
            switch self {
            case .Locked:
                errorName = "Please enter your passcode to unlock and try again."
            case .InvalidPasscode:
                errorName = "The passcode is invalid, please try again"
            case .FailedToSaveInKeychain(let code):
                errorName = "Failed to save passcode to Keychain, error \(code)"
            case .FailedToReadFromKeychain(let code):
                errorName = "Failed to read passcode from Keychain, error \(code)"
            case .NoPasscode:
                errorName = "No passcode set"
            }
            return "\(Constants.ErrorPrefixName) - \(errorName)"
        }
    }
    
    /** Whether the manager is currently locked or not */
    public private (set)  var locked = true
    
    /**
    Add a new passcode, replacing any previous. The manager must currently be unlocked.
    :param: passcode The new passcode to add, only succeeds when validated (numeric only, must be 4 digits)
    */
    public func add(passcode:String) throws {
        // the manager must be unlocked before adding a new passcode
        guard !self.locked else {
            throw ManagerError.Locked
        }
        
        do {
            // make sure the new passcode meets validation
            try validate(passcode)
            
            do {
                // save it in the keychain
                try KeychainService.save(Constants.KeychainPasscodeKey, data: passcode.dataUsingEncoding(NSUTF8StringEncoding)!)
            } catch let status as OSStatus {
                let error = ManagerError.FailedToSaveInKeychain(code: status)
                #if DEBUG
                    print(error.description)
                #endif
                throw error
            }
            
        } catch let error as PasscodeError{
            throw error
        }
    }
    
    /**
    Validate a new passcode against passcode requirements
    
    - parameter newPasscode: The new passcode to be validated
    - throws: PasscodeManagerError- PasscodeTooShort, PasscodeTooLong, or PasscodeNotNumeric
    */
    private func validate(newPasscode:String) throws {
        // code should not be more than the the max
        guard newPasscode.characters.count <= Constants.MaxPasscodeLength else {
            let error = PasscodeError.PasscodeTooLong
            #if DEBUG
            print(error.description)
            #endif
            throw error
        }
        // code should be at least the min length
        guard newPasscode.characters.count >= Constants.MinPasscodeLength else {
            let error = PasscodeError.PasscodeTooShort
            #if DEBUG
            print(error.description)
            #endif
            throw error
        }
        
        // code should be numeric only
        guard Int(newPasscode) != nil else {
            let error = PasscodeError.PasscodeNotNumeric
            #if DEBUG
            print(error.description)
            #endif
            throw error
        }
    }
    
    /** Lock the manager */
    public func lock() {
        locked = true
    }
    
    /**
    Unlock the passcode
    
    - parameter passcode: The passcode to attempt unlock with
    - throws: ManagerError.NoPasscode if no passcode has been saved, or ManagerError.FailedToReadFromKeychain(code)
    */
    public func unlock(passcode:String) throws {
        do {
            // load the existing passcode
            let code = try KeychainService.load(Constants.KeychainPasscodeKey)
            // unlock if matching
            guard code == passcode else {
                throw ManagerError.InvalidPasscode
            }
            self.locked = false
            
        } catch let error as OSStatus {
            switch error {
            case errSecItemNotFound:
                throw ManagerError.NoPasscode
            default:
                throw ManagerError.FailedToReadFromKeychain(code: error)
            }
        }
    }
}
