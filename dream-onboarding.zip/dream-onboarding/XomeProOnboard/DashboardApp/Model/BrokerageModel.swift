//
//  BrokerageModel.swift
//  ProfessionalTools
//
//  Created by Pike Dev 01 on 25/10/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class BrokerageModel: NSObject {

}
