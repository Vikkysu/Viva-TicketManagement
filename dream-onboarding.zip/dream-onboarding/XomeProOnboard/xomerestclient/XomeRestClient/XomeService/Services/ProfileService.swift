//
//  ProfileService.swift
//  XomeRestClient
//
//  Created by David Parton on 1/14/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import PromiseKit
import ObjectMapper

public extension XomeService {
    public func profile() -> Promise<ProfileModel> {
        return operationFactory.promise(.GET, path: "contacts", queryParameters: nil, bodyData: nil)
    }
}
