//
//  PropertyWalkscoreModel.swift
//  XomeRestClient
//
//  Created by David Parton on 1/19/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public struct PropertyWalkScoreModel : Mappable {
    public var score: Int
    public var description: String

    public init?(_ map: Map) {
        score = map["walkscore"].valueOrFail()
        description = map["description"].valueOrFail()
        if !map.isValid {
            return nil
        }
    }

    public mutating func mapping(map: Map) {
        score <- map["walkscore"]
        description <- map["description"]
    }
}

