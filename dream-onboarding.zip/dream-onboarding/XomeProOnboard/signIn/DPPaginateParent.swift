//
//  DPPaginateParent.swift
//  ProfessionalTools
//
//  Created by Vikas on 9/24/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import UIKit

public
class DPPaginateParent :UIViewController,UIPageViewControllerDataSource,UIScrollViewDelegate,UIPageViewControllerDelegate {
    var pageViewController:UIPageViewController!
    var pageTitles:NSArray!
    var pageImages:NSArray!
    @IBOutlet weak var signInBtn:UIButton!
    @IBOutlet weak var infoLbl:UILabel!
    @IBOutlet weak var lapsePageControl: UIPageControl!
    @IBOutlet weak var signUpBtn: UIButton!
    


    var headerTextArr = ["WELCOME TO XOME PRO", "STAY CONNECTED", "FROM SEARCH & DISCOVERY TO OFFER & CLOSE", " "]
    
    @IBOutlet weak var headerText: UILabel!
    
    override public func viewDidLoad() {
        super.viewDidLoad()

        self.pageTitles = NSArray(objects:"Bringing real estate professionals and their clients together online, finally.","Collaborate with your clients. Create property collections together, schedule tours and set automatic notifications.","XomePro is an amazing resource that provides transactional and support services, from pre-open to post-close.","Login or signup below")

        
        self.pageViewController = self.storyboard?.instantiateViewControllerWithIdentifier("DPPaginate") as! DPPaginate
        self.lapsePageControl.numberOfPages = self.pageTitles.count
        self.lapsePageControl.currentPage = 0
        
        self.pageViewController.delegate = self
        self.pageViewController.dataSource = self
        
        
        let startVC = self.viewControllerAtIndex(0) as DPUserIntro
        
        let viewControllers = NSArray(objects:  startVC)
        
        
        self.pageViewController.setViewControllers(viewControllers as? [UIViewController], direction: .Forward, animated: true, completion: nil)
        
        self.pageViewController.view.frame = CGRectMake(0, 0,self.view.frame.size.width, self.view.frame.size.height + 37)
        
        self.addChildViewController(self.pageViewController)
        
        self.view.addSubview(self.pageViewController.view)
        
        self.pageViewController.didMoveToParentViewController(self)
        
        
        for view in self.pageViewController.view.subviews {
            if let scrollView = view as? UIScrollView {
                scrollView.delegate = self
            }
        }
        self.view.bringSubviewToFront(self.infoLbl)
        self.infoLbl.text = self.pageTitles[0] as? String
        self.view.bringSubviewToFront(self.lapsePageControl)
        self.view.bringSubviewToFront(self.signInBtn)
        self.view.bringSubviewToFront(self.signUpBtn)
    }
    
    override public func preferredStatusBarStyle() -> UIStatusBarStyle {
        return UIStatusBarStyle.LightContent
    }
    
    func viewControllerAtIndex(index:Int) -> DPUserIntro
    {
        if(self.pageTitles.count == 0) || (index >= self.pageTitles.count)
        {
            return DPUserIntro()
        }
        
        let vc:DPUserIntro = self.storyboard!.instantiateViewControllerWithIdentifier("newUser") as! DPUserIntro
        

        vc.pageIndex = index
        return vc
        
    }
    
    public func loginDisplay() {
        let loginView:DPloginViewController =  DPloginViewController()
        loginView.delegateParent = self
        self.presentViewController(loginView, animated: true, completion: nil)
    }

    public func signUpDisplay() {
        let signUpView:DPSignInViewController =  DPSignInViewController()
        signUpView.delegateParent = self
        self.presentViewController(signUpView , animated: true, completion: nil)
    }
    
    @IBAction func sendToLogin(sndr:AnyObject)
    {
        loginDisplay()
    }
    
    @IBAction func sendToSignup(sndr:AnyObject)
    {
        signUpDisplay()
    }
    
    public func pageViewController(pageViewController:UIPageViewController, viewControllerBeforeViewController viewController:UIViewController) -> UIViewController?
    {
        let vc = viewController as! DPUserIntro
        var index = vc.pageIndex as Int
        
        if(index == 0) || (index == NSNotFound)
        {
            return nil
        }
        
        self.lapsePageControl.currentPage = index
        index--
        
        return self.viewControllerAtIndex(index)

    }
    
    public func pageViewController(pageViewController: UIPageViewController, viewControllerAfterViewController viewController: UIViewController) -> UIViewController? {
        let vc = viewController as! DPUserIntro
        var index = vc.pageIndex as Int
        
        if(index == NSNotFound)
        {
            return nil
        }
        
        self.lapsePageControl.currentPage = index
        index++
        
        if(index == self.pageTitles.count)
        {
            return nil
        }
        return self.viewControllerAtIndex(index)
        
    }
    
    public func presentationCountForPageViewController(pageViewController: UIPageViewController) -> Int {
        return self.pageTitles.count
    }
    
    public func presentationIndexForPageViewController(pageViewController: UIPageViewController) -> Int {
        return 0
    }
    
    public func pageViewController(DPUserIntro: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        let subviews:Array = self.pageViewController.view.subviews
        var pgCntrl:UIPageControl! = nil
        
        for(var i=0;i < subviews.count;i++)
        {
            if(subviews[i] is UIPageControl)
            {
                pgCntrl = subviews[i] as! UIPageControl
                self.lapsePageControl.currentPage = pgCntrl.currentPage
                
            }
        }
        
        self.infoLbl.text = self.pageTitles[pgCntrl.currentPage] as? String
        self.headerText.text = self.headerTextArr[pgCntrl.currentPage]
    }
    
    
}
