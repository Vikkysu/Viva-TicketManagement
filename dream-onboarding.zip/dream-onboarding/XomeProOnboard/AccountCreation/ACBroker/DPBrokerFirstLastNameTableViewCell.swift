//
//  DPBrokerFirstLastNameTableViewCell.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/15/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrokerFirstLastNameTableViewCell: UITableViewCell {
    override init(style: UITableViewCellStyle, reuseIdentifier: String!)
    {
        super.init(style: UITableViewCellStyle.Value1, reuseIdentifier: reuseIdentifier)
        var labelText : UILabel
        labelText = UILabel()
        labelText.textAlignment = .Left
        labelText.text = "FIRST NAME"
        labelText.tag=140
        labelText.font = UIFont(name: MuseoSansRounded100Font, size: 11.0)
        self.addSubview(labelText)
        
        let textField : UITextField = UITextField()
        textField.font = UIFont(name: MuseoSansRounded100Font, size: 20.0)
        textField.tag=141
        self.addSubview(textField)
        
        var labelTextState : UILabel
        labelTextState = UILabel()
        labelTextState.textAlignment = .Left
        labelTextState.tag=142
        labelTextState.text = "LAST NAME"
        labelTextState.font = UIFont(name: MuseoSansRounded100Font, size: 11.0)
        self.addSubview(labelTextState)
        
        let textFieldState : UITextField = UITextField()
        textFieldState.font = UIFont(name: MuseoSansRounded100Font, size: 20.0)
        textFieldState.tag=143
        self.addSubview(textFieldState)
        
        let separatorLine: UIView = UIView()
        separatorLine.backgroundColor = UIColor.baoTableBorderColor()
        self.addSubview(separatorLine)
        
        var labelTextEmail : UILabel
        labelTextEmail = UILabel()
        labelTextEmail.textAlignment = .Left
        labelTextEmail.tag=144
        labelTextEmail.text = "EMAIL"
        labelTextEmail.font = UIFont(name: MuseoSansRounded100Font, size: 11.0)
        self.addSubview(labelTextEmail)
        
        let textFieldEmail : UITextField = UITextField()
        textFieldEmail.keyboardType = .EmailAddress
        textFieldEmail.font = UIFont(name: MuseoSansRounded100Font, size: 20.0)
        textFieldEmail.tag=145
        self.addSubview(textFieldEmail)
        
        let separatorLine1: UIView = UIView()
        separatorLine1.backgroundColor = UIColor.baoTableBorderColor()
        self.addSubview(separatorLine1)
        
        var labelTextMobile : UILabel
        labelTextMobile = UILabel()
        labelTextMobile.textAlignment = .Left
        labelTextMobile.tag=146
        labelTextMobile.text = "MOBILE NUMBER"
        labelTextMobile.font = UIFont(name: MuseoSansRounded100Font, size: 11.0)
        self.addSubview(labelTextMobile)
        
        let textFieldMobile : UITextField = UITextField()
        textFieldMobile.font = UIFont(name: MuseoSansRounded100Font, size: 20.0)
        textFieldMobile.keyboardType = .PhonePad
        textFieldMobile.tag=147
        self.addSubview(textFieldMobile)
        
        let separatorLine2: UIView = UIView()
        separatorLine2.backgroundColor = UIColor.baoTableBorderColor()
        self.addSubview(separatorLine2)
        
        labelTextState.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self).offset(5)
            make.centerX.equalTo(self).offset(0)
            make.height.equalTo(25)
        }
        
        textFieldState.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(labelTextState).offset(20)
            make.leading.equalTo(labelTextState).offset(0)
            make.trailing.equalTo(self).offset(-10)
            make.height.equalTo(30)
        }
        
        labelText.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self).offset(5)
            make.leading.equalTo(self).offset(10)
            make.height.equalTo(25)
        }
        
        textField.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(labelText).offset(20)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(textFieldState).offset(10)
            make.height.equalTo(30)
        }
        
        separatorLine.snp_makeConstraints {(make) -> Void in
            make.bottom.equalTo(textField).offset(4)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
            make.height.equalTo(1)
        }
        
        labelTextEmail.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(separatorLine).offset(5)
            make.leading.equalTo(self).offset(10)
            make.height.equalTo(25)
        }
        
        textFieldEmail.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(labelTextEmail).offset(20)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
            make.height.equalTo(30)
        }
        
        separatorLine1.snp_makeConstraints {(make) -> Void in
            make.bottom.equalTo(textFieldEmail).offset(4)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
            make.height.equalTo(1)
        }

        labelTextMobile.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(separatorLine1).offset(5)
            make.leading.equalTo(self).offset(10)
            make.height.equalTo(25)
        }
        
        textFieldMobile.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(labelTextMobile).offset(20)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
            make.height.equalTo(30)
        }
        
        separatorLine2.snp_makeConstraints {(make) -> Void in
            make.bottom.equalTo(textFieldMobile).offset(4)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
            make.height.equalTo(1)
        }

    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setSelected(selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
    
}
