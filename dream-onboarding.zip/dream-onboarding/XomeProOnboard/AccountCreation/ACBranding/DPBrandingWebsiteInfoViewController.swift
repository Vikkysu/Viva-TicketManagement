//
//  DPBrandingWebsiteInfoViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/9/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrandingWebsiteInfoViewController: DPAccountCreationBaseViewController {
    override func nextViewC1(sender: UIBarButtonItem) {
        
        print(self.childViewControllers)
        let accountViewCntrl = self.childViewControllers[0] as! DPBrandingWebsiteInfoTableViewController
        if accountViewCntrl.setDataFields() == true {
            let nextViewController: DPBrandingStep2BioViewController = DPBrandingStep2BioViewController()
            nextViewController.eState = flowState.BROKERAGE
            self.navigationItem.backBarButtonItem?.title = " "
            self.navigationController?.pushViewController(nextViewController, animated: true)
        }
    }
    
    func closeView(sender: UIBarButtonItem) {
        self.dismissViewControllerAnimated(true, completion: nil);
    }
    
    override func skipViewC1(sender: UIBarButtonItem) {
        print(self.childViewControllers)
        let nextViewController: DPBrandingStep2BioViewController = DPBrandingStep2BioViewController()
        self.navigationItem.backBarButtonItem?.title = " "
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
    override func viewWillAppear(animated: Bool) {
        [self.setNavigationPreferences(UIColor.baoPrimaryColor())]
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.navigationItem.title = "Branding"
        
        self.view.backgroundColor = UIColor.lightGrayColor()
        
        let tablecontr: DPBrandingWebsiteInfoTableViewController = DPBrandingWebsiteInfoTableViewController()
        self.addChildViewController(tablecontr)
        self.view.addSubview(tablecontr.view)
        tablecontr.didMoveToParentViewController(self)
        
        tablecontr.view.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self.view).offset(138)
            make.leading.equalTo(self.view).offset(5)
            make.trailing.equalTo(self.view).offset(-5)
            make.bottom.equalTo(self.view).offset(-5)
        }
        self.setStepIndication(tagStep1, state: 5)
        self.setStepIndication(tagStep2, state: 2)
        
        self.createSkipbutton()

        let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
        if let brokerBrandingWebsiteInfo: DPBrandingWebsiteAddrObj = brokerOnboardingInfo.loadBrokerageBrandingWebsiteObjectWithKey() {
            if brokerBrandingWebsiteInfo.websiteAddressStr!.isEmpty || brokerBrandingWebsiteInfo.websiteAddressStr == " " {
                self.createSkipbutton()
            }
            else {
                self.createNextbutton(NEXTBUTTON)
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
