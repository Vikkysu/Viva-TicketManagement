//
//  DPUserIntro.swift
//  ProfessionalTools
//
//  Created by Vikas on 9/24/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import UIKit

class DPUserIntro : UIViewController
{
    @IBOutlet weak var titleLabel:UILabel!
    @IBOutlet weak var swipeImage:UIImageView!
    
    
    var pageIndex:Int!
    var titleText:String!
    var imageFile:String!
    
    
    var pageTitles:NSArray!
    var pageImages:NSArray!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    
}
