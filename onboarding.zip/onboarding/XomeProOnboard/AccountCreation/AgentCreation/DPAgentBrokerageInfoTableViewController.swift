//
//  DPAgentBrokerageInfoTableViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/24/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPAgentBrokerageInfoTableViewController: UITableViewController, UITextFieldDelegate {
    var brokerNameTextField: UITextField!
    var brokerageEmailAddField: UITextField!
    var brokerPhoneTextField: UITextField!
    var brokerAddressTextField: UITextField!
    var brokerAddressOptTextField: UITextField?
    var brokerCityTextField: UITextField!
    var brokerStateTextField: UITextField!
    var brokerZipCodeTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        tableView.delegate=self
        tableView.dataSource=self
        tableView.showsHorizontalScrollIndicator=false
        tableView.showsVerticalScrollIndicator=false
        tableView.separatorStyle = .None
        tableView.registerClass(ACBrokerageStep1HeaderCell.self, forCellReuseIdentifier: "reuseIdentifier")
        tableView.registerClass(ACBrokerageTextCell.self, forCellReuseIdentifier: "textHeader")
        tableView.registerClass(ACBrokerageCityStateCellView.self, forCellReuseIdentifier: "ACBrokerageCityStateCellView1")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Tableview delegates
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 7
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 100
        }
        return 60
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        // fill the fields if saved offline
        let brokerOnboardingInfo: DPAgentOnBoardingModel = DPAgentOnBoardingModel.sharedInstance
        
        let brokerObj: DPBrokeragePersonalInfoObj? = brokerOnboardingInfo.getProfileInfo()
        
        
        if(indexPath.row == 0)
        {
            let cell: ACBrokerageStep1HeaderCell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath) as! ACBrokerageStep1HeaderCell
            let label: UILabel? = cell.viewWithTag(34) as? UILabel
            
            label!.text = "Brokerage Information."
            
            cell.selectionStyle = .None
            return cell
        }
        else if indexPath.row == 6 {
            let cellState: ACBrokerageCityStateCellView = tableView.dequeueReusableCellWithIdentifier("ACBrokerageCityStateCellView1", forIndexPath: indexPath) as! ACBrokerageCityStateCellView
            self.brokerCityTextField = cellState.viewWithTag(41) as? UITextField
            self.brokerStateTextField = cellState.viewWithTag(43) as? UITextField
            self.brokerZipCodeTextField = cellState.viewWithTag(45) as? UITextField
            
            self.brokerCityTextField?.delegate=self
            self.brokerStateTextField?.delegate=self
            self.brokerZipCodeTextField?.delegate=self

            self.brokerCityTextField?.enabled=false
            self.brokerStateTextField?.enabled=false
            self.brokerZipCodeTextField?.enabled=false

            self.brokerZipCodeTextField.keyboardType = .NumberPad
            
            if let brokerModelObj = brokerObj {
                self.brokerCityTextField.text = brokerModelObj.brokerageCity
                self.brokerStateTextField.text = brokerModelObj.brokerageState
                self.brokerZipCodeTextField.text = brokerModelObj.brokerageZipcode
            }
            else
            {
                // leave it empty
            }
            
            cellState.selectionStyle = .None
            return cellState
        }
        let cell: ACBrokerageTextCell = tableView.dequeueReusableCellWithIdentifier("textHeader", forIndexPath: indexPath) as! ACBrokerageTextCell
        
        let label: UILabel? = cell.viewWithTag(33) as? UILabel
        let textField : UITextField? = cell.viewWithTag(32) as? UITextField
        textField?.delegate=self
        if indexPath.row == 1 {
            label!.text = "BROKERAGE NAME"
            textField?.enabled=false
            textField?.keyboardType = .EmailAddress
            self.brokerNameTextField = textField;
            if let brokerModelObj = brokerObj {
                self.brokerNameTextField.text = brokerModelObj.brokerageName
            }
            else
            {
                // leave it empty
            }
        }
        else if indexPath.row == 2 {
            label!.text = "BROKERAGE EMAIL ADDRESS"
            textField?.keyboardType = .PhonePad
            textField?.enabled=false
            self.brokerageEmailAddField = textField
            if let brokerModelObj = brokerObj {
                self.brokerageEmailAddField.text = brokerModelObj.brokeragePhone
            }
            else
            {
                // leave it empty
            }
        }
        else if indexPath.row == 3 {
            label!.text = "BROKERAGE PHONE NUMBER"
            textField?.keyboardType = .PhonePad
            textField?.enabled=false
            self.brokerPhoneTextField = textField
            if let brokerModelObj = brokerObj {
                self.brokerPhoneTextField.text = brokerModelObj.brokeragePhone
            }
            else
            {
                // leave it empty
            }
        }
        else if indexPath.row == 4 {
            label!.text = "BROKERAGE ADDRESS 1"
            textField?.keyboardType = .Default
            textField?.enabled=false
            self.brokerAddressTextField = textField
            if let brokerModelObj = brokerObj {
                self.brokerAddressTextField.text = brokerModelObj.brokerageAddress
            }
            else
            {
                // leave it empty
            }
        }
        else if indexPath.row == 5 {
            label!.text = "BROKERAGE ADDRESS 2 (OPTIONAL)"
            textField?.keyboardType = .Default
            textField?.enabled=false
            self.brokerAddressOptTextField = textField
            if let brokerModelObj = brokerObj {
                self.brokerAddressOptTextField!.text = brokerModelObj.brokerageAddressOpt
            }
            else
            {
                // leave it empty
            }
        }
        cell.selectionStyle = .None
        return cell
    }
}
