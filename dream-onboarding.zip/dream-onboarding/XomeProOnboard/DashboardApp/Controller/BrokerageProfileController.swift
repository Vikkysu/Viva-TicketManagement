//
//  BrokerageProfileController.swift
//  ProfessionalTools
//
//  Created by BharatMeda on 10/24/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class BrokerageProfileController: UIViewController {
    
    let brokerageProfileView: BrokerageProfileView = BrokerageProfileView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.hidden = true
        self.loadBrokerageProfile()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func loadBrokerageProfile() {
        
        brokerageProfileView.loadBrokerageProfile(self)
        print ("loading brokerage profile...")
    }

}