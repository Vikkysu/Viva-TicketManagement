//
//  EditProfileVIew.swift
//  ProfessionalTools
//
//  Created by MACMINI4 on 23/10/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class EditAdditionalVIew: NSObject {
    
    var editAdditionalModel : EditAdditionalModel = EditAdditionalModel()
    
    var vwController                    :UIViewController!
    var vwMain                            :UIView!
    var vwSubview                            :UIView!

    var vwHeader                        :UIView!
    var vwHeaderRight                :UIImageView!
    
    var btnBackHeader                  :UIButton!
    var lblHeader                   :UILabel!
    var btnRtHeader                 :UIButton!
    
    var lblEditProfileHeader                  :UILabel!
    
    var dividerView1                  : UIView!
    var lblAddress1Header      : UILabel!
    var tfAddress1                    : UITextField!
    
    var dividerView2                  : UIView!
    var lblAddress2Header      : UILabel!
    var tfAddress2                    : UITextField!
    
    var dividerView3                  : UIView!
    var lblCityHeader      : UILabel!
    var tfCity                   : UITextField!
    
    var lblStateHeader      : UILabel!
    var tfState                    : UITextField!
    
  
    var lblZipHeader      : UILabel!
    var tfZip                    : UITextField!
    
    var dividerView4                  : UIView!
    
     var lblinterestedHeader      : UILabel!
    var btnCheckBox1               : UIButton!
    var lblCheckBox1                 : UILabel!
    
    var btnCheckBox2               : UIButton!
    var lblCheckBox2                 : UILabel!
    
    var btnCheckBox3              : UIButton!
    var lblCheckBox3                 : UILabel!
    

        var cgScreenWidth               :CGFloat!
    var cgScreenHeight              :CGFloat!
    
    func loadEditProfileUI(inViewController :UIViewController, inEditAdditionalModel: EditAdditionalModel){
        
        vwController            = inViewController
        editAdditionalModel     = inEditAdditionalModel
        
        getScreenDimensions()
        createUIElements()
        setProperties()
        setProfileData()
        addElements2UI()
    }
    
    
    func getScreenDimensions(){
        
        let screenDimensions = UIScreen.mainScreen().bounds
        cgScreenWidth        = screenDimensions.width
        cgScreenHeight       = screenDimensions.height
    }
    
    func centreX(inWidth: CGFloat)->CGFloat{
        
        let tWidth:CGFloat  = cgScreenWidth - CGFloat(inWidth)
        let pX: CGFloat     = tWidth/2
        
        return pX
    }
    
    func centreY(inHeight: CGFloat)->CGFloat{
        
        let tHeight:CGFloat  = cgScreenHeight - CGFloat(inHeight)
        let pY: CGFloat      = tHeight/2
        
        return pY
    }
    
    func convert2Pixels(points:CGFloat)->CGFloat{
        
        let pixels  :CGFloat = points * 96 / 72
        return pixels
    }
    
    func createUIElements(){
        
        let hdrVwHeight :CGFloat = self.convert2Pixels(65)
        let hdrWidth    :CGFloat = self.convert2Pixels(32)
        let hdrHeight   :CGFloat = self.convert2Pixels(22)
        let hdRtWidth   :CGFloat = self.convert2Pixels(30)
        let hdRtHeight  :CGFloat = self.convert2Pixels(30)
        let hdRtX       :CGFloat = cgScreenWidth - hdRtWidth - 20 //constraint set to hdRtWidth
        let hdRTY       :CGFloat = self.convert2Pixels(31)
        let hdrX        :CGFloat = self.centreX(hdrWidth)
        let hdrY        :CGFloat = self.convert2Pixels(31)
        let profHY      :CGFloat = self.convert2Pixels(15)
        
        
        vwMain              = UIView(frame:CGRectMake(0, 0, cgScreenWidth, cgScreenHeight))
        
        vwSubview        = UIView(frame:CGRectMake(10, hdrVwHeight+10, cgScreenWidth-20, cgScreenHeight-hdrVwHeight-20))
        
        vwHeader            = UIView(frame:CGRectMake(0, 0, cgScreenWidth, hdrVwHeight))
        btnBackHeader          = UIButton(frame:CGRectMake(0, hdrY, hdRtWidth+20, hdRtHeight))
        lblHeader           = UILabel(frame:CGRectMake(hdrX, hdrY+2, hdrWidth, hdrHeight))
        btnRtHeader         = UIButton(frame:CGRectMake(hdRtX , hdRTY, hdRtWidth, hdRtHeight))
        
        
        lblEditProfileHeader          = UILabel(frame:CGRectMake(0, profHY, cgScreenWidth, 20))
        
        dividerView1        = UIView(frame: CGRectMake(0, profHY+60, cgScreenWidth-20, 2))
        lblAddress1Header = UILabel(frame: CGRectMake(5, profHY+65, cgScreenWidth-20/2, 20))
        tfAddress1              = UITextField(frame: CGRectMake(5, profHY+90, cgScreenWidth-20/2, 33))
        
        dividerView2        = UIView(frame: CGRectMake(0, profHY+120, cgScreenWidth-20, 2))
        lblAddress2Header = UILabel(frame: CGRectMake(5, profHY+125, cgScreenWidth-20/2, 20))
        tfAddress2              = UITextField(frame: CGRectMake(5, profHY+150, cgScreenWidth-20/2, 33))
        

        dividerView3        = UIView(frame: CGRectMake(0, profHY+180, cgScreenWidth-20, 2))
        lblCityHeader = UILabel(frame: CGRectMake(5, profHY+185, cgScreenWidth/2, 20))
        tfCity              = UITextField(frame: CGRectMake(5, profHY+210, cgScreenWidth/2, 33))
        
        lblStateHeader = UILabel(frame: CGRectMake(180, profHY+185, 50, 20))
        tfState              = UITextField(frame: CGRectMake(180, profHY+210, 40, 33))
        
        lblZipHeader = UILabel(frame: CGRectMake(270, profHY+185, 50, 20))
        tfZip              = UITextField(frame: CGRectMake(270, profHY+210, 100, 33))

        dividerView4        = UIView(frame: CGRectMake(0, profHY+240, cgScreenWidth-20, 2))
        
        lblinterestedHeader = UILabel(frame: CGRectMake(5, profHY+270, 100, 20))
        btnCheckBox1         = UIButton(frame:CGRectMake(5 , profHY+298, 33, 33))
        lblCheckBox1 = UILabel(frame: CGRectMake(48, profHY+305, 50, 20))
        
        btnCheckBox2         = UIButton(frame:CGRectMake(5 , profHY+338, 33, 33))
        lblCheckBox2 = UILabel(frame: CGRectMake(48, profHY+348, 50, 20))
        
        btnCheckBox3         = UIButton(frame:CGRectMake(5 , profHY+378, 33, 33))
        lblCheckBox3 = UILabel(frame: CGRectMake(48, profHY+385, 70, 20))
        

        

    }
    
    func setProperties(){
        
        vwMain.backgroundColor          = UIColor(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
        vwSubview.backgroundColor          = UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1)

        //setup header
        vwHeader.backgroundColor        = UIColor(red: 217/255, green: 2/255, blue: 9/255, alpha: 1)
        btnBackHeader.setTitle("Cancel", forState: UIControlState.Normal)
        btnBackHeader.addTarget(self, action: Selector("back"), forControlEvents: UIControlEvents.TouchUpInside)

        btnRtHeader.setTitle("Save", forState: UIControlState.Normal)
        btnRtHeader.addTarget(self, action: Selector("back"), forControlEvents: UIControlEvents.TouchUpInside)
        btnRtHeader.backgroundColor = UIColor.clearColor()
        
        lblHeader.text              = "Edit"
        let headerFont      :UIFont = UIFont(name: "MuseoSansRounded-300", size: 18.0)!
        lblHeader.font              = headerFont
        lblHeader.textColor         = UIColor.whiteColor()

        
        lblEditProfileHeader.textColor          = UIColor.blackColor()
        lblEditProfileHeader.textAlignment      = NSTextAlignment.Center
        let shopperFont      :UIFont  = UIFont(name: "MuseoSansRounded-300", size: 17.0)!
        lblEditProfileHeader.font               = shopperFont
        lblEditProfileHeader.text               = "Additional Information"
        
        dividerView1.backgroundColor = UIColor(red: 232/255, green: 232/255, blue: 232/255, alpha: 1)
        
        lblAddress1Header.textColor               = UIColor(red: 159/255, green: 162/255, blue: 164/255, alpha: 1)
        lblAddress1Header.text                    = "ADDRESS 1"
        let h1Font                  :UIFont = UIFont(name: "MuseoSansRounded-300", size: 10.0)!
        lblAddress1Header.font                    = h1Font


        tfAddress1.textColor                                    = UIColor.blackColor()
        let t1Font                  :UIFont = UIFont(name: "MuseoSansRounded-300", size: 15.0)!
        tfAddress1.font                                            = t1Font
        tfAddress1.userInteractionEnabled             =   false

        
        dividerView2.backgroundColor = UIColor(red: 232/255, green: 232/255, blue: 232/255, alpha: 1)
        lblAddress2Header.textColor               = UIColor(red: 159/255, green: 162/255, blue: 164/255, alpha: 1)
        lblAddress2Header.text                        = "ADDRESS 2"
        lblAddress2Header.font                    = h1Font
        
        tfAddress2.textColor                                    = UIColor.blackColor()
        tfAddress2.font                                            = t1Font
        tfAddress2.userInteractionEnabled             =   false
        
        dividerView3.backgroundColor = UIColor(red: 232/255, green: 232/255, blue: 232/255, alpha: 1)

        lblCityHeader.textColor               = UIColor(red: 159/255, green: 162/255, blue: 164/255, alpha: 1)
        lblCityHeader.text                        = "CITY"
        lblCityHeader.font                    = h1Font
        
        tfCity.textColor                                    = UIColor.blackColor()
        tfCity.font                                            = t1Font
        tfCity.userInteractionEnabled             =   false
        
        
        lblStateHeader.textColor               = UIColor(red: 159/255, green: 162/255, blue: 164/255, alpha: 1)
        lblStateHeader.text                        = "STATE"
        lblStateHeader.font                    = h1Font
        
        tfState.textColor                                    = UIColor.blackColor()
        tfState.font                                            = t1Font
        tfState.userInteractionEnabled             =   false
        
        lblZipHeader.textColor               = UIColor(red: 159/255, green: 162/255, blue: 164/255, alpha: 1)
        lblZipHeader.text                        = "ZIP"
        lblZipHeader.font                    = h1Font
        
        tfZip.textColor                                    = UIColor.blackColor()
        tfZip.font                                            = t1Font
        tfZip.userInteractionEnabled             =   false
        
        dividerView4.backgroundColor = UIColor(red: 232/255, green: 232/255, blue: 232/255, alpha: 1)
        
        lblinterestedHeader.textColor               = UIColor(red: 159/255, green: 162/255, blue: 164/255, alpha: 1)
        lblinterestedHeader.text                        = "I'M INTERESTED IN:"
        lblinterestedHeader.font                    = h1Font
        
        btnCheckBox1.setImage(UIImageCustom().getImageFromString("boxUnchecked.png"), forState: UIControlState.Normal)
        btnCheckBox1.addTarget(self, action: Selector("checkBoxButtonClicked:"), forControlEvents: UIControlEvents.TouchUpInside)
        lblCheckBox1.text                   = "Buying"
        lblCheckBox1.textColor                                    = UIColor.blackColor()
        lblCheckBox1.font                                            = t1Font
        
        btnCheckBox2.setImage(UIImageCustom().getImageFromString("boxUnchecked.png"), forState: UIControlState.Normal)
        btnCheckBox2.addTarget(self, action: Selector("checkBoxButtonClicked:"), forControlEvents: UIControlEvents.TouchUpInside)
        lblCheckBox2.text                   = "Selling"
        lblCheckBox2.textColor                                    = UIColor.blackColor()
        lblCheckBox2.font                                            = t1Font
        
        
        btnCheckBox3.setImage(UIImageCustom().getImageFromString("boxUnchecked.png"), forState: UIControlState.Normal)
        btnCheckBox3.addTarget(self, action: Selector("checkBoxButtonClicked:"), forControlEvents: UIControlEvents.TouchUpInside)
        lblCheckBox3.text                   = "Renting"
        lblCheckBox3.textColor                                    = UIColor.blackColor()
        lblCheckBox3.font                                            = t1Font
        

        

    }
    
    func setProfileData(){

        tfAddress1.text  = editAdditionalModel.addr1
        tfAddress2.text = editAdditionalModel.addr2
        tfCity.text = editAdditionalModel.addrCity
        tfState.text = editAdditionalModel.addrState
        tfZip.text = editAdditionalModel.zipCode

    }
    
    func addElements2UI(){
        
        vwController.view.addSubview(vwMain)
        vwMain.addSubview(vwHeader)
        vwMain.addSubview(vwSubview)
        
        vwHeader.addSubview(btnBackHeader)
        vwHeader.addSubview(lblHeader)
        vwHeader.addSubview(btnRtHeader)
        
        vwSubview.addSubview(lblEditProfileHeader)
        
        
        vwSubview.addSubview(dividerView1)
        vwSubview.addSubview(lblAddress1Header)
        vwSubview.addSubview(tfAddress1)
        
        vwSubview.addSubview(dividerView2)
        vwSubview.addSubview(lblAddress2Header)
        vwSubview.addSubview(tfAddress2)
        
        vwSubview.addSubview(dividerView3)
        vwSubview.addSubview(lblCityHeader)
        vwSubview.addSubview(tfCity)
        
        vwSubview.addSubview(lblStateHeader)
        vwSubview.addSubview(tfState)
        
        vwSubview.addSubview(lblZipHeader)
        vwSubview.addSubview(tfZip)
        
        vwSubview.addSubview(dividerView4)
        vwSubview.addSubview(lblinterestedHeader)
        vwSubview.addSubview(btnCheckBox1)
        vwSubview.addSubview(lblCheckBox1)
        vwSubview.addSubview(btnCheckBox2)
        vwSubview.addSubview(lblCheckBox2)
        vwSubview.addSubview(btnCheckBox3)
        vwSubview.addSubview(lblCheckBox3)
        

    }
    func back(){
        vwController.navigationController?.popViewControllerAnimated(true)
    }
    
    func checkBoxButtonClicked( sender : AnyObject )
    {
        let checkBoxBtn : UIButton = sender as! UIButton
        if checkBoxBtn.currentImage == UIImageCustom().getImageFromString("boxUnchecked.png")
        {
            checkBoxBtn.setImage(UIImageCustom().getImageFromString("boxChecked.png"), forState: UIControlState.Normal)
        }
        else{
            checkBoxBtn.setImage(UIImageCustom().getImageFromString("boxUnchecked.png"), forState: UIControlState.Normal)

        }
    }
    
    
}
