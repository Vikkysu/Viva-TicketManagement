//
//  GetAgentsModel.swift
//  XomeRestClient
//
//  Created by Shivakumar Chandramouli on 2/8/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper


public class GetAgentsModel: Mappable {

    public var recommendedAgent : [RecommendedAgents]?
    
    public init() {
        
    }
    
    required public init?(_ map: Map) {
        
    }
    
    public func mapping(map: Map) {
        
        recommendedAgent <- map["recommendedAgents"]
    }
}
