//
//  PriceHistoryRecords.swift
//  XomeRestClient
//
//  Created by Xome on 2/4/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class PriceHistoryRecords: Mappable {
    
    public var historyId: Double?
    public var propertyId: Double?
    public var scmId: Double?
    public var stateCode: String?
    public var muniName: String?
    public var fipsStateCode: Int?
    public var fipsMuniCode: Int?
    public var fipsCountyName: String?
    public var parcelNumber: String?
    public var fullSiteAddress: String?
    public var fullMailAddress: String?
    public var mailAddressHouseNumber: String?
    public var mailAddressHouseNumberFraction: String?
    public var mailAddressPreDirectional: String?
    public var mailAddressStreetName: String?
    public var mailAddressStreetNameSuffix: String?
    public var mailAddressPostDirectional: String?
    public var mailAddressUnitNumberPrefix: String?
    public var mailAddressUnitNumber: String?
    public var mailAddressCity: String?
    public var mailAddressState: String?
    public var mailAddressZip: Double?
    public var mailAddressCarrierRoute: String?
    public var legalDescription: String?
    public var legalKeyedBlock: String?
    public var legalKeyedLot: String?
    public var legalKeyedPlatBook: String?
    public var legalKeyedPlatPage: String?
    public var legalKeyedRange: String?
    public var legalKeyedSection: String?
    public var legalKeyedSubName: String?
    public var legalKeyedTownship: String?
    public var legalKeyedTract: String?
    public var legalKeyedUnit: String?
    public var buyer: String?
    public var seller: String?
    public var transferValue: Double?
    public var transferTax: Double?
    public var documentNumberRaw: String?
    public var documentNumberFormatted: String?
    public var transferDate: Double?
    public var filingDate: Double?
    public var documentType: String?
    public var deedType: String?
    public var transactionType: String?
    public var quitClaim: Bool?
    public var armsLengthFlag: String?
    public var fullPartCode: String?
    public var multipleApnFlagKeyed: String?
    public var multiplePortionalCode: String?
    public var lenderSellerFlag: String?
    public var documentNumber1: String?
    public var loanId1: String?
    public var loanId1Extension: String?
    public var loanValue1: Double?
    public var loanType1: String?
    public var interestRateType1: String?
    public var lenderCreditLine1: String?
    public var lenderCode1: Double?
    public var lenderFirstName1: String?
    public var lenderLastName1: String?
    public var lenderType1: String?
    public var documentNumber2: String?
    public var loanId2: String?
    public var loanId2Extension: String?
    public var loanValue2: Double?
    public var loanType2: String?
    public var interestRateType2: String?
    public var lenderCreditLine2: String?
    public var lenderCode2: Double?
    public var lenderFirstName2: String?
    public var lenderLastName2: String?
    public var lenderType2: String?
    public var documentNumber3: String?
    public var loanId3: String?
    public var loanId3Extension: String?
    public var loanValue3: Double?
    public var loanType3: String?
    public var interestRateType3: String?
    public var lenderCreditLine3: String?
    public var lenderFirstName3: String?
    public var lenderLastName3: String?
    public var lenderType3: String?
    public var distressIndicator: String?
    public var processId: Double?
    public var escrowId: String?
    public var transactionPrice: String?
    public var transactionDate: String?

    required public init?(_ map: Map) {
        
    }
    
    public func mapping(map: Map) {
        
        historyId <- map["historyId"]
        propertyId <- map["propertyId"]
        scmId <- map["scmId"]
        stateCode <- map["stateCode"]
        muniName <- map["muniName"]
        fipsStateCode <- map["fipsStateCode"]
        fipsMuniCode <- map["fipsMuniCode"]
        fipsCountyName <- map["fipsCountyName"]
        parcelNumber <- map["parcelNumber"]
        fullSiteAddress <- map["fullSiteAddress"]
        fullMailAddress <- map["fullMailAddress"]
        mailAddressHouseNumber <- map["mailAddressHouseNumber"]
        mailAddressHouseNumberFraction <- map["mailAddressHouseNumberFraction"]
        mailAddressPreDirectional <- map["mailAddressPreDirectional"]
        mailAddressStreetName <- map["mailAddressStreetName"]
        mailAddressStreetNameSuffix <- map["mailAddressStreetNameSuffix"]
        mailAddressPostDirectional <- map["mailAddressPostDirectional"]
        mailAddressUnitNumberPrefix <- map["mailAddressUnitNumberPrefix"]
        mailAddressUnitNumber <- map["mailAddressUnitNumber"]
        mailAddressCity <- map["mailAddressCity"]
        mailAddressState <- map["mailAddressState"]
        mailAddressZip <- map["mailAddressZip"]
        mailAddressCarrierRoute <- map["mailAddressCarrierRoute"]
        legalDescription <- map["legalDescription"]
        legalKeyedBlock <- map["legalKeyedBlock"]
        legalKeyedLot <- map["legalKeyedLot"]
        legalKeyedPlatBook <- map["legalKeyedPlatBook"]
        legalKeyedPlatPage <- map["legalKeyedPlatPage"]
        legalKeyedRange <- map["legalKeyedRange"]
        legalKeyedSection <- map["legalKeyedSection"]
        legalKeyedSubName <- map["legalKeyedSubName"]
        legalKeyedTownship <- map["legalKeyedTownship"]
        legalKeyedTract <- map["legalKeyedTract"]
        legalKeyedUnit <- map["legalKeyedUnit"]
        buyer <- map["buyer"]
        seller <- map["seller"]
        transferValue <- map["transferValue"]
        transferTax <- map["transferTax"]
        documentNumberRaw <- map["documentNumberRaw"]
        documentNumberFormatted <- map["documentNumberFormatted"]
        transferDate <- map["transferDate"]
        filingDate <- map["filingDate"]
        documentType <- map["documentType"]
        deedType <- map["deedType"]
        transactionType <- map["transactionType"]
        quitClaim <- map["quitClaim"]
        armsLengthFlag <- map["armsLengthFlag"]
        fullPartCode <- map["fullPartCode"]
        multipleApnFlagKeyed <- map["multipleApnFlagKeyed"]
        multiplePortionalCode <- map["multiplePortionalCode"]
        lenderSellerFlag <- map["lenderSellerFlag"]
        documentNumber1 <- map["documentNumber1"]
        loanId1 <- map["loanId1"]
        loanId1Extension <- map["loanId1Extension"]
        loanValue1 <- map["loanValue1"]
        loanType1 <- map["loanType1"]
        interestRateType1 <- map["interestRateType1"]
        lenderCreditLine1 <- map["lenderCreditLine1"]
        lenderCode1 <- map["lenderCode1"]
        lenderFirstName1 <- map["lenderFirstName1"]
        lenderLastName1 <- map["lenderLastName1"]
        lenderType1 <- map["lenderType1"]
        documentNumber2 <- map["documentNumber2"]
        loanId2 <- map["loanId2"]
        loanId2Extension <- map["loanId2Extension"]
        loanValue2 <- map["loanValue2"]
        loanType2 <- map["loanType2"]
        interestRateType2 <- map["interestRateType2"]
        lenderCreditLine2 <- map["lenderCreditLine2"]
        lenderCode2 <- map["lenderCode2"]
        lenderFirstName2 <- map["lenderFirstName2"]
        lenderLastName2 <- map["lenderLastName2"]
        lenderType2 <- map["lenderType2"]
        documentNumber3 <- map["documentNumber3"]
        loanId3 <- map["loanId3"]
        loanId3Extension <- map["loanId3Extension"]
        loanValue3 <- map["loanValue3"]
        loanType3 <- map["loanType3"]
        interestRateType3 <- map["interestRateType3"]
        lenderCreditLine3 <- map["lenderCreditLine3"]
        lenderFirstName3 <- map["lenderFirstName3"]
        lenderLastName3 <- map["lenderLastName3"]
        lenderType3 <- map["lenderType3"]
        distressIndicator <- map["distressIndicator"]
        processId <- map["processId"]
        escrowId <- map["escrowId"]
        transactionPrice <- map["transactionPrice"]
        transactionDate <- map["transactionDate"]
    }
}