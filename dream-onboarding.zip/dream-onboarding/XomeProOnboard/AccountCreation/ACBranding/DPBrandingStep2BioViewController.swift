//
//  DPBrandingStep2BioViewController.swift
//  
//
//  Created by Vikas on 10/8/15.
//
//

import UIKit

class DPBrandingStep2BioViewController: DPAccountCreationBaseViewController {
    
    var eState: flowState = .BROKERAGE
    
    func nextNavigation () {
        let accountViewCntrl = self.childViewControllers[0] as! DPBrandingStep2BioTableViewController
        if accountViewCntrl.setDataFields() == true {
            if userRoleInfo.getUserRole() == userType.InvitedAgent {
                let nextViewController: DPBrandingReviewViewController = DPBrandingReviewViewController()
                self.navigationController?.pushViewController(nextViewController, animated: true)
            }
            else
            {
                if eState == flowState.BROKERAGE {
                    let nextViewController: DPBrokerProfileViewController = DPBrokerProfileViewController()
                    self.navigationItem.backBarButtonItem?.title = " "
                    self.navigationController?.pushViewController(nextViewController, animated: true)
                }
                else
                {
                    let nextViewController: DPBrandingReviewViewController = DPBrandingReviewViewController()
                    self.navigationItem.backBarButtonItem?.title = " "
                    nextViewController.eState = eState
                    self.navigationController?.pushViewController(nextViewController, animated: true)
                }
            }
        }
    }

    override func nextViewC1(sender: UIBarButtonItem) {
        
        print(self.childViewControllers)
        self.nextNavigation()
    }
    
    override func skipViewC1(sender: UIBarButtonItem) {
        print(self.childViewControllers)
       self.nextNavigation()
    }
    
    func geteState()->flowState {
        return eState
    }
    
    func changeeState(lState : flowState) {
        eState = lState
    }
    
    func closeView(sender: UIBarButtonItem) {
        self.dismissViewControllerAnimated(true, completion: nil);
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.navigationItem.title = "Branding"

        self.view.backgroundColor = UIColor.lightGrayColor()
        
        let tablecontr: DPBrandingStep2BioTableViewController = DPBrandingStep2BioTableViewController()
        self.addChildViewController(tablecontr)
        self.view.addSubview(tablecontr.view)
        tablecontr.didMoveToParentViewController(self)
        
        tablecontr.view.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self.view).offset(138)
            make.leading.equalTo(self.view).offset(5)
            make.trailing.equalTo(self.view).offset(-5)
            make.bottom.equalTo(self.view).offset(-5)
        }
        
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            self.setStepIndication(tagStep1, state: 5)
            self.setStepIndication(tagStep2, state: 5)
            self.setStepIndication(tagStep3, state: 3)
        }
        else {
            if eState == flowState.BROKERAGE {
                self.setStepIndication(tagStep1, state: 5)
                self.setStepIndication(tagStep2, state: 3)
            }
            else {
                self.setStepIndication(tagStep1, state: 5)
                self.setStepIndication(tagStep2, state: 5)
                self.setStepIndication(tagStep3, state: 4)
            }
        }
        self.createSkipbutton()

        let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
        if let brokerPersonalInfoInfo: DPBrandingBioObj = brokerOnboardingInfo.loadBrokerageBrandingBioObjectWithKey() {
            if let brokerPersonalBio = brokerPersonalInfoInfo.bioStr {
            if brokerPersonalBio.isEmpty || brokerPersonalBio == " " {
                self.createSkipbutton()
            }
            else {
                self.createNextbutton(NEXTBUTTON)
            }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
