//
//  FavoritesService.swift
//  XomeRestClient
//
//  Created by Vikas on 1/20/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import PromiseKit

public enum FavoritesSortBy: String {
    case PriceLowToHigh = "PriceLoToHi"
    case PriceHighToLow = "PriceHiToLow"
    case DateListed     = "DateListed"
    case DateSold       = "DateSold"
    case CityAToZ       = "CityAToZ"
    case CityZtoA       = "CityZToA"
}

public extension XomeService {

    public func favorites(sortBy sortBy: FavoritesSortBy, idsOnly: Bool = false) -> Promise<FavoritePropertyListModel>
    {
        let path = "SavedProperties"
        let params = [
            "showDetails": String(!idsOnly),
            "sortOrder": sortBy.rawValue
        ]
        return operationFactory.promise(path: path, queryParameters: params, bodyData: nil, outgoingRequestMutator: nil)
    }
    
    public func addFavorite(listingId: String) -> Promise<FavoritePropertyModel>
    {
        let path = "SavedProperties/"
        let postData = NSDictionary(dictionary: ["ListingKey": listingId]).xome_jsonData()
        return operationFactory.promise(.POST, path: path, queryParameters: nil, bodyData: postData, outgoingRequestMutator: nil)
    }

    public func removeFavorite(favoriteId: String) -> Promise<FavoritePropertyModel>
    {
        let path = "SavedProperties/\(favoriteId)"
        return operationFactory.promise(.DELETE, path: path, queryParameters: nil, bodyData: nil, outgoingRequestMutator: nil)
    }
}
