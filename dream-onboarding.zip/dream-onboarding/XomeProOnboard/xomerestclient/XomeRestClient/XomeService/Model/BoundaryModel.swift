//
//  BoundaryModel.swift
//  XomeRestClient
//
//  Created by David Parton on 3/29/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper
import CoreLocation
import MapKit

public class BoundaryPointTransform : TransformType {
    public typealias Object = [CLLocationCoordinate2D]
    public typealias JSON = [[Float]]

    public func transformFromJSON(value: AnyObject?) -> Object? {
        guard let json = value as? JSON else { return nil }
        return json.flatMap {
            guard let long = $0[safe: 0], lat = $0[safe: 1] else { return nil }
            return CLLocationCoordinate2D(latitude: CLLocationDegrees(lat),
                                            longitude: CLLocationDegrees(long))
        }
    }

    public func transformToJSON(value: Object?) -> JSON? {
        return value?.map { [Float($0.longitude), Float($0.latitude)] }
    }
}

public class PolygonPointList: Mappable {
    public var points: [CLLocationCoordinate2D] = []

    public init(points: [CLLocationCoordinate2D]) {
        self.points = points
    }
    public init(polygon: MKPolygon) {
        let buffer = UnsafeMutableBufferPointer(start: polygon.points(), count: polygon.pointCount)
        points = Array(buffer).map { MKCoordinateForMapPoint($0) }
    }

    public required init?(_ map: Map) {
    }

    public func mapping(map: Map) {
        points <- (map["Points"], BoundaryPointTransform())
    }
}

public class BoundaryModel: Mappable {
    public var polygonPoints: [PolygonPointList] = []
    public var isSingle: Bool { return polygonPoints.count == 1 }

    public init(polygonPoints: [PolygonPointList]) {
        self.polygonPoints = polygonPoints
    }

    public required init?(_ map: Map) {
    }

    public func mapping(map: Map) {
        polygonPoints <- map["polygonPoints"]
    }

    public func boundingBoxRegion(regionSizeMultiplier: CLLocationDegrees = 1) -> MKCoordinateRegion {
        let maxDegrees = CLLocationDegrees(FLT_MAX), minDegrees = CLLocationDegrees(-FLT_MAX)
        var minLat = maxDegrees, minLon = maxDegrees
        var maxLat = minDegrees, maxLon = minDegrees
        polygonPoints.forEach {
            $0.points.forEach {
                minLat = min(minLat, $0.latitude)
                minLon = min(minLon, $0.longitude)
                maxLat = max(maxLat, $0.latitude)
                maxLon = max(maxLon, $0.longitude)
            }
        }

        let center = CLLocationCoordinate2DMake(minLat + (maxLat - minLat)/2,
                                                minLon + (maxLon - minLon)/2)
        let span = MKCoordinateSpanMake((maxLat - minLat)*regionSizeMultiplier,
                                        (maxLon - minLon)*regionSizeMultiplier)
        return MKCoordinateRegionMake(center, span)
    }

    public var polygons: [MKPolygon] {
        return polygonPoints.map {
            var mapPoints: [CLLocationCoordinate2D] = $0.points.map {
                CLLocationCoordinate2D(latitude: $0.latitude, longitude: $0.longitude)
            }
            return MKPolygon(coordinates: &mapPoints, count: mapPoints.count)
        }
    }

    public func applyTo(request: PropertyRequestModel) {
        polygonPoints.forEach {
            let location = PropertyRequestBoundaryModel(points: $0.points)
            request.addLocation(location)
        }
    }
}

extension PropertySearchModel: MappableCluster {
    public static func objectForMapping(map: Map) -> Mappable? {
        let resolved = tap(PropertySearchResolvedBoundaryModel(map)) { $0?.mapping(map) }
        if resolved?.boundary != nil {
            return resolved
        }

        return PropertySearchModel(map)
    }
}

public class PropertySearchResolvedBoundaryModel: PropertySearchModel {
    public var boundary: BoundaryModel?

    public init(basicModel: PropertySearchModel, boundary: BoundaryModel?) {
        self.boundary = boundary
        super.init(copy: basicModel)
    }

    required public init?(_ map: Map) {
        super.init(map)
    }

    public override func mapping(map: Map) {
        super.mapping(map)

        boundary <- map["additionalInfo.boundary"]
    }
}
