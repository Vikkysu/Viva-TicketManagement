//
//  XomeModel.m
//  Xome
//
//  Created by David Parton on 6/23/15.
//  Copyright (c) 2015 Xome. All rights reserved.
//

#import "XomeRestModel.h"
@import XomeFoundation;

#import "objc/runtime.h"

XOME_OBJECT_ASSOCIATION_KEY(kFieldNamesSeparatedByComma);
XOME_OBJECT_ASSOCIATION_KEY(kFieldNamesArray);

@implementation XomeRestModel

+ (NSString *)fieldNamesSeparatedByComma {
    NSString* cached = [(id)self associatedObjectForKey:kFieldNamesSeparatedByComma];
    if (cached) {
        return cached;
    }

    cached = [[self arrayOfFieldNames] componentsJoinedByString:@","];
    [(id)self associateObject:cached withKey:kFieldNamesSeparatedByComma policy:XomeObjectAssociationPolicy_RETAIN_NONATOMIC];
    return cached;
}

+ (NSArray*)arrayOfFieldNames {
    NSArray* cached = [(id)self associatedObjectForKey:kFieldNamesArray];
    if (cached) {
        return cached;
    }

    unsigned int count;
    objc_property_t* properties = class_copyPropertyList(self, &count);
    NSMutableArray* output = [[NSMutableArray alloc] initWithCapacity:count];
    if (properties) {
        void* freePtr = properties;
        while (*properties) {
            objc_property_t prop = *properties++;
            const char* name = property_getName(prop);
            [output addObject:[NSString stringWithCString:name encoding:NSASCIIStringEncoding]];
        }
        free(freePtr);
    }
    [(id)self associateObject:output withKey:kFieldNamesArray policy:XomeObjectAssociationPolicy_RETAIN_NONATOMIC];
    return output;
}

@end
