//
//  ACBrokerageCityStateCellView.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/4/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class ACBrokerageCityStateCellView: UITableViewCell {
    override init(style: UITableViewCellStyle, reuseIdentifier: String!)
    {
        super.init(style: UITableViewCellStyle.Value1, reuseIdentifier: reuseIdentifier)
        var labelText : UILabel
        labelText = UILabel()
        labelText.textAlignment = .Left
        labelText.text = "CITY"
        labelText.tag=40
        labelText.font = UIFont(name: MuseoSansRounded100Font, size: 11.0)
        self.addSubview(labelText)
        
        let textField : UITextField = UITextField()
        textField.font = UIFont(name: MuseoSansRounded100Font, size: 20.0)
        textField.tag=41
        self.addSubview(textField)
        
        var labelTextState : UILabel
        labelTextState = UILabel()
        labelTextState.textAlignment = .Left
        labelTextState.tag=42
        labelTextState.text = "STATE"
        labelTextState.font = UIFont(name: MuseoSansRounded100Font, size: 11.0)
        self.addSubview(labelTextState)
        
        let textFieldState : UITextField = UITextField()
        textFieldState.font = UIFont(name: MuseoSansRounded100Font, size: 20.0)
        textFieldState.tag=43
        self.addSubview(textFieldState)
        
        var labelTextZipCode : UILabel
        labelTextZipCode = UILabel()
        labelTextZipCode.textAlignment = .Left
        labelTextZipCode.text = "ZIP CODE"
        labelTextZipCode.tag=44
        labelTextZipCode.font = UIFont(name: MuseoSansRounded100Font, size: 11.0)
        self.addSubview(labelTextZipCode)
        
        let textFieldZipCode : UITextField = UITextField()
        textFieldZipCode.font = UIFont(name: MuseoSansRounded100Font, size: 20.0)
        textFieldZipCode.tag=45
        textFieldZipCode.textAlignment = .Right
        self.addSubview(textFieldZipCode)
        
        
        let separatorLine: UIView = UIView()
        separatorLine.backgroundColor = UIColor.baoTableBorderColor()
        self.addSubview(separatorLine)
        
        labelTextState.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self).offset(5)
            make.centerX.equalTo(self).offset(0)
            make.height.equalTo(25)
        }
        
        textFieldState.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(labelTextState).offset(20)
            make.centerX.equalTo(labelTextState).offset(0)
            make.width.equalTo(labelTextState)
            make.height.equalTo(30)
        }
        
        labelText.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self).offset(5)
            make.leading.equalTo(self).offset(10)
            make.height.equalTo(25)
        }
        
        textField.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(labelText).offset(20)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(textFieldState).offset(10)
            make.height.equalTo(30)
        }
        
        labelTextZipCode.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self).offset(5)
            make.trailing.equalTo(self).offset(-30)
            make.height.equalTo(25)
        }
        
        textFieldZipCode.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(labelTextZipCode).offset(20)
            make.leading.equalTo(labelTextZipCode).offset(0)
            make.trailing.equalTo(self).offset(-30)
            make.height.equalTo(30)
        }
        
        separatorLine.snp_makeConstraints {(make) -> Void in
            make.bottom.equalTo(textField).offset(4)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-1)
            make.height.equalTo(1)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setSelected(selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }

}
