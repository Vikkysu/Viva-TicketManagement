//
//  DPAgentBrokerageInfoViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/24/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPAgentBrokerageInfoViewController: DPAccountCreationBaseViewController {
    
    override func nextViewC1(sender: UIBarButtonItem) {
        let nextViewController: ACBrokarageStep3ViewController = ACBrokarageStep3ViewController()
        self.navigationItem.backBarButtonItem?.title = " "
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.navigationItem.title = "Create an Account"
        
        self.view.backgroundColor = UIColor.lightGrayColor()
        
        let tablecontr: DPAgentBrokerageInfoTableViewController = DPAgentBrokerageInfoTableViewController()
        self.addChildViewController(tablecontr)
        self.view.addSubview(tablecontr.view)
        tablecontr.didMoveToParentViewController(self)
        
        tablecontr.view.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self.view).offset(138)
            make.leading.equalTo(self.view).offset(5)
            make.trailing.equalTo(self.view).offset(-5)
            make.bottom.equalTo(self.view).offset(-5)
        }
        
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            self.setStepIndication(tagStep1, state: 5)
            self.setStepIndication(tagStep2, state: 2)
        }
        else {
            self.setStepIndication(tagStep1, state: 2)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
}
