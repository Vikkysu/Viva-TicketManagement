//
//  SavedSearchListModel.swift
//  XomeRestClient
//
//  Created by Brendan Farrington on 2/3/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class SavedSearchListModel: Mappable {
    public var pageSize: Int?
    public var pageIndex: Int?
    public var pageCount: Int?
    public var totalCount: Int?

    public var items = [SavedSearchModel]()

    public init() {

    }
    

    required public init?(_ map: Map) {

    }

    public func mapping(map: Map) {
        pageSize <- map["pageSize"]
        pageIndex <- map["page"]
        pageCount <- map["pageCount"]
        totalCount <- map["totalCount"]
        items <- map["items"]
    }
}