//
//  PropertyDetailsCommunityInfoModel.swift
//  XomeRestClient
//
//  Created by David Parton on 1/20/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation

public class PropertyDetailsCommunityInfoModel : PropertyDetailsSimpleInfoModel {
}