//
//  XomeRestClient.h
//  XomeRestClient
//
//  Created by Vikas on 9/21/15.
//  Copyright (c) 2015 Xome. All rights reserved.
//

@import XomeFoundation;
@import JSONModel;

//! Project version number for XomeRestClient.
FOUNDATION_EXPORT double XomeRestClientVersionNumber;

//! Project version string for XomeRestClient.
FOUNDATION_EXPORT const unsigned char XomeRestClientVersionString[];

NS_ASSUME_NONNULL_BEGIN
@protocol XomeRestClientServiceEnvironment
- (NSString*)apiKey;
- (NSString*)apiEndpoint;
- (nullable NSURL*)apiEndpointURL;
- (nullable NSURL*)webURL;
- (nullable NSURL*)socialLoginURL;
@end
NS_ASSUME_NONNULL_END

#import <XomeRestClient/XomeRestOperation.h>
#import <XomeRestClient/XomeRestOperationFactory.h>
#import <XomeRestClient/XomeRestOperationFactoryDefault.h>

#import <XomeRestClient/XomeRestModel.h>
#import <XomeRestClient/XomeRestMLSStatusTypeID.h>
#import <XomeRestClient/XomeRestPagedArrayResult.h>
#import <XomeRestClient/XomeRestPropertyDataProvider.h>
