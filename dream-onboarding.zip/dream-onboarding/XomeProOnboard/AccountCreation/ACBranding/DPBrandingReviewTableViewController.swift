//
//  DPBrandingReviewTableViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/8/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrandingReviewTableViewController: UITableViewController {
    
    func setDataFields() -> Bool
    {
        return true
    }
    
    var cellInfoArr: [(value: String, subHeader: String, type: String)] = [(value: String, subHeader: String, type: String)]()

    override func viewDidLoad() {
        var cellBrokerageInfoArr:[(value: String, subHeader: String, type: String)] = []
        var cellBrokerInfoArr:[(value: String, subHeader: String, type: String)] = []

        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        
        let reviewInfo : DPReviewInfo = DPReviewInfo()
        
        //get the review values from model
        //constructAgentCellInfo
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            cellInfoArr = reviewInfo.constructAgentCellInfo()
        }
        else
        {
            cellBrokerageInfoArr = reviewInfo.constructCellInfo()
            cellBrokerInfoArr = reviewInfo.constructBrokerCellInfo()
            
            for arrVal in cellBrokerageInfoArr {
                cellInfoArr.append(arrVal)
            }
            
            for arrBrokerVal in cellBrokerInfoArr {
                cellInfoArr.append(arrBrokerVal)
            }
        }
        
        tableView.delegate=self
        tableView.dataSource=self
        tableView.showsHorizontalScrollIndicator=false
        tableView.showsVerticalScrollIndicator=false
        tableView.separatorStyle = .None
        tableView.registerClass(DPBrandingReviewSubHeaderCell.self, forCellReuseIdentifier: "DPBrandingReviewSubHeaderIdentifierCell")
        tableView.registerClass(DPBrandingReviewMenuCell.self, forCellReuseIdentifier: "DPBrandingReviewMenuCellIdentifierCell")
        tableView.registerClass(DPBrandingLicenseTableViewCell.self, forCellReuseIdentifier: "DPBrandingLicenseCellIdentifierCell")
        tableView.registerClass(DPBrandingReviewMLSInfoTableViewCell.self, forCellReuseIdentifier: "DDPBrandingReviewMLSInfoCellIdentifierCell")
        tableView.registerClass(DPBrandingReviewOptionalTableViewCell.self, forCellReuseIdentifier: "DPBrandingReviewOptionaCellIdentifierCell")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Tableview delegates
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return cellInfoArr.count
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        let (value, subHeader, type) = cellInfoArr[indexPath.row]
        print(subHeader)
        print(value)
        if(type == "BROKER LICENSE INFORMATION" || type == "HEADER") {
            return 60
        }
        else if(type == "BROKER MLS INFORMATION") {
            return 100
        }
        else if(type == "BROKER BRANDING") {
            return 50
        }
        return 80
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        // fill the fields if saved offline
            //DPBrandingReviewSubHeaderCell
        let (value, subHeader, type) = cellInfoArr[indexPath.row]
        
        if(type == "HEADER") {
        let cell: DPBrandingReviewSubHeaderCell = tableView.dequeueReusableCellWithIdentifier("DPBrandingReviewSubHeaderIdentifierCell", forIndexPath: indexPath) as! DPBrandingReviewSubHeaderCell
            let label: UILabel? = cell.viewWithTag(80) as? UILabel
            label?.text = subHeader
            cell.selectionStyle = .None
            return cell
        }
        
        if(type == "BROKER LICENSE INFORMATION")
        {
            let cell: DPBrandingLicenseTableViewCell = tableView.dequeueReusableCellWithIdentifier("DPBrandingLicenseCellIdentifierCell", forIndexPath: indexPath) as! DPBrandingLicenseTableViewCell
            let arrayVal = value.componentsSeparatedByString(",")
            if arrayVal.count > 1 {
                cell.brokerLicenseInfo.text = arrayVal[0]
                cell.brokerLicenseStateInfo.text = arrayVal[1]
            }
            cell.selectionStyle = .None
            return cell
        }
        
        if(type == "BROKER MLS INFORMATION")
        {
            let cell: DPBrandingReviewMLSInfoTableViewCell = tableView.dequeueReusableCellWithIdentifier("DDPBrandingReviewMLSInfoCellIdentifierCell", forIndexPath: indexPath) as! DPBrandingReviewMLSInfoTableViewCell
            let arrayVal = value.componentsSeparatedByString(",")
            if arrayVal.count > 1 {
                cell.brokerMLSBrokerageIDInfo.text = arrayVal[0]
                cell.brokerMLSNameInfo.text = arrayVal[1]
            }
            cell.selectionStyle = .None
            return cell
        }
        
        if(type == "BROKER BRANDING") {
            let cell: DPBrandingReviewOptionalTableViewCell = tableView.dequeueReusableCellWithIdentifier("DPBrandingReviewOptionaCellIdentifierCell", forIndexPath: indexPath) as! DPBrandingReviewOptionalTableViewCell
            
            if value == "false" {
                let imageCheck: UIImageView? = cell.viewWithTag(111) as? UIImageView
                imageCheck?.image = UIImageCustom().getImageFromString("stepSkipped")
            }
            
            let label: UILabel? = cell.viewWithTag(110) as? UILabel
            label?.text = subHeader
            cell.selectionStyle = .None
            return cell
        }
        
        let cell: DPBrandingReviewMenuCell = tableView.dequeueReusableCellWithIdentifier("DPBrandingReviewMenuCellIdentifierCell", forIndexPath: indexPath) as! DPBrandingReviewMenuCell
        let label: UILabel? = cell.viewWithTag(80) as? UILabel
        label?.text = subHeader
        let labelSub: UILabel? = cell.viewWithTag(81) as? UILabel
        labelSub?.text = value
        cell.selectionStyle = .None
        return cell
    }
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        if text == "\n" {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    func textViewDidBeginEditing(textView: UITextView) {
        textView.text = ""
        
    }
}
