//
//  TemplateView.swift
//  ProfessionalTools
//
//  Created by MacMini5 on 21/10/15.
//  Copyright © 2015 Xome. All rights reserved.

//

import UIKit

class TemplateView: NSObject, UITableViewDelegate, UITableViewDataSource {
    
    var cgScreenWidth:  CGFloat!
    var cgScreenHeight: CGFloat!
    var tableValues:    NSMutableArray!
    var mainView:       UIView!
    var headerView:     UIView!
    var btnXheader:     UIButton!
    var imgHeader:      UIImageView!
    var lblHeaderRight: UILabel!
    var tblData:        UITableView!
    
    func createTemplate(inViewController:UIViewController, inDataArray:NSMutableArray){
        
        self.createUIElements()
        self.setProperties(inDataArray)
        self.addElementstoUI(inViewController)
    }
    
    func getScreenDimensions(){
        
        let screenDimensions = UIScreen.mainScreen().bounds
        cgScreenWidth   = screenDimensions.width
        cgScreenHeight  = screenDimensions.height
    }
    
    func centreX(inWidth: Int)->CGFloat{
        
        let tWidth:CGFloat  = cgScreenWidth - CGFloat(inWidth)
        let pX: CGFloat     = tWidth/2
        
        return pX
    }
    
    func createUIElements(){
     
        let imgX: CGFloat  = self.centreX(40)
        mainView       = UIView(frame:CGRectMake(0, 0, cgScreenWidth, cgScreenHeight))
        headerView     = UIView(frame:CGRectMake(0, 0, cgScreenWidth, 45))
        btnXheader     = UIButton(frame:CGRectMake(0, 5, 40, 40))
        imgHeader      = UIImageView(frame:CGRectMake(imgX, 5, 40, 40))
        lblHeaderRight = UILabel()
        tblData        = UITableView()
    }
    
    func setProperties(inDataArray:NSMutableArray){
       
        tableValues = inDataArray
        tblData.dataSource = self
        tblData.delegate = self
    }
    
    func addElementstoUI(inController:UIViewController){
   
        
    }
    
    
    //////////////////////////////////////////////////////////////////////
    //TableView delegates for creating table size, populating and actions
    //////////////////////////////////////////////////////////////////////
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        

    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return 1
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        
        return 60
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
        
        let cell : UITableViewCell = UITableViewCell(style: UITableViewCellStyle.Default, reuseIdentifier: "cell")

        return cell
    }

    

}
