//
//  PropertyStructs.swift
//  XomeRestClient
//
//  Created by David Parton on 1/29/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import CoreLocation
import MapKit

public enum PropertySortOption: Int {
    case PriceHighToLow = 6
    case PriceLowToHigh = 1
    case DateListed = 5
    case DateSold = 22
    case CityAtoZ = 4
    case CityZtoA = 7
    case Nearest = 21 // note: this sort option only makes sense for radius searches
}

public enum PropertyQueryType: String {
    case City = "City"
    case County = "County"
    case Neighborhood = "Neighborhood"
    case Address = "Address"
    case ElementarySchool = "Elementary School"
    case MiddleSchool = "Middle School"
    case HighSchool = "High School"
    case SchoolDistrict = "School District"
    case ZipCode = "Zip Code"
    case MLS = "MLS #"
    case Radius = "Radius"
    case RegionCity = "Region City"
    case RegionZip = "Region Zip"
    case CurrentLocation = "Current Location"
}

@objc public enum PropertyMapLayerType: Int {
    case ParcelLines, Neighborhoods, Subdivisions, ElementarySchools, MiddleSchools, HighSchools
}

public struct PropertySearchRegion {
    public let northEast: CLLocationCoordinate2D
    public let southWest: CLLocationCoordinate2D
    public let filter:    PropertySearchFilter
    
    public var coordinateRegion: MKCoordinateRegion {
        let latDelta = abs(northEast.latitude - southWest.latitude)/2
        let lonDelta = abs(northEast.longitude - southWest.longitude)/2
        let lat = northEast.latitude - latDelta
        let lon = northEast.longitude - lonDelta
        let center = CLLocationCoordinate2DMake(lat, lon)
        let span = MKCoordinateSpanMake(latDelta, lonDelta)
        return MKCoordinateRegionMake(center, span)
    }
    
    public init(northEast: CLLocationCoordinate2D, southWest: CLLocationCoordinate2D, filter: PropertySearchFilter) {
        self.northEast = northEast
        self.southWest = southWest
        self.filter = filter
    }
}

public struct PropertySearchPolygon {
    public let points: [CLLocationCoordinate2D]
    public let filter: PropertySearchFilter

    public init(points: [CLLocationCoordinate2D], filter: PropertySearchFilter) {
        self.points = points
        self.filter = filter
    }
}

