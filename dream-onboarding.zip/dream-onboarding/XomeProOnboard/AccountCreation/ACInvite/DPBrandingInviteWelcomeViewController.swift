//
//  DPBrandingInviteWelcomeViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/20/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrandingInviteWelcomeViewController: DPAccountCreationBaseViewController {
    
    func inVite (sender: AnyObject) {
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            let vc = DPBrandingInviteViewController()
            self.navigationItem.backBarButtonItem?.title = " "
            vc.eState = flowStateInvite.ICLIENT
            self.navigationController?.pushViewController(vc, animated: true)
            return
        }
        
        let nextViewController: DPBrandingInviteViewController = DPBrandingInviteViewController()
        self.navigationItem.backBarButtonItem?.title = " "
        nextViewController.eState = flowStateInvite.IAGENT
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
    override func skipViewC1(sender: UIBarButtonItem) {
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            let nextViewController: DPBrandingSetupCompleteViewController = DPBrandingSetupCompleteViewController()
            self.navigationItem.backBarButtonItem?.title = " "
            self.navigationController?.pushViewController(nextViewController, animated: true)
            return
        }
        let nextViewController: DPBrandingInviteViewController = DPBrandingInviteViewController()
        self.navigationItem.backBarButtonItem?.title = " "
        nextViewController.eState = flowStateInvite.ICLIENT
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.navigationItem.title = "Account Created"
        self.navigationItem.setHidesBackButton(true, animated: false)
        
        self.view.backgroundColor = UIColor.lightGrayColor()
        
        let viewBackGround: UIView  = UIView()
        viewBackGround.backgroundColor = UIColor.whiteColor()
        self.view.addSubview(viewBackGround)
        
        viewBackGround.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self.view).offset(168)
            make.leading.equalTo(self.view).offset(5)
            make.trailing.equalTo(self.view).offset(-5)
            make.bottom.equalTo(self.view).offset(-50)
        }
        
        let headerLbl: UILabel = UILabel()
        headerLbl.text = "Invite Your Agents"
        headerLbl.font = UIFont(name: MuseoSansRounded100Font, size: 20)
        headerLbl.numberOfLines=0
        headerLbl.textAlignment = .Center
        headerLbl.textColor = UIColor.baoGunmetalColor()
        viewBackGround.addSubview(headerLbl)
        
        let imageCompleted: UIImageView = UIImageView()
        imageCompleted.image = UIImageCustom().getImageFromString("inviteAgents")
        viewBackGround.addSubview(imageCompleted)
        
        let headerSubLbl: UILabel = UILabel()
        headerSubLbl.numberOfLines = 0
        headerSubLbl.textAlignment = .Center
        headerSubLbl.text = "Invite your agents to use your branded app."
        headerSubLbl.font = UIFont(name: MuseoSansRounded300Font, size: 16)
        headerSubLbl.textColor = UIColor.baoGunmetalColor()
        viewBackGround.addSubview(headerSubLbl)
        
        let continueOnBoarding: UIButton = UIButton()
        continueOnBoarding.backgroundColor = UIColor.baoGunmetalColor()
        continueOnBoarding.titleLabel?.font = UIFont(name: MuseoSansRounded300Font, size: 16.0)
        continueOnBoarding.setTitle("Let's Start", forState: .Normal)
        continueOnBoarding.addTarget(self, action: "inVite:", forControlEvents: .TouchUpInside)
        continueOnBoarding.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        self.view.addSubview(continueOnBoarding)
        
        headerLbl.snp_makeConstraints {(make) ->Void in
            make.top.equalTo(viewBackGround).offset(50)
            make.leading.equalTo(viewBackGround).offset(10)
            make.trailing.equalTo(viewBackGround).offset(-10)
        }
        
        imageCompleted.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(headerLbl).offset(50)
            make.centerX.equalTo(viewBackGround).offset(0)
            make.width.equalTo(356)
            make.height.equalTo(178)
        }
        
        headerSubLbl.snp_makeConstraints {(make) ->Void in
            make.bottom.equalTo(imageCompleted).offset(30)
            make.leading.equalTo(viewBackGround).offset(10)
            make.trailing.equalTo(viewBackGround).offset(-10)
        }
        
        continueOnBoarding.snp_makeConstraints {(make) ->Void in
            make.leading.equalTo(self.view).offset(0)
            make.trailing.equalTo(self.view).offset(0)
            make.bottom.equalTo(self.view).offset(0)
            make.height.equalTo(50)
        }
        
        self.setStepIndication(tagStep1, state: 5)
        self.setStepIndication(tagStep2, state: 5)
        self.setStepIndication(tagStep3, state: 5)
        
        self.createSkipbutton()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
