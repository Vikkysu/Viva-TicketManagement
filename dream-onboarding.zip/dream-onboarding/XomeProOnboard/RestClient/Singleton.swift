import Foundation

final class Singleton {

    class var instance: Singleton {
        return Static.instance
    }

    let env: Env

    let restClient: RestClient
    let createBrokerage: createBrokerageAccount
    // MARK: private

    private init() {
        env = ProdEnv()
        restClient = RestClient(env: env)
        createBrokerage = Process
    }

    private struct Static {
        static let instance = Singleton()
    }
}

final class Api {

    static var createBrokerage: createBrokerageAccount {
        return Singleton.instance.createBrokerage
    }
}

final class Services {

//    static var image: ImageService {
//        return Singleton.instance.imageService
//    }
//    
//    static var defaults: UserDefaultsService {
//        return Singleton.instance.defaultsService
//    }
}