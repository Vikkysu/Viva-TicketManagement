//
//  LegalDocumentRequest.swift
//  XomeRestClient
//
//  Created by Shivakumar Chandramouli on 4/4/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class UpdateConsentRequestModel: NSObject, Mappable {

    public var consentStatus : Bool?
    public var documentId: Double?
    public var disclosureType: Double?
    public var version: String?
    public var documentTitle: String?
    public var displayConsentStatus: String?
    public var metaData: MetaData?
    
    override public init() {
        
    }
    
    required public init?(_ map: Map) {
        
    }
    
    public func mapping(map: Map) {
        
        consentStatus <- map["consentStatus"]
        documentId <- map["documentId"]
        disclosureType <- map["disclosureType"]
        version <- map["version"]
        documentTitle <- map["documentTitle"]
        displayConsentStatus <- map["displayConsentStatus"]
        metaData <- map["metaData"]
    }

}
