//
//  XomeRestClientAssembly.swift
//  XomeRestClient
//
//  Created by Vikas on 9/28/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import XomeAssembly

public class XomeRestClientAssembly : TyphoonAssembly, XomeAssemblyInitialComponent {

    public dynamic func restClientConfig() -> AnyObject {
        return TyphoonDefinition.configDefinitionWithName("XomeRestClient.config.properties", bundle: NSBundle(forClass: XomeRestClientAssembly.self))
    }

    public dynamic func operationFactory() -> AnyObject {
        return TyphoonDefinition.withClass(XomeRestOperationFactoryDefault.self, configuration: { (definition: TyphoonDefinition!) -> Void in
            definition.injectProperty("environment", with: self.serviceEnvironment())
        })
    }

    public dynamic func propertyDataProvider() -> AnyObject {
        return TyphoonDefinition.withClass(XomeRestPropertyDataProvider.self, configuration: { (definition: TyphoonDefinition!) -> Void in
            definition.injectProperty("operationFactory")
        })
    }

    public dynamic func serviceEnvironment() -> AnyObject {
        return TyphoonDefinition.withClass(XomeServiceEnv.self, configuration: { (definition: TyphoonDefinition!) in
            definition.scope = .Singleton
            for (propertyName,typhoonConfigKey) in self.dynamicType.environmentMapping() {
                definition.injectProperty(Selector(propertyName), with: TyphoonConfig(typhoonConfigKey))
            }
        })
    }

    static internal func environmentMapping() -> [String:String] {
        return [
            "prodApiEndpoint": "Environment.Xome.Prod.URL",
            "stageApiEndpoint": "Environment.Xome.Stage.URL",
            "qaApiEndpoint": "Environment.Xome.QA.URL",
            "commonApiKey": "Environment.Common.apiKey",
            "prodWebURL": "Environment.Xome.Prod.WebURL",
            "stageWebURL": "Environment.Xome.Stage.WebURL",
            "qaWebURL": "Environment.Xome.Prod.WebURL",
            "prodSocialLoginURL": "Environment.Xome.Prod.SocialLoginURL",
            "stageSocialLoginURL": "Environment.Xome.Stage.SocialLoginURL",
            "qaSocialLoginURL": "Environment.Xome.Prod.SocialLoginURL",
            "prodSocialLoginDomainParam": "Environment.Xome.Prod.SocialLoginDomainParam",
            "stageSocialLoginDomainParam": "Environment.Xome.Stage.SocialLoginDomainParam",
            "qaSocialLoginDomainParam": "Environment.Xome.Prod.SocialLoginDomainParam",
            "cookieName": "Environment.Xome.CookieName",
            "webCookieName": "Environment.Xome.WebCookieName",
            "prodCookieHost": "Environment.Xome.Prod.CookieHost",
            "stageCookieHost": "Environment.Xome.Stage.CookieHost",
            "qaCookieHost": "Environment.Xome.QA.CookieHost",
            "prodWebCookieHost": "Environment.Xome.Prod.WebCookieHost",
            "stageWebCookieHost": "Environment.Xome.Stage.WebCookieHost",
            "qaWebCookieHost": "Environment.Xome.QA.WebCookieHost",
            "cookieExpirationString": "Environment.Xome.CookieExpiration"
        ]
    }
}
