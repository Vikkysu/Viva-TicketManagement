//
//  XomeServiceEnv.swift
//  XomeRestClient
//
//  Created by Brendan Farrington on 11/5/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation

let defaultEnv = "prod"

@objc public class XomeServiceEnv : NSObject, XomeRestClientServiceEnvironment {
    // HACK: This singleton accessor shouldn't exist at all. 
    // For now make it a computed property and read the singleton out of the object created from the assembly.
    // This relies on the fact that the definition's scope for XomeServiceEnv is not LazySingleton of WeakSingleton
    private static weak var _sharedInstance : XomeServiceEnv?
    public static var sharedInstance : XomeServiceEnv {
        return _sharedInstance!
    }

    var prodApiEndpoint : String!
    var stageApiEndpoint : String!
    var qaApiEndpoint : String!
    var prodWebURL : String!
    var stageWebURL : String!
    var qaWebURL : String!
    var prodSocialLoginURL : String!
    var stageSocialLoginURL : String!
    var qaSocialLoginURL : String!
    var prodSocialLoginDomainParam : String!
    var stageSocialLoginDomainParam : String!
    var qaSocialLoginDomainParam : String!
    var commonApiKey : String!
    public var cookieName : String!
    public var webCookieName : String!
    var prodCookieHost : String!
    var stageCookieHost : String!
    var qaCookieHost : String!
    var prodWebCookieHost : String!
    var stageWebCookieHost : String!
    var qaWebCookieHost : String!
    var cookieExpirationString : String!

    override init() {
        super.init()
        self.dynamicType._sharedInstance = self
    }

    public func apiEndpoint() -> String {
        let envValue: String = NSUserDefaults.standardUserDefaults().stringForKey("Developer/env") ?? defaultEnv
        switch envValue {
        case "prod": return prodApiEndpoint
        case "stage", "prod": return stageApiEndpoint
        case "qa": return qaApiEndpoint
        default:
            NSLog("ENDPOINT NOT DETERMINED DUE TO UNEXPECTED ENV VALUE - %@", envValue)
            return ""
        }
    }
    
    public func webURLString() -> String {
        let envValue = NSUserDefaults.standardUserDefaults().stringForKey("Developer/env") ?? defaultEnv
        switch envValue {
            case "prod": return prodWebURL
            case "stage": return stageWebURL
            case "qa": return qaWebURL
        default:
            return ""
        }
    }

    public func socialLoginURLString() -> String {
        let envValue = NSUserDefaults.standardUserDefaults().stringForKey("Developer/env") ?? defaultEnv
        switch envValue {
        case "prod": return prodSocialLoginURL
        case "stage": return stageSocialLoginURL
        case "qa": return qaSocialLoginURL
        default:
            return ""
        }
    }

    public func socialLoginDomainParam() -> String {
        let envValue = NSUserDefaults.standardUserDefaults().stringForKey("Developer/env") ?? defaultEnv
        switch envValue {
        case "prod": return prodSocialLoginDomainParam
        case "stage": return stageSocialLoginDomainParam
        case "qa": return qaSocialLoginDomainParam
        default:
            return ""
        }
    }

    public func webURL() -> NSURL? {
        return NSURL(string: webURLString())
    }

    public func apiEndpointURL() -> NSURL? {
        return NSURL(string: apiEndpoint())
    }

    public func socialLoginURL() -> NSURL? {
        return NSURL(string: socialLoginURLString())
    }

    public func apiKey() -> String {
        return commonApiKey
    }

    public func cookieHost() -> String {
        let envValue = NSUserDefaults.standardUserDefaults().stringForKey("Developer/env") ?? defaultEnv
        switch envValue {
        case "prod": return prodCookieHost
        case "stage": return stageCookieHost
        case "qa": return qaCookieHost
        default:
            return ""
        }
    }

    public func webCookieHost() -> String {
        let envValue = NSUserDefaults.standardUserDefaults().stringForKey("Developer/env") ?? defaultEnv
        switch envValue {
        case "prod": return prodWebCookieHost
        case "stage": return stageWebCookieHost
        case "qa": return qaWebCookieHost
        default:
            return ""
        }
    }

    public func cookieExpiration() -> NSTimeInterval {
        return NSTimeInterval(cookieExpirationString) ?? 0
    }
}