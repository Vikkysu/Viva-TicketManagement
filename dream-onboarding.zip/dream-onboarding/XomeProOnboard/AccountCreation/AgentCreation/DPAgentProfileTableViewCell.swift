//
//  DPAgentProfileTableViewCell.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/27/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPAgentProfileTableViewCell: UITableViewCell {
    override init(style: UITableViewCellStyle, reuseIdentifier: String!)
    {
        super.init(style: UITableViewCellStyle.Value1, reuseIdentifier: reuseIdentifier)
        
        var labelTextPass : UILabel
        labelTextPass = UILabel()
        labelTextPass.textAlignment = .Left
        labelTextPass.text = "CREATE PASSWORD"
        labelTextPass.tag=160
        labelTextPass.font = UIFont(name: MuseoSansRounded100Font, size: 11.0)
        self.addSubview(labelTextPass)
        
        let textFieldPass : UITextField = UITextField()
        textFieldPass.font = UIFont(name: MuseoSansRounded100Font, size: 20.0)
        textFieldPass.tag=161
        textFieldPass.secureTextEntry=true
        self.addSubview(textFieldPass)
        
        let displayPassword: UIButton = UIButton()
        displayPassword.setBackgroundImage(UIImageCustom().getImageFromString("showPassword"), forState: UIControlState.Normal)
        displayPassword.tag=162
        displayPassword.hidden=false
        displayPassword.addTarget(self, action: "displayPassword:", forControlEvents: .TouchUpInside)
        self.addSubview(displayPassword)
        
        let separatorLinePass: UIView = UIView()
        separatorLinePass.backgroundColor = UIColor.baoTableBorderColor()
        self.addSubview(separatorLinePass)
        
        var labelTextFirstName : UILabel
        labelTextFirstName = UILabel()
        labelTextFirstName.textAlignment = .Left
        labelTextFirstName.text = "FIRST NAME"
        labelTextFirstName.tag=163
        labelTextFirstName.font = UIFont(name: MuseoSansRounded100Font, size: 11.0)
        self.addSubview(labelTextFirstName)
        
        let textFieldFirstName : UITextField = UITextField()
        textFieldFirstName.font = UIFont(name: MuseoSansRounded100Font, size: 20.0)
        textFieldFirstName.tag=164
        self.addSubview(textFieldFirstName)
        
        var labelTextLastName : UILabel
        labelTextLastName = UILabel()
        labelTextLastName.textAlignment = .Left
        labelTextLastName.tag=165
        labelTextLastName.text = "LAST NAME"
        labelTextLastName.font = UIFont(name: MuseoSansRounded100Font, size: 11.0)
        self.addSubview(labelTextLastName)
        
        let textFieldLastName : UITextField = UITextField()
        textFieldLastName.font = UIFont(name: MuseoSansRounded100Font, size: 20.0)
        textFieldLastName.tag=166
        self.addSubview(textFieldLastName)
        
        let separatorLine: UIView = UIView()
        separatorLine.backgroundColor = UIColor.baoTableBorderColor()
        self.addSubview(separatorLine)
        
        var labelTextEmail : UILabel
        labelTextEmail = UILabel()
        labelTextEmail.textAlignment = .Left
        labelTextEmail.tag=167
        labelTextEmail.text = "EMAIL"
        labelTextEmail.font = UIFont(name: MuseoSansRounded100Font, size: 11.0)
        self.addSubview(labelTextEmail)
        
        let textFieldEmail : UITextField = UITextField()
        textFieldEmail.keyboardType = .EmailAddress
        textFieldEmail.font = UIFont(name: MuseoSansRounded100Font, size: 20.0)
        textFieldEmail.tag=168
        self.addSubview(textFieldEmail)
        
        let separatorLine1: UIView = UIView()
        separatorLine1.backgroundColor = UIColor.baoTableBorderColor()
        self.addSubview(separatorLine1)
        
        var labelTextMobile : UILabel
        labelTextMobile = UILabel()
        labelTextMobile.textAlignment = .Left
        labelTextMobile.tag=169
        labelTextMobile.text = "MOBILE NUMBER"
        labelTextMobile.font = UIFont(name: MuseoSansRounded100Font, size: 11.0)
        self.addSubview(labelTextMobile)
        
        let textFieldMobile : UITextField = UITextField()
        textFieldMobile.font = UIFont(name: MuseoSansRounded100Font, size: 20.0)
        textFieldMobile.keyboardType = .PhonePad
        textFieldMobile.tag=170
        self.addSubview(textFieldMobile)
        
        let separatorLine2: UIView = UIView()
        separatorLine2.backgroundColor = UIColor.baoTableBorderColor()
        self.addSubview(separatorLine2)
        
        var labelTextDesc : UILabel
        labelTextDesc = UILabel()
        labelTextDesc.numberOfLines = 0
        labelTextDesc.textAlignment = .Center
        labelTextDesc.tag=171
        labelTextDesc.text = "Do you already have a Xome.com account?. Use the same email and your Xome leads will automatically flow into Xome Pro"
        labelTextDesc.font = UIFont(name: MuseoSansRounded100Font, size: 11.0)
        self.addSubview(labelTextDesc)
        
        labelTextPass.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self).offset(5)
            make.leading.equalTo(self).offset(10)
            make.height.equalTo(25)
        }
        
        textFieldPass.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(labelTextPass).offset(20)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(10)
            make.height.equalTo(30)
        }
        
        displayPassword.snp_makeConstraints { (make) -> Void in
            make.height.equalTo(12)
            make.width.equalTo(18)
            make.centerY.equalTo(textFieldPass)
            make.trailing.equalTo(self).offset(-10)
        }
        
        separatorLinePass.snp_makeConstraints {(make) -> Void in
            make.bottom.equalTo(textFieldPass).offset(4)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
            make.height.equalTo(1)
        }
        
        labelTextLastName.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(separatorLinePass).offset(5)
            make.centerX.equalTo(self).offset(0)
            make.height.equalTo(25)
        }
        
        textFieldLastName.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(labelTextLastName).offset(20)
            make.leading.equalTo(labelTextLastName).offset(0)
            make.trailing.equalTo(self).offset(-10)
            make.height.equalTo(30)
        }
        
        labelTextFirstName.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(separatorLinePass).offset(5)
            make.leading.equalTo(self).offset(10)
            make.height.equalTo(25)
        }
        
        textFieldFirstName.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(labelTextFirstName).offset(20)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(textFieldLastName).offset(10)
            make.height.equalTo(30)
        }
        
        separatorLine.snp_makeConstraints {(make) -> Void in
            make.bottom.equalTo(textFieldFirstName).offset(4)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
            make.height.equalTo(1)
        }
        
        labelTextEmail.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(separatorLine).offset(5)
            make.leading.equalTo(self).offset(10)
            make.height.equalTo(25)
        }
        
        textFieldEmail.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(labelTextEmail).offset(20)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
            make.height.equalTo(30)
        }
        
        separatorLine1.snp_makeConstraints {(make) -> Void in
            make.bottom.equalTo(textFieldEmail).offset(4)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
            make.height.equalTo(1)
        }
        
        labelTextMobile.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(separatorLine1).offset(5)
            make.leading.equalTo(self).offset(10)
            make.height.equalTo(25)
        }
        
        textFieldMobile.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(labelTextMobile).offset(20)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
            make.height.equalTo(30)
        }
        
        separatorLine2.snp_makeConstraints {(make) -> Void in
            make.bottom.equalTo(textFieldMobile).offset(4)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
            make.height.equalTo(1)
        }
        
        labelTextDesc.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(separatorLine2).offset(5)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
        }
        
    }
    
    func displayPassword(sender : AnyObject) {
        let textFieldFirstName: UITextField? = self.viewWithTag(161) as? UITextField
        
        if let textField1 = textFieldFirstName {
            textField1.secureTextEntry = !textField1.secureTextEntry
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setSelected(selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
    
}
