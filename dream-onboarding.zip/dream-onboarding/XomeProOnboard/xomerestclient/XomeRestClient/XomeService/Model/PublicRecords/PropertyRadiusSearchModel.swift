//
//  NearbyPropertiesRequestModel.swift
//  XomeRestClient
//
//  Created by Xome on 2/11/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class PropertyRadiusSearchModel: PropertySearchFilter {
    public var radiusDistance: Double?
    public var radiusLat: Double?
    public var radiusLong: Double?
    public var searchType: String?
    public var sortId: Int?
    
    public init(radiusDistance: Double? = nil,
        radiusLat: Double? = nil,
        radiusLong: Double? = nil,
        sortId: Int? = nil,
        filterModel: PropertyFilterModel? = nil)
    {
        let searchFilter = PropertySearchFilter(filterModel: filterModel)
        super.init(other: searchFilter)
        self.sortId = sortId
        self.radiusDistance = radiusDistance
        self.radiusLat = radiusLat
        self.radiusLong = radiusLong
        self.searchType = "radius"
    }
    
    required public init?(_ map: Map) {
        super.init(map)
    }
    
    public override func mapping(map: Map) {
        super.mapping(map)
        radiusDistance <- map["radiusDistance"]
        radiusLat <- map["radiusLat"]
        radiusLong <- map["radiusLong"]
        searchType <- map["searchType"]
        sortId <- map["sortId"]
    }
}