//
//  BrokerageHomeView.swift
//  ProfessionalTools
//
//  Created by Pike Dev 01 on 25/10/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class BrokerageHomeView: NSObject,UITableViewDataSource,UITableViewDelegate {
    var brokerageDataArray       :NSMutableArray!
    var vwController                    :UIViewController!
    var vwMain                            :UIView!
    var vwHeader                       : UIView!
    
    var lblHeader               :   UILabel!
    var vwSubHeader             :   UIView!
    var lblSubHeader            :   UILabel!
    var vwDivider               :   UIView!
    var lblTag1                 :   UILabel!
    var lblTag2                 :   UILabel!

    var lblHeader1              :   UILabel!
    var lblHeader2              :   UILabel!
    var lblHeader3              :   UILabel!

    var imgAlert                :   UIImageView!
    var imgLeads                :   UIImageView!
    var imgTask                 :   UIImageView!
    
    
    var vwDivider1              :   UIView!
    var vwDivider2              :   UIView!
    
    var lblAlerts               : UILabel!
    var lblLeads                : UILabel!
    var lblTasks                : UILabel!
    
    var lblRecentActivity       : UILabel!
    
    var tableView               : UITableView!


    
    
    
    
    var cgScreenWidth               :CGFloat!
    var cgScreenHeight              :CGFloat!
    
    func loadBrokerageHomeUI(inViewController :UIViewController, inDataArray :NSMutableArray){
        
        vwController            = inViewController
        brokerageDataArray      = inDataArray
        
        getScreenDimensions()
        createUIElements()
        setProperties()
        setProfileData()
        addElements2UI()
    }
    
    
    func getScreenDimensions(){
        
        let screenDimensions = UIScreen.mainScreen().bounds
        cgScreenWidth        = screenDimensions.width
        cgScreenHeight       = screenDimensions.height
    }
    
    func centreX(inWidth: CGFloat)->CGFloat{
        
        let tWidth:CGFloat  = cgScreenWidth - CGFloat(inWidth)
        let pX: CGFloat     = tWidth/2
        
        return pX
    }
    
    func centreY(inHeight: CGFloat)->CGFloat{
        
        let tHeight:CGFloat  = cgScreenHeight - CGFloat(inHeight)
        let pY: CGFloat      = tHeight/2
        
        return pY
    }
    
    func convert2Pixels(points:CGFloat)->CGFloat{
        
        let pixels  :CGFloat = points * 96 / 72
        return pixels
    }
    
    func createUIElements(){
        
        let hdrVwHeight :CGFloat = self.convert2Pixels(260)
        let lblhX       :CGFloat = self.convert2Pixels(110)
        let lblhY      :CGFloat  = self.convert2Pixels(31)
        let lblhW       :CGFloat = self.convert2Pixels(137)
        let lblhH      :CGFloat = self.convert2Pixels(22)
        
        let vwshX       :CGFloat = self.convert2Pixels(100)
        let vwshY      :CGFloat  = self.convert2Pixels(79)
        let vwshW       :CGFloat = self.convert2Pixels(124)
        let vwshH      :CGFloat  = self.convert2Pixels(66)
        
        let lblshX       :CGFloat = 20
        let lblshY       :CGFloat = 10
        
        let lblshW       :CGFloat = self.convert2Pixels(105)
        let lblshH      :CGFloat  = self.convert2Pixels(32)
        
        let lblh1X       :CGFloat = self.convert2Pixels(70)
        let lblh1Y      :CGFloat  = self.convert2Pixels(153)
        let lblh1W       :CGFloat = self.convert2Pixels(236)
        let lblh1H      :CGFloat  = self.convert2Pixels(20)

        let lblh2X       :CGFloat = self.convert2Pixels(112)
        let lblh2Y      :CGFloat  = self.convert2Pixels(174)
        let lblh2W       :CGFloat = self.convert2Pixels(130)
        let lblh2H      :CGFloat  = self.convert2Pixels(24)
        
        let lblh3X       :CGFloat = self.convert2Pixels(122)
        let lblh3Y      :CGFloat  = self.convert2Pixels(191)
        let lblh3W       :CGFloat = self.convert2Pixels(158)
        let lblh3H      :CGFloat  = self.convert2Pixels(12)
        
    
        let imgAX       :CGFloat = self.convert2Pixels(55)
        let imgAY       :CGFloat  = self.convert2Pixels(204)
        let imgAW       :CGFloat = self.convert2Pixels(18)
        let imgAH       :CGFloat  = self.convert2Pixels(18)
        
        let imgLX       :CGFloat = self.convert2Pixels(155)
        let imgLY       :CGFloat  = self.convert2Pixels(208)
        let imgLW       :CGFloat = self.convert2Pixels(22)
        let imgLH       :CGFloat  = self.convert2Pixels(13)
        
        let imgTX       :CGFloat = self.convert2Pixels(252)
        let imgTY       :CGFloat  = self.convert2Pixels(204)
        let imgTW       :CGFloat = self.convert2Pixels(21)
        let imgTH       :CGFloat  = self.convert2Pixels(21)
        
        

        vwMain              = UIView(frame:CGRectMake(0, 0, cgScreenWidth, cgScreenHeight))
        vwHeader            = UIView(frame:CGRectMake(0, 0, cgScreenWidth, hdrVwHeight))
        lblHeader           = UILabel(frame:CGRectMake(lblhX,lblhY,lblhW,lblhH))
        vwSubHeader         = UIView(frame:CGRectMake(vwshX , vwshY, vwshW, vwshH))
        lblSubHeader        = UILabel(frame:CGRectMake(lblshX,lblshY,lblshW,lblshH))
        vwDivider           = UIView(frame: CGRectMake(lblshX, lblshY+lblshH-10, lblshW-20, 2))
        lblTag1             = UILabel(frame:CGRectMake(lblshX,lblshY+lblshH-5,lblshW,20))
        lblTag2             = UILabel(frame:CGRectMake(lblshX,lblshY+lblshH+12,lblshW,20))
        lblHeader1          = UILabel(frame:CGRectMake(lblh1X,lblh1Y,lblh1W,lblh1H))
        lblHeader2          = UILabel(frame:CGRectMake(lblh2X,lblh2Y,lblh2W,lblh2H))
        lblHeader3          = UILabel(frame:CGRectMake(lblh3X,lblh3Y,lblh3W,lblh3H))
        
        imgAlert            = UIImageView(frame: CGRectMake(imgAX, imgAY, imgAW, imgAH))
        imgLeads            = UIImageView(frame: CGRectMake(imgLX, imgLY, imgLW, imgLH))
        imgTask             = UIImageView(frame: CGRectMake(imgTX, imgTY, imgTW, imgTH))

        vwDivider1          = UIView(frame: CGRectMake(imgAX+imgAW+50, imgAY, 1, imgAH+30))
        vwDivider2          = UIView(frame: CGRectMake(imgLX+imgLW+50, imgLY, 1, imgAH+30))
        
        
        lblAlerts           = UILabel(frame:CGRectMake(imgAX-5,imgAY+imgAH+5,imgAW+30,lblh1H))
        lblLeads            = UILabel(frame:CGRectMake(imgLX-5,imgLY+imgLH+5,imgLW+30,lblh1H))
        lblTasks            = UILabel(frame:CGRectMake(imgTX-5,imgTY+imgTH+5,imgTW+30,lblh1H))

        
        lblRecentActivity   = UILabel(frame:CGRectMake(20,hdrVwHeight+10,lblh1W,lblh1H))
        
        tableView           = UITableView(frame: CGRectMake(0, hdrVwHeight+lblh1H+20, cgScreenWidth, cgScreenHeight-hdrVwHeight-lblh1H-70))


        
    }
    
    func setProperties(){
        
        vwMain.backgroundColor          = UIColor(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
        vwHeader.backgroundColor        = UIColor(red: 217/255, green: 19/255, blue: 9/255, alpha: 1)
        vwSubHeader.backgroundColor     = UIColor.whiteColor()
        lblHeader.textColor             = UIColor.whiteColor()
        let headerFont      :UIFont     = UIFont(name: "MuseoSansRounded-300", size: 18.0)!
        lblHeader.font                  = headerFont
        lblHeader.text                  = "Brokerage Home"
        
        lblSubHeader.textColor          = UIColor(red: 217/255, green: 19/255, blue: 9/255, alpha: 1)
        let subheaderFont      :UIFont  = UIFont(name: "MuseoSansRounded-300", size: 24.0)!
        lblSubHeader.font               = subheaderFont
        lblSubHeader.text               = "MEREDITH"
        
        vwDivider.backgroundColor       = UIColor(red: 217/255, green: 19/255, blue: 9/255, alpha: 1)
        
        
        lblTag1.textColor          = UIColor(red: 217/255, green: 19/255, blue: 9/255, alpha: 1)
        let tag1Font      :UIFont  = UIFont(name: "MuseoSansRounded-300", size: 10.0)!
        lblTag1.font               = tag1Font
        lblTag1.text               = "FINE PROPERTIES GROUP"
        
        lblTag2.textColor          = UIColor(red: 217/255, green: 19/255, blue: 9/255, alpha: 1)
        let tag2Font      :UIFont  = UIFont(name: "MuseoSansRounded-300", size: 7.0)!
        lblTag2.font               = tag2Font
        lblTag2.text               = "OF LONG & FOSTER REAL ESTATE, INC"
        
        lblHeader1.textColor          = UIColor.whiteColor()
        let lblHeader1Font    :UIFont = UIFont(name: "MuseoSansRounded-300", size: 17.0)!
        lblHeader1.font               = lblHeader1Font
        lblHeader1.text               = "Meredith Fine Properties Group"
        
        
        lblHeader2.textColor          = UIColor.whiteColor()
        let lblHeader2Font    :UIFont = UIFont(name: "MuseoSansRounded-300", size: 12.0)!
        lblHeader2.font               = lblHeader2Font
        lblHeader2.text               = "Brokerage in Seattle, WA"
        
        
        lblHeader3.textColor          = UIColor.whiteColor()
        let lblHeader3Font    :UIFont = UIFont(name: "MuseoSansRounded-300", size: 10.0)!
        lblHeader3.font               = lblHeader3Font
        lblHeader3.text               = "Courtney Abbott, Managing Broker"
        
        imgAlert.image                = UIImage(named: "taskalertsInactive@3x.png")
        imgLeads.image                = UIImage(named: "discoverCopy@3x.png")
        imgTask.image                 = UIImage(named: "plus@3x.png")
        
        vwDivider1.backgroundColor    = UIColor.whiteColor()
        vwDivider2.backgroundColor    = UIColor.whiteColor()
        
        
        lblAlerts.textColor          = UIColor.whiteColor()
        let lblAlertsFont    :UIFont = UIFont(name: "MuseoSansRounded-500", size: 11.0)!
        lblAlerts.font               = lblAlertsFont
        lblAlerts.text               = "ALERTS"
        

        

        lblLeads.textColor           = UIColor.whiteColor()
        lblLeads.font                = lblAlertsFont
        lblLeads.text                = "LEADS"
        
        
        lblTasks.textColor           = UIColor.whiteColor()
        lblTasks.font                = lblAlertsFont
        lblTasks.text                = "TASKS"
        
        
        
        lblRecentActivity.textColor  = UIColor(red: 155/255, green: 155/255, blue: 155/255, alpha: 1)
        let lblRecentFont    :UIFont = UIFont(name: "MuseoSansRounded-300", size: 15.0)!
        lblRecentActivity.font       = lblRecentFont
        lblRecentActivity.text       = "RECENT ACTIVITY"
        
        tableView.dataSource         = self
        tableView.delegate           = self
        
        
    }
    
    func setProfileData(){
    }
    
    func addElements2UI(){
        
        vwController.view.addSubview(vwMain)
        vwMain.addSubview(vwHeader)
        vwHeader.addSubview(lblHeader)
        vwHeader.addSubview(vwSubHeader)
        
        vwSubHeader.addSubview(lblSubHeader)
        vwSubHeader.addSubview(vwDivider)
        vwSubHeader.addSubview(lblTag1)
        vwSubHeader.addSubview(lblTag2)
        
        vwHeader.addSubview(lblHeader1)
        vwHeader.addSubview(lblHeader2)
        vwHeader.addSubview(lblHeader3)
        vwHeader.addSubview(imgAlert)
        vwHeader.addSubview(imgLeads)
        vwHeader.addSubview(imgTask)
        vwHeader.addSubview(vwDivider1)
        vwHeader.addSubview(vwDivider2)
        vwHeader.addSubview(lblAlerts)
        vwHeader.addSubview(lblLeads)
        vwHeader.addSubview(lblTasks)
        
        vwMain.addSubview(lblRecentActivity)
        vwMain.addSubview(tableView)

    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return 5
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat{
        return 63
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
        
        //variable type is inferred
        var cell = tableView.dequeueReusableCellWithIdentifier("CELL")
        
        if cell == nil {
            cell = UITableViewCell(style: UITableViewCellStyle.Value1, reuseIdentifier: "CELL")
            let typeIcon : UIImageView       = UIImageView(frame: CGRectMake(15, 25, 25, 25))
//            typeIcon.autoresizingMask = [UIViewAutoresizing.FlexibleBottomMargin , UIViewAutoresizing.FlexibleHeight , UIViewAutoresizing.FlexibleRightMargin , UIViewAutoresizing.FlexibleLeftMargin , UIViewAutoresizing.FlexibleTopMargin , UIViewAutoresizing.FlexibleWidth]
            typeIcon.contentMode = UIViewContentMode.ScaleAspectFit
            typeIcon.tag                     = 1
            
            let type  :UILabel               = UILabel(frame: CGRectMake(52, 15, 250, 20))
            type.textColor                   = UIColor(red: 51/255, green: 51/255, blue: 51/255, alpha: 1)
            type.font                        = UIFont(name: "MuseoSansRounded-500", size: 15.0)!
            type.tag                         = 2
            
            let typeTag  :UILabel            = UILabel(frame: CGRectMake(52, 37, 250, 20))
            typeTag.textColor                = UIColor(red: 51/255, green: 51/255, blue: 51/255, alpha: 1)
            typeTag.font                     = UIFont(name: "MuseoSansRounded-300", size: 11.0)!
            typeTag.tag                      = 3

            
            let checkMarkImg : UIImageView   = UIImageView(frame: CGRectMake(cgScreenWidth-45, 25, 10, 7))
            checkMarkImg.image               = UIImage(named: "path17Copy6@3x.png")
            checkMarkImg.tag                 = 4
            
            cell?.addSubview(typeIcon)
            cell?.addSubview(type)
            cell?.addSubview(typeTag)
            cell?.addSubview(checkMarkImg)

        }
        
        let currentDictionary : NSMutableDictionary = brokerageDataArray.objectAtIndex(indexPath.row) as! NSMutableDictionary
        let typeIcon   :UIImageView = cell?.viewWithTag(1) as! UIImageView
        let type     :UILabel = cell?.viewWithTag(2) as! UILabel
        let typeTag     :UILabel = cell?.viewWithTag(3) as! UILabel

        
        typeIcon.image  = UIImage(named: currentDictionary.objectForKey("imgName") as! String)
        type.text      = String(currentDictionary.objectForKey("typeName")) //as! String
        typeTag.text   = currentDictionary.objectForKey("tag") as? String
        

        
        return cell!
    }
    

    
    
}
