//
//  DPBrandingReviewMLSInfoTableViewCell.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/13/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrandingReviewMLSInfoTableViewCell: UITableViewCell {
    var brokerMLSBrokerageIDInfo: UILabel!
    var brokerMLSNameInfo: UILabel!
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String!)
    {
        super.init(style: UITableViewCellStyle.Value1, reuseIdentifier: reuseIdentifier)
        var imageCheck : UIImageView
        imageCheck = UIImageView()
        imageCheck.image = UIImageCustom().getImageFromString("stepCompletion")
        self.addSubview(imageCheck)
        
        var labelTextBL : UILabel
        labelTextBL = UILabel()
        labelTextBL.numberOfLines=0
        labelTextBL.textAlignment = .Center
        labelTextBL.tag=100
        labelTextBL.backgroundColor=UIColor.clearColor()
        labelTextBL.font = UIFont(name: MuseoSansRounded300Font, size: 12.0)
        labelTextBL.text = "MLS BROKERAGE ID"
        self.addSubview(labelTextBL)
        
        let textFieldBL : UILabel = UILabel()
        textFieldBL.font = UIFont(name: MuseoSansRounded300Font, size: 20.0)
        textFieldBL.tag=101
        self.addSubview(textFieldBL)
        brokerMLSBrokerageIDInfo = textFieldBL
        
        let separatorLine: UIView = UIView()
        separatorLine.backgroundColor = UIColor.baoTableBorderColor()
        self.addSubview(separatorLine)
        
        var labelTextState : UILabel
        labelTextState = UILabel()
        labelTextState.numberOfLines=0
        labelTextState.textAlignment = .Right
        labelTextState.tag=102
        labelTextState.text="MLS NAME"
        labelTextState.backgroundColor=UIColor.clearColor()
        labelTextState.font = UIFont(name: MuseoSansRounded300Font, size: 12.0)
        self.addSubview(labelTextState)
        
        let textFieldState : UILabel = UILabel()
        textFieldState.font = UIFont(name: MuseoSansRounded300Font, size: 20.0)
        textFieldState.tag=103
        self.addSubview(textFieldState)
        brokerMLSNameInfo = textFieldState
                
        let separatorLineEnd: UIView = UIView()
        separatorLineEnd.backgroundColor = UIColor.baoTableBorderColor()
        self.addSubview(separatorLineEnd)
        
        imageCheck.snp_makeConstraints { (make) -> Void in
            make.centerY.equalTo(self).offset(0)
            make.leading.equalTo(self).offset(35)
            make.height.equalTo(25)
            make.width.equalTo(25)
        }
        
        labelTextBL.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self).offset(5)
            make.leading.equalTo(imageCheck).offset(40)
            make.height.equalTo(25)
        }
        
        textFieldBL.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(labelTextBL).offset(20)
            make.leading.equalTo(imageCheck).offset(40)
            make.trailing.equalTo(self).offset(-10)
            make.height.equalTo(30)
        }
        
        labelTextState.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(textFieldBL).offset(25)
            make.leading.equalTo(labelTextBL).offset(0)
            make.height.equalTo(25)
        }
        
        separatorLine.snp_makeConstraints {(make) -> Void in
            make.bottom.equalTo(textFieldBL).offset(-1)
            make.leading.equalTo(textFieldBL).offset(0)
            make.trailing.equalTo(self).offset(-20)
            make.height.equalTo(1)
        }
        
        textFieldState.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(labelTextState).offset(20)
            make.leading.equalTo(imageCheck).offset(40)
            make.trailing.equalTo(self).offset(-10)
            make.height.equalTo(30)
        }
        
        separatorLineEnd.snp_makeConstraints {(make) -> Void in
            make.bottom.equalTo(self).offset(-1)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
            make.height.equalTo(1)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
