//
//  BrokerageHomeModel.swift
//  ProfessionalTools
//
//  Created by Pike Dev 01 on 25/10/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class BrokerageHomeModel: NSObject {
    var brokerageDataArray      :NSMutableArray = NSMutableArray()
    var brokerageDataDictionary  :NSMutableDictionary   = NSMutableDictionary()
    
    func createAndGetDataSample()->NSMutableArray{
        
        
        brokerageDataDictionary["imgName"]        = "discoverCopy3@3x.png"
        brokerageDataDictionary["typeName"]       = "LEADS"
        brokerageDataDictionary["tag"]            = "3 new leads"
        brokerageDataArray.addObject(brokerageDataDictionary)
        brokerageDataDictionary = NSMutableDictionary(capacity: 0)
        
        brokerageDataDictionary["imgName"]        = "myAgentInactive@3x.png"
        brokerageDataDictionary["typeName"]       = "AGENTS"
        brokerageDataDictionary["tag"]            = "2 agents invited recently"
        
        brokerageDataArray.addObject(brokerageDataDictionary)
        brokerageDataDictionary = NSMutableDictionary(capacity: 0)
        
        brokerageDataDictionary["imgName"]        = "homeInactive@3x.png"
        brokerageDataDictionary["typeName"]    = "LISTINGS"
        brokerageDataDictionary["tag"]      = "5 MLS listings added today"
        
        brokerageDataArray.addObject(brokerageDataDictionary)
        brokerageDataDictionary = NSMutableDictionary(capacity: 0)
        
        brokerageDataDictionary["imgName"]        = "taskalertsInactive@3x.png"
        brokerageDataDictionary["typeName"]    = "ALERTS"
        brokerageDataDictionary["tag"]      = "4 new alerts - 2 messages, 1 notification, 1 reminder"
        
        brokerageDataArray.addObject(brokerageDataDictionary)
        brokerageDataDictionary = NSMutableDictionary(capacity: 0)
        
        brokerageDataDictionary["imgName"]        = "tasksCopy@3x.png"
        brokerageDataDictionary["typeName"]    = "TASKS"
        brokerageDataDictionary["tag"]      = "1 new task"
        
        brokerageDataArray.addObject(brokerageDataDictionary)
        brokerageDataDictionary = NSMutableDictionary(capacity: 0)
        
        brokerageDataDictionary["imgName"]        = "homeInactive@3x.png"
        brokerageDataDictionary["typeName"]    = "TRANSCATION"
        brokerageDataDictionary["tag"]      = "1 ongoing transaction"
        
        brokerageDataArray.addObject(brokerageDataDictionary)
        
        
        return brokerageDataArray
    }

}
