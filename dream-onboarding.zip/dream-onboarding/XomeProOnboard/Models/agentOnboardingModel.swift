//
//  agentOnboardingModel.swift
//  ProfessionalTools
//
//  Created by Vikas on 9/29/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class agentOnboardingModel: NSObject {
    static let sharedInstance = agentOnboardingModel()
    
    var profileModelObj : profileModel!
    
    func getProfileModelObj() ->profileModel {
        return profileModelObj
    }
    
    func profileModelObj(profileModelObject :profileModel) {
        profileModelObj = profileModelObject
        print(profileModelObj.firstNameStr)
        print(profileModelObj.lastNameStr)
        print(profileModelObj.emailStr)
        print(profileModelObj.mobileNumStr)
        print(profileModelObj.passwordStr)
    }
}
