//
//  AssessorModel.swift
//  XomeRestClient
//
//  Created by Xome on 2/4/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class AssessorModel: Mappable {
    
    public var propertyId: Double
    public var latitude: Double
    public var longitude: Double
    
    public var scmId: Double?
    public var stateCode: String?
    public var muniName: String?
    public var fipsStateCode: Int?
    public var fipsMuniCode: Int?
    public var fipsCountyName: String?
    public var yearApnAdded: Int?
    public var owner1: String?
    public var owner1First: String?
    public var owner1Mid: String?
    public var owner1Last: String?
    public var owner1Suffix: String?
    public var owner1SpouseFirst: String?
    public var owner1SpouseMid: String?
    public var owner1SpouseSuffix: String?
    public var owner1Type: String?
    public var owner2: String?
    public var owner2First: String?
    public var owner2Mid: String?
    public var owner2Last: String?
    public var owner2Suffix: String?
    public var owner2SpouseFirst: String?
    public var owner2SpouseMid: String?
    public var owner2SpouseSuffix: String?
    public var owner2Type: String?
    public var zoning: String?
    public var ownershipStatusCode: String?
    public var companyFlag: String?
    public var siteAddressHouseNumber: String?
    public var siteAddressHouseNumberFraction: String?
    public var siteAddressPreDirectional: String?
    public var siteAddressStreetName: String?
    public var siteAddressStreetNameSuffix: String?
    public var siteAddressPostDirectional: String?
    public var siteAddressUnitNumberPrefix: String?
    public var siteAddressUnitNumber: String?
    public var siteAddressCity: String?
    public var siteAddressState: String?
    public var siteAddressZip: Int?
    public var siteAddressZipFour: Int?
    public var siteAddressCarrierRoute: String?
    public var mailAddressHouseNumber: String?
    public var mailAddressHouseNumberFraction: String?
    public var mailAddressPreDirectional: String?
    public var mailAddressStreetName: String?
    public var mailAddressStreetNameSuffix: String?
    public var mailAddressPostDirectional: String?
    public var mailAddressUnitNumberPrefix: String?
    public var mailAddressUnitNumber: String?
    public var mailAddressCity: String?
    public var mailAddressState: String?
    public var mailAddressZip: Int?
    public var mailAddressCarrierRoute: String?
    public var siteMailSame: String?
    public var legalDescription: String?
    public var lotNumber1: String?
    public var lotNumber2: String?
    public var lotNumber3: String?
    public var blockNumber1: String?
    public var blockNumber2: String?
    public var township: String?
    public var range: String?
    public var section: String?
    public var quarterSection: String?
    public var quarterQuarterSection: String?
    public var subdivision: String?
    public var tractNumber: Int?
    public var legalUnit: String?
    public var useCodeStandard: String?
    public var useCodeMunicipal: String?
    public var assessorYear: String?
    public var valueAssessed: Double?
    public var valueAssessedLand: Double?
    public var valueAssessedImprovements: Double?
    public var appraisalYear: Int?
    public var landAppraisalYear: Int?
    public var appraisalValue: Double?
    public var appraisalValueLand: Double?
    public var appraisalValueImprovements: Double?
    public var marketValue: Double?
    public var marketValueLand: Double?
    public var marketValueImprovements: Double?
    public var marketValueImprovementsPercent: Double?
    public var exemptionFlag1: String?
    public var exemptionValue1: Double?
    public var exemptionFlag2: String?
    public var exemptionValue2: Double?
    public var exemptionFlag3: String?
    public var exemptionValue3: Double?
    public var exemptionFlag4: String?
    public var exemptionValue4: Double?
    public var exemptionFlag5: String?
    public var exemptionValue5: Double?
    public var exemptionFlag6: String?
    public var exemptionValue6: Double?
    public var fullCashValue: Double?
    public var taxYear: String?
    public var taxAmount: Double?
    public var taxYearDelinquent: Double?
    public var additionsSqft: Double?
    public var architectureCode: String?
    public var atticSqFt: Double?
    public var buildingCode: String?
    public var basementCode: String?
    public var basementFinishedSqFt: Double?
    public var basementUnfinishedSqFt: Double?
    public var conditionCode: Double?
    public var constructionCode: String?
    public var constructionQuality: Double?
    public var coolingCode: String?
    public var exteriorTypeCode: String?
    public var finishedAreaSqFt1: Double?
    public var finishedAreaSqFt2: Double?
    public var finishedAreaSqFt3: Double?
    public var finishedAreaSqFt4: Double?
    public var totalFinishedAreaSqft: Double?
    public var fireplaceCode: String?
    public var foundationCode: String?
    public var garageCarport: String?
    public var garageSqFt: Double?
    public var heatingTypeCode: String?
    public var heatingSourceCode: Double?
    public var lotDepth: Double?
    public var lotWidth: Double?
    public var lotSizeSqft: Double?
    public var totalBaths: Double?
    public var bathsQuarter: Double?
    public var bathsHalf: Double?
    public var bathsThreeQuarter: Double?
    public var bathsFull: Double?
    public var basementBathsHalf: Double?
    public var basementBathsFull: Double?
    public var numberBaths: Double?
    public var totalBedrooms: Double?
    public var totalRooms: Double?
    public var totalStories: Int?
    public var totalUnits: Int?
    public var roofCode: String?
    public var structureSqft: Double?
    public var assessorRawSqft: Double?
    public var sqFtTypeCode: Double?
    public var structureCode: String?
    public var structureNumber: Double?
    public var viewCode: String?
    public var yearBuilt: Double?
    public var yearBuiltEffective: Double?
    public var uniqueLoanTransactionId: Double?
    public var uniqueLoanTransactionIdNovalue: Double?
    public var dateOwnershipTransfer: Double?
    public var recentSaleAmount: Double?
    public var documentNumberOwnershipTransfer: String?
    public var dateNoValueOwnershipTransfer: Double?
    public var documentNumberOwnershipTransferNoValue: String?
    public var geocodeQuality: String?
    public var censusTract: String?
    public var censusBlockGroup: String?
    public var coreBasedStatisticalArea: Double?
    public var minorCivilDivisionCode: String?
    public var fipsPlaceCode: String?
    public var inactiveParcelFlag: String?
    public var shellParcelFlag: String?
    public var heatingCooling: String?
    public var taxRateArea: Double?
    public var propertyType: String?
    public var fireplaceDescription: String?
    public var garageCarportDescription: String?
    
    public required init?(_ map: Map) {
        
        propertyId = map["propertyId"].valueOrFail()
        latitude = map["latitude"].valueOrFail()
        longitude = map["longitude"].valueOrFail()
        if !map.isValid {
            return nil
        }
    }
    
    public func mapping(map: Map) {
        
        propertyId <- map["propertyId"]
        scmId <- map["scmId"]
        stateCode <- map["stateCode"]
        muniName <- map["muniName"]
        fipsStateCode <- map["fipsStateCode"]
        fipsMuniCode <- map["fipsMuniCode"]
        fipsCountyName <- map["fipsCountyName"]
        yearApnAdded <- map["yearApnAdded"]
        owner1 <- map["owner1"]
        owner1First <- map["owner1First"]
        owner1Mid <- map["owner1Mid"]
        owner1Last <- map["owner1Last"]
        owner1Suffix <- map["owner1Suffix"]
        owner1SpouseFirst <- map["owner1SpouseFirst"]
        owner1SpouseMid <- map["owner1SpouseMid"]
        owner1SpouseSuffix <- map["owner1SpouseSuffix"]
        owner1Type <- map["owner1Type"]
        owner2 <- map["owner2"]
        owner2First <- map["owner2First"]
        owner2Mid <- map["owner2Mid"]
        owner2Last <- map["owner2Last"]
        owner2Suffix <- map["owner2Suffix"]
        owner2SpouseFirst <- map["owner2SpouseFirst"]
        owner2SpouseMid <- map["owner2SpouseMid"]
        owner2SpouseSuffix <- map["owner2SpouseSuffix"]
        owner2Type <- map["owner2Type"]
        zoning <- map["zoning"]
        ownershipStatusCode <- map["ownershipStatusCode"]
        companyFlag <- map["companyFlag"]
        siteAddressHouseNumber <- map["siteAddressHouseNumber"]
        siteAddressHouseNumberFraction <- map["siteAddressHouseNumberFraction"]
        siteAddressPreDirectional <- map["siteAddressPreDirectional"]
        siteAddressStreetName <- map["siteAddressStreetName"]
        siteAddressStreetNameSuffix <- map["siteAddressStreetNameSuffix"]
        siteAddressPostDirectional <- map["siteAddressPostDirectional"]
        siteAddressUnitNumberPrefix <- map["siteAddressUnitNumberPrefix"]
        siteAddressUnitNumber <- map["siteAddressUnitNumber"]
        siteAddressCity <- map["siteAddressCity"]
        siteAddressState <- map["siteAddressState"]
        siteAddressZip <- map["siteAddressZip"]
        siteAddressZipFour <- map["siteAddressZipFour"]
        siteAddressCarrierRoute <- map["siteAddressCarrierRoute"]
        mailAddressHouseNumber <- map["mailAddressHouseNumber"]
        mailAddressHouseNumberFraction <- map["mailAddressHouseNumberFraction"]
        mailAddressPreDirectional <- map["mailAddressPreDirectional"]
        mailAddressStreetName <- map["mailAddressStreetName"]
        mailAddressStreetNameSuffix <- map["mailAddressStreetNameSuffix"]
        mailAddressPostDirectional <- map["mailAddressPostDirectional"]
        mailAddressUnitNumberPrefix <- map["mailAddressUnitNumberPrefix"]
        mailAddressUnitNumber <- map["mailAddressUnitNumber"]
        mailAddressCity <- map["mailAddressCity"]
        mailAddressState <- map["mailAddressState"]
        mailAddressZip <- map["mailAddressZip"]
        mailAddressCarrierRoute <- map["mailAddressCarrierRoute"]
        siteMailSame <- map["siteMailSame"]
        legalDescription <- map["legalDescription"]
        lotNumber1 <- map["lotNumber1"]
        lotNumber2 <- map["lotNumber2"]
        lotNumber3 <- map["lotNumber3"]
        blockNumber1 <- map["blockNumber1"]
        blockNumber2 <- map["blockNumber2"]
        township <- map["township"]
        range <- map["range"]
        section <- map["section"]
        quarterSection <- map["quarterSection"]
        quarterQuarterSection <- map["quarterQuarterSection"]
        subdivision <- map["subdivision"]
        tractNumber <- map["tractNumber"]
        legalUnit <- map["legalUnit"]
        useCodeStandard <- map["useCodeStandard"]
        useCodeMunicipal <- map["useCodeMunicipal"]
        assessorYear <- map["assessorYear"]
        valueAssessed <- map["valueAssessed"]
        valueAssessedLand <- map["valueAssessedLand"]
        valueAssessedImprovements <- map["valueAssessedImprovements"]
        appraisalYear <- map["appraisalYear"]
        landAppraisalYear <- map["landAppraisalYear"]
        appraisalValue <- map["appraisalValue"]
        appraisalValueLand <- map["appraisalValueLand"]
        appraisalValueImprovements <- map["appraisalValueImprovements"]
        marketValue <- map["marketValue"]
        marketValueLand <- map["marketValueLand"]
        marketValueImprovements <- map["marketValueImprovements"]
        marketValueImprovementsPercent <- map["marketValueImprovementsPercent"]
        exemptionFlag1 <- map["exemptionFlag1"]
        exemptionValue1 <- map["exemptionValue1"]
        exemptionFlag2 <- map["exemptionFlag2"]
        exemptionValue2 <- map["exemptionValue2"]
        exemptionFlag3 <- map["exemptionFlag3"]
        exemptionValue3 <- map["exemptionValue3"]
        exemptionFlag4 <- map["exemptionFlag4"]
        exemptionValue4 <- map["exemptionValue4"]
        exemptionFlag5 <- map["exemptionFlag5"]
        exemptionValue5 <- map["exemptionValue5"]
        exemptionFlag6 <- map["exemptionFlag6"]
        exemptionValue6 <- map["exemptionValue6"]
        fullCashValue <- map["fullCashValue"]
        taxYear <- map["taxYear"]
        taxAmount <- map["taxAmount"]
        taxYearDelinquent <- map["taxYearDelinquent"]
        additionsSqft <- map["additionsSqft"]
        architectureCode <- map["architectureCode"]
        atticSqFt <- map["atticSqFt"]
        buildingCode <- map["buildingCode"]
        basementCode <- map["basementCode"]
        basementFinishedSqFt <- map["basementFinishedSqFt"]
        basementUnfinishedSqFt <- map["basementUnfinishedSqFt"]
        conditionCode <- map["conditionCode"]
        constructionCode <- map["constructionCode"]
        constructionQuality <- map["constructionQuality"]
        coolingCode <- map["coolingCode"]
        exteriorTypeCode <- map["exteriorTypeCode"]
        finishedAreaSqFt1 <- map["finishedAreaSqFt1"]
        finishedAreaSqFt2 <- map["finishedAreaSqFt2"]
        finishedAreaSqFt3 <- map["finishedAreaSqFt3"]
        finishedAreaSqFt4 <- map["finishedAreaSqFt4"]
        totalFinishedAreaSqft <- map["totalFinishedAreaSqft"]
        fireplaceCode <- map["fireplaceCode"]
        foundationCode <- map["foundationCode"]
        garageCarport <- map["garageCarport"]
        garageSqFt <- map["garageSqFt"]
        heatingTypeCode <- map["heatingTypeCode"]
        heatingSourceCode <- map["heatingSourceCode"]
        lotDepth <- map["lotDepth"]
        lotWidth <- map["lotWidth"]
        lotSizeSqft <- map["lotSizeSqft"]
        totalBaths <- map["totalBaths"]
        bathsQuarter <- map["bathsQuarter"]
        bathsHalf <- map["bathsHalf"]
        bathsThreeQuarter <- map["bathsThreeQuarter"]
        bathsFull <- map["bathsFull"]
        basementBathsHalf <- map["basementBathsHalf"]
        basementBathsFull <- map["basementBathsFull"]
        numberBaths <- map["numberBaths"]
        totalBedrooms <- map["totalBedrooms"]
        totalRooms <- map["totalRooms"]
        totalStories <- map["totalStories"]
        totalUnits <- map["totalUnits"]
        roofCode <- map["roofCode"]
        structureSqft <- map["structureSqft"]
        assessorRawSqft <- map["assessorRawSqft"]
        sqFtTypeCode <- map["sqFtTypeCode"]
        structureCode <- map["structureCode"]
        structureNumber <- map["structureNumber"]
        viewCode <- map["viewCode"]
        yearBuilt <- map["yearBuilt"]
        yearBuiltEffective <- map["yearBuiltEffective"]
        uniqueLoanTransactionId <- map["uniqueLoanTransactionId"]
        uniqueLoanTransactionIdNovalue <- map["uniqueLoanTransactionIdNovalue"]
        dateOwnershipTransfer <- map["dateOwnershipTransfer"]
        recentSaleAmount <- map["recentSaleAmount"]
        documentNumberOwnershipTransfer <- map["documentNumberOwnershipTransfer"]
        dateNoValueOwnershipTransfer <- map["dateNoValueOwnershipTransfer"]
        documentNumberOwnershipTransferNoValue <- map["documentNumberOwnershipTransferNoValue"]
        latitude <- map["latitude"]
        longitude <- map["longitude"]
        geocodeQuality <- map["geocodeQuality"]
        censusTract <- map["censusTract"]
        censusBlockGroup <- map["censusBlockGroup"]
        coreBasedStatisticalArea <- map["coreBasedStatisticalArea"]
        minorCivilDivisionCode <- map["minorCivilDivisionCode"]
        fipsPlaceCode <- map["fipsPlaceCode"]
        inactiveParcelFlag <- map["inactiveParcelFlag"]
        shellParcelFlag <- map["shellParcelFlag"]
        heatingCooling <- map["heatingCooling"]
        taxRateArea <- map["taxRateArea"]
        propertyType <- map["propertyType"]
        fireplaceDescription <- map["fireplaceDescription"]
        garageCarportDescription <- map["garageCarportDescription"]
    }
}