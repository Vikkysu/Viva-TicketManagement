//
//  DPBrokerProfileTableViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/15/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPAgentProfileTableViewController: UITableViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    let picker = UIImagePickerController()
    var profilePhotoImg: UIImageView!

    var firstNameTextField: UITextField!
    var lastNameTextField: UITextField!
    var emailNameTextField: UITextField!
    var phoneNameTextField: UITextField!
    var passwordtextField: UITextField!
    
    func saveData(brokerPersonalInfoInfo: DPBrokerProfileObj) {
        let agentOnboardingInfo = DPAgentOnBoardingModel.sharedInstance
        agentOnboardingInfo.BrokerProfileModelObj(brokerPersonalInfoInfo)
        agentOnboardingInfo.saveBrokerProfileObject(brokerPersonalInfoInfo)
    }
    
    
    func fetchSavedData()->DPBrokerProfileObj? {
        let agentOnboardingInfo: DPAgentOnBoardingModel = DPAgentOnBoardingModel.sharedInstance
        let agentObj: DPBrokerProfileObj? = agentOnboardingInfo.loadBrokerProfileObjectWithKey()
        return agentObj
    }
    
    func setDataFields() -> Bool
    {
        var isValidated: Bool = false
        
        let brokerPersonalInfoInfo: DPBrokerProfileObj = DPBrokerProfileObj()
        
        let strUserRole = userRoleInfo.getUserData(userRoleInfo.getUserRole()!)
        
        if passwordtextField.text != "" {
            brokerPersonalInfoInfo.password = passwordtextField.text
            isValidated = true
        }
        else
        {
            let alertView = UIAlertView(title: "", message: NSLocalizedString("Please enter Password", comment:"Please enter Password"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
            alertView.show()
            return false
        }
        
        if firstNameTextField.text != "" {
            brokerPersonalInfoInfo.firstNameStr = firstNameTextField.text
            isValidated = true
        }
        else
        {
            let alertView = UIAlertView(title: "", message: NSLocalizedString("Please enter \(strUserRole) Name", comment:"Please enter \(strUserRole) Name"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
            alertView.show()
            return false
        }
        
        if lastNameTextField.text != "" {
            brokerPersonalInfoInfo.lastNameStr = lastNameTextField.text
            isValidated = true
        }
        else
        {
            let alertView = UIAlertView(title: "", message: NSLocalizedString("Please enter \(strUserRole) Last Name", comment:"Please enter \(strUserRole) Last Name"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
            alertView.show()
            return false
        }
        
        if emailNameTextField.text != "" {
            brokerPersonalInfoInfo.emailStr = emailNameTextField.text
            isValidated = true
        }
        else
        {
            let alertView = UIAlertView(title: "", message: NSLocalizedString("Email field cannot be empty", comment:"Email field cannot be empty"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
            alertView.show()
            return false
        }
        
        if let cityText = phoneNameTextField {
            if cityText.text != "" {
                brokerPersonalInfoInfo.phonenoStr = phoneNameTextField.text
                isValidated = true
            }
            else
            {
                let alertView = UIAlertView(title: "", message: NSLocalizedString("Phone number field cannot be empty", comment:"Phone number field cannot be empty"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
                alertView.show()
                return false
            }
        }
        
        brokerPersonalInfoInfo.profilePhoto = profilePhotoImg.image
        
        
        if isValidated == true {
            saveData(brokerPersonalInfoInfo)
        }
        return isValidated
    }
    
    func getHeadervalue () -> String {
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            return "Create an Account"
        }
        
        return "Provide Brokerage Information"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        tableView.delegate=self
        tableView.dataSource=self
        tableView.showsHorizontalScrollIndicator=false
        tableView.showsVerticalScrollIndicator=false
        tableView.separatorStyle = .None
        tableView.registerClass(ACBrokerageStep1HeaderCell.self, forCellReuseIdentifier: "reuseIdentifier")
        tableView.registerClass(DPAgentProfileTableViewCell.self, forCellReuseIdentifier: "DPAgentProfileTableViewCellIdentifier")
        tableView.registerClass(DPBrokerProfilePhotoTableViewCell.self, forCellReuseIdentifier: "DPBrokerProfilePhotoTableViewCellIdentifier")
        
        picker.delegate = self
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 3
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 100
        }
        else if indexPath.row == 1 {
            return 160
        }
        return 240
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if(indexPath.row == 0)
        {
            let cell: ACBrokerageStep1HeaderCell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath) as! ACBrokerageStep1HeaderCell
            let label: UILabel? = cell.viewWithTag(34) as? UILabel
            
            label!.text = getHeadervalue()
            
            cell.selectionStyle = .None
            return cell
        }
        else if indexPath.row == 1 {
            let cell: DPBrokerProfilePhotoTableViewCell = tableView.dequeueReusableCellWithIdentifier("DPBrokerProfilePhotoTableViewCellIdentifier", forIndexPath: indexPath) as! DPBrokerProfilePhotoTableViewCell
            let displayPhoto: UIImageView? = cell.viewWithTag(150) as? UIImageView
            let tapProfilePhoto = UITapGestureRecognizer(target: self, action: "uploadProfilePhoto:")
            tapProfilePhoto.numberOfTapsRequired = 1
            displayPhoto?.userInteractionEnabled = true
            displayPhoto!.addGestureRecognizer(tapProfilePhoto)
            self.profilePhotoImg = displayPhoto
            cell.selectionStyle = .None
            return cell
        }
        
        let cell: DPAgentProfileTableViewCell = tableView.dequeueReusableCellWithIdentifier("DPAgentProfileTableViewCellIdentifier", forIndexPath: indexPath) as! DPAgentProfileTableViewCell

        //fetch the saved data
        let brokerObj: DPBrokerProfileObj? = fetchSavedData()
        
        let lPasswordTextFeild: UITextField? = cell.viewWithTag(161) as? UITextField
        lPasswordTextFeild?.delegate=self
        
        let lFirstNameTextFeild: UITextField? = cell.viewWithTag(164) as? UITextField
        lFirstNameTextFeild?.delegate=self
        
        let lLastNameTextFeild: UITextField? = cell.viewWithTag(166) as? UITextField
        lLastNameTextFeild?.delegate=self

        let lEmailNameTextFeild: UITextField? = cell.viewWithTag(168) as? UITextField
        lEmailNameTextFeild?.delegate=self

        let lPhoneNameTextFeild: UITextField? = cell.viewWithTag(170) as? UITextField
        lPhoneNameTextFeild?.delegate=self
        if let brokerModelObj = brokerObj {
            lPasswordTextFeild?.text = brokerModelObj.password
            lFirstNameTextFeild?.text = brokerModelObj.firstNameStr
            lLastNameTextFeild?.text = brokerModelObj.lastNameStr
            lEmailNameTextFeild?.text = brokerModelObj.emailStr
            lPhoneNameTextFeild?.text = brokerModelObj.phonenoStr
            profilePhotoImg.image = brokerModelObj.profilePhoto
        }
        self.passwordtextField = lPasswordTextFeild
        self.firstNameTextField = lFirstNameTextFeild
        self.lastNameTextField = lLastNameTextFeild
        self.emailNameTextField = lEmailNameTextFeild
        self.phoneNameTextField = lPhoneNameTextFeild
        
        return cell
    }
    
    //MARK:- custom text field methods
    func addKeypadToolBar(textField: UITextField) {
        // Create a button bar for the number pad
        let keyboardDoneButtonView = UIToolbar()
        keyboardDoneButtonView.sizeToFit()
        
        // Setup the buttons to be put in the system.
        let item = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.Plain, target: self, action: Selector("endEditingNow") )
        let toolbarButtons = [item]
        
        //Put the buttons into the ToolBar and display the tool bar
        keyboardDoneButtonView.setItems(toolbarButtons, animated: false)
        textField.inputAccessoryView = keyboardDoneButtonView
    }
    
    func endEditingNow(){
        self.view.endEditing(true)
    }
    
    //photo upload functions
    func uploadProfilePhoto(recognizer: UITapGestureRecognizer) {
        print("Upload an photo")
        picker.allowsEditing = false //2
        picker.sourceType = .PhotoLibrary //3
        presentViewController(picker, animated: true, completion: nil)//4
    }
    
    //MARK: - text field delegates
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        if textField == self.phoneNameTextField {
            let countLen = textField.text!.characters.count + string.characters.count
            if countLen > 13 {
                return false
            }
        }
        return true
    }

    
    func textFieldShouldEndEditing(textField: UITextField) -> Bool {
        if textField == self.passwordtextField {
            self.passwordtextField.resignFirstResponder()
            self.firstNameTextField.becomeFirstResponder()
        }
        if textField == self.firstNameTextField {
            self.firstNameTextField.resignFirstResponder()
            self.lastNameTextField.becomeFirstResponder()
        }
        if textField == self.lastNameTextField {
            self.lastNameTextField.resignFirstResponder()
            self.emailNameTextField.becomeFirstResponder()
        }
        if textField == self.emailNameTextField {
            let isEmailValid: Bool = UtilitiesFunc.isValidEmail(textField.text!)
            if isEmailValid == false {
                let alertView = UIAlertView(title: "", message: NSLocalizedString("Please enter valid Email Address", comment:"Please enter valid Email Address"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
                alertView.show()
                return false
            }

            self.emailNameTextField.resignFirstResponder()
            self.phoneNameTextField.becomeFirstResponder()
        }
        else {
            self.phoneNameTextField.resignFirstResponder()
        }
        return true;
    }
    
    //MARK: - text field delegates
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        if textField == self.phoneNameTextField {
            addKeypadToolBar(textField)
        }        
        return true
    }
    
    //MARK: Delegates
    func imagePickerController(
        picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [String : AnyObject])
    {
        let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage //2
        self.profilePhotoImg.contentMode = .ScaleAspectFit //3
        self.profilePhotoImg.image = chosenImage //4
        dismissViewControllerAnimated(true, completion: nil) //5
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        dismissViewControllerAnimated(true, completion: nil)
    }

}
