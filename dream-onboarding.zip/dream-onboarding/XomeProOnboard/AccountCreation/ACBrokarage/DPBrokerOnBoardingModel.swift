//
//  DPBrokerOnBoardingModel.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/2/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

let keyBrokerOnBoardingObj: String = "brokerOnBoardingObjKey"
let keyBrokerOnBoardingEmailPassObj: String = "brokerOnBoardingEmailPassObjKey"
let keyBrokeragePassObj: String = "BrokeragePassObjKey"
let keyBrokerageLicenseObj: String = "BrokerageLicenseObjKey"
let keyBrokerageMLSObj: String = "BrokerageMLSObjKey"
let keyBrokerageBrandingBioObj: String = "BrokerageBrandingBioObjKey"
let keyBrokerageBrandingWebsiteObj: String = "BrokerageBrandingWebsiteObjKey"
let keyBrokerageBrandingColorObj: String = "BrokerageBrandingImageColorObjKey"
let keyBrokerageBrandingWebsiteYoutubeObj: String = "BrokerageBrandingWebsiteYoutubeObjKey"
let keyBrokerProfileObj: String = "BrokerProfileObjkey"
let keyBrokerLicenseObj: String = "BrokerLicenseObjKey"
let keyBrokerMLSObj: String = "BrokerMLSObjKey"
let keyBrokerBrandingBioObj: String = "BrokerBrandingBioObjKey"

class DPBrokerOnBoardingModel: NSObject {
    static let sharedInstance = DPBrokerOnBoardingModel()
    
    //getter & setter for Broker emial information
    var brokerageEmailModelObj : DPBrokerageEmailObj?
    
    func getProfileModelObj() ->DPBrokerageEmailObj? {
        return self.brokerageEmailModelObj
    }
    
    func brokerageEmailModelObj(profileModelObject :DPBrokerageEmailObj) {
        brokerageEmailModelObj = profileModelObject
    }

    //getter & setter for Broker Personal information
    var brokeragePersonalInfoObjModelObj : DPBrokeragePersonalInfoObj!
    func getbrokeragePersonalInfoModelObj() ->DPBrokeragePersonalInfoObj {
        return brokeragePersonalInfoObjModelObj
    }
    
    func brokeragePersonalInfoModelObj(PersonalModelObject :DPBrokeragePersonalInfoObj) {
        brokeragePersonalInfoObjModelObj = PersonalModelObject
    }
    
    //getter & setter for Brokerage License information
    var brokerageLicenseObjModelObj : DPBrokerageLicenseInfo!
    func getbrokerageLicenseModelObj() ->DPBrokerageLicenseInfo {
        return brokerageLicenseObjModelObj
    }
    
    func brokerageLicenseModelObj(LicenseModelObject :DPBrokerageLicenseInfo) {
        brokerageLicenseObjModelObj = LicenseModelObject
    }
    
    //getter & setter for Broker License information
    var brokerLicenseObjModelObj : DPBrokerLicenseInfo!
    func getbrokerLicenseModelObj() ->DPBrokerLicenseInfo {
        return brokerLicenseObjModelObj
    }
    
    func brokerLicenseModelObj(LicenseModelObject :DPBrokerLicenseInfo) {
        brokerLicenseObjModelObj = LicenseModelObject
    }
    
    //getter & setter for Brokerage MLS information
    var brokerageMLSObjModelObj : DPBrokerageMLSInfo!
    func getbrokerageMLSModelObj() ->DPBrokerageMLSInfo {
        return brokerageMLSObjModelObj
    }
    
    func brokerageMLSModelObj(MLSModelObject :DPBrokerageMLSInfo) {
        brokerageMLSObjModelObj = MLSModelObject
    }
    
    //getter & setter for Broker MLS information
    var brokerMLSObjModelObj : DPBrokerMLSInfo!
    func getbrokerMLSModelObj() ->DPBrokerMLSInfo {
        return brokerMLSObjModelObj
    }
    
    func brokerMLSModelObj(MLSModelObject :DPBrokerMLSInfo) {
        brokerMLSObjModelObj = MLSModelObject
    }
    
    
    //getter & setter for Broker about us information
    var brokerageBioModelObj : DPBrandingBioObj?
    
    func getBrokerageBioModelObj() ->DPBrandingBioObj? {
        return self.brokerageBioModelObj
    }
    
    func BrokerageBioModelObj(brandingBioModelObject :DPBrandingBioObj) {
        brokerageBioModelObj = brandingBioModelObject
    }
    
    //getter & setter for Broker about us information
    var brokerBioModelObj : DPBrandingBioObj?
    
    func getBrokerBioModelObj() ->DPBrandingBioObj? {
        return self.brokerBioModelObj
    }
    
    func BrokerBioModelObj(brandingBioModelObject :DPBrandingBioObj) {
        brokerageBioModelObj = brandingBioModelObject
    }
    
    //getter & setter for Broker website information
    var brokerageWebsiteModelObj : DPBrandingWebsiteAddrObj?
    
    func getBrokerageWebsiteModelObj() ->DPBrandingWebsiteAddrObj? {
        return self.brokerageWebsiteModelObj
    }
    
    func BrokerageWebsiteModelObj(brandingWebsiteModelObject :DPBrandingWebsiteAddrObj) {
        brokerageWebsiteModelObj = brandingWebsiteModelObject
    }
    
    //getter & setter for Broker website & youtube information
    var brokerageWebsiteYoutubeModelObj : DPBrandingWebsiteYoutubeAddrObj?
    
    func getBrokerageWebsiteyoutubeModelObj() ->DPBrandingWebsiteYoutubeAddrObj? {
        return self.brokerageWebsiteYoutubeModelObj
    }
    
    func BrokerageWebsiteYoutubeModelObj(brandingWebsiteYoutubeModelObject :DPBrandingWebsiteYoutubeAddrObj) {
        brokerageWebsiteYoutubeModelObj = brandingWebsiteYoutubeModelObject
    }
    
    //getter & setter for color information
    var brokerageColorModelObj : DPBrandingColorObj?
    
    func getBrokerageColorModelObj() ->DPBrandingColorObj? {
        return self.brokerageColorModelObj
    }
    
    func BrokeragecolorModelObj(brandingBioModelObject :DPBrandingColorObj) {
        brokerageColorModelObj = brandingBioModelObject
    }
    
    //getter & setter for profile information
    var brokerProfileModelObj : DPBrokerProfileObj?
    
    func getBrokerProfileModelObj() ->DPBrokerProfileObj? {
        return self.brokerProfileModelObj
    }
    
    func BrokerProfileModelObj(brokerProfileModelObject :DPBrokerProfileObj) {
        brokerProfileModelObj = brokerProfileModelObject
    }

    
    //save the model for offline usage
    func encodeWithCoder(encoder: NSCoder) {
        encoder.encodeObject(self, forKey: keyBrokerOnBoardingObj)
    }
    
    func initWithCoder(decoder: NSCoder)->AnyObject {
        return self;
    }
    
    
    //save email password fields
    func saveCustomObject(object: DPBrokerageEmailObj) {
        let encodedObject: NSData = NSKeyedArchiver.archivedDataWithRootObject(object);
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.setObject(encodedObject, forKey:keyBrokerOnBoardingEmailPassObj);
        defaults.synchronize();
    
    }
    
    func loadCustomObjectWithKey()->DPBrokerageEmailObj? {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        if let encodedObject: NSData = defaults.objectForKey(keyBrokerOnBoardingEmailPassObj) as? NSData
        {
            if let object: DPBrokerageEmailObj? = NSKeyedUnarchiver.unarchiveObjectWithData(encodedObject) as? DPBrokerageEmailObj {
                return object;
            }
        }
        return nil
    }
    
    func removeEmailSavedObj() {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.removeObjectForKey(keyBrokerOnBoardingEmailPassObj)
    }
    
    //save Brokerage password fields
    func saveBrokerageCustomObject(object: DPBrokeragePersonalInfoObj) {
        let encodedObject: NSData = NSKeyedArchiver.archivedDataWithRootObject(object);
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.setObject(encodedObject, forKey:keyBrokeragePassObj);
        defaults.synchronize();
        
    }
    
    func loadBrokerageCustomObjectWithKey()->DPBrokeragePersonalInfoObj? {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        if let encodedObject: NSData = defaults.objectForKey(keyBrokeragePassObj) as? NSData
        {
            if let object: DPBrokeragePersonalInfoObj? = NSKeyedUnarchiver.unarchiveObjectWithData(encodedObject) as? DPBrokeragePersonalInfoObj {
                return object;
            }
        }
        return nil
    }
    
    func removeBrokerageSavedObj() {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.removeObjectForKey(keyBrokeragePassObj)
    }
    
    //save Brokerage License Custom Object
    func saveBrokerageLicenseCustomObject(object: DPBrokerageLicenseInfo) {
        let encodedObject: NSData = NSKeyedArchiver.archivedDataWithRootObject(object);
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.setObject(encodedObject, forKey:keyBrokerageLicenseObj);
        defaults.synchronize();
        
    }
    
    func loadBrokerageLicenseCustomObjectWithKey()->DPBrokerageLicenseInfo? {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        if let encodedObject: NSData = defaults.objectForKey(keyBrokerageLicenseObj) as? NSData
        {
            if let object: DPBrokerageLicenseInfo? = NSKeyedUnarchiver.unarchiveObjectWithData(encodedObject) as? DPBrokerageLicenseInfo {
                return object;
            }
        }
        return nil
    }
    
    func removeBrokerageLicenseSavedObj() {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.removeObjectForKey(keyBrokerageLicenseObj)
    }
    
    //save Brokerage License Custom Object
    func saveBrokerLicenseCustomObject(object: DPBrokerLicenseInfo) {
        let encodedObject: NSData = NSKeyedArchiver.archivedDataWithRootObject(object);
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.setObject(encodedObject, forKey:keyBrokerLicenseObj);
        defaults.synchronize();
        
    }
    
    func loadBrokerLicenseCustomObjectWithKey()->DPBrokerLicenseInfo? {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        if let encodedObject: NSData = defaults.objectForKey(keyBrokerLicenseObj) as? NSData
        {
            if let object: DPBrokerLicenseInfo? = NSKeyedUnarchiver.unarchiveObjectWithData(encodedObject) as? DPBrokerLicenseInfo {
                return object;
            }
        }
        return nil
    }
    
    func removeBrokerLicenseSavedObj() {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.removeObjectForKey(keyBrokerLicenseObj)
    }
    
    //save Brokerage MLS Custom Object
    func saveBrokerageMLSCustomObject(object: DPBrokerageMLSInfo) {
        let encodedObject: NSData = NSKeyedArchiver.archivedDataWithRootObject(object);
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.setObject(encodedObject, forKey:keyBrokerageMLSObj);
        defaults.synchronize();
        
    }
    
    func loadBrokerageMLSCustomObjectWithKey()->DPBrokerageMLSInfo? {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        if let encodedObject: NSData = defaults.objectForKey(keyBrokerageMLSObj) as? NSData
        {
            if let object: DPBrokerageMLSInfo? = NSKeyedUnarchiver.unarchiveObjectWithData(encodedObject) as? DPBrokerageMLSInfo {
                return object;
            }
        }
        return nil
    }
    
    func removeBrokerageLMLSSavedObj() {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.removeObjectForKey(keyBrokerageMLSObj)
    }
    
    //save Brokerage MLS Custom Object
    func saveBrokerMLSCustomObject(object: DPBrokerMLSInfo) {
        let encodedObject: NSData = NSKeyedArchiver.archivedDataWithRootObject(object);
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.setObject(encodedObject, forKey:keyBrokerMLSObj);
        defaults.synchronize();
        
    }
    
    func loadBrokerMLSCustomObjectWithKey()->DPBrokerMLSInfo? {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        if let encodedObject: NSData = defaults.objectForKey(keyBrokerMLSObj) as? NSData
        {
            if let object: DPBrokerMLSInfo? = NSKeyedUnarchiver.unarchiveObjectWithData(encodedObject) as? DPBrokerMLSInfo {
                return object;
            }
        }
        return nil
    }
    
    func removeBrokerLMLSSavedObj() {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.removeObjectForKey(keyBrokerMLSObj)
    }
    
    //save Brokerage About us Custom Object
    func saveBrokerageBrandingBioObject(object: DPBrandingBioObj) {
        let encodedObject: NSData = NSKeyedArchiver.archivedDataWithRootObject(object);
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.setObject(encodedObject, forKey:keyBrokerageBrandingBioObj);
        defaults.synchronize();
        
    }
    
    func loadBrokerageBrandingBioObjectWithKey()->DPBrandingBioObj? {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        if let encodedObject: NSData = defaults.objectForKey(keyBrokerageBrandingBioObj) as? NSData
        {
            if let object: DPBrandingBioObj? = NSKeyedUnarchiver.unarchiveObjectWithData(encodedObject) as? DPBrandingBioObj {
                return object;
            }
        }
        return nil
    }
    
    func removeBrokerageBrandingBioSavedObj() {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.removeObjectForKey(keyBrokerageBrandingBioObj)
    }
    
    //save Broker About us Custom Object
    func saveBrokerBrandingBioObject(object: DPBrandingBioObj) {
        let encodedObject: NSData = NSKeyedArchiver.archivedDataWithRootObject(object);
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.setObject(encodedObject, forKey:keyBrokerBrandingBioObj);
        defaults.synchronize();
        
    }
    
    func loadBrokerBrandingBioObjectWithKey()->DPBrandingBioObj? {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        if let encodedObject: NSData = defaults.objectForKey(keyBrokerBrandingBioObj) as? NSData
        {
            if let object: DPBrandingBioObj? = NSKeyedUnarchiver.unarchiveObjectWithData(encodedObject) as? DPBrandingBioObj {
                return object;
            }
        }
        return nil
    }
    
    func removeBrokerBrandingBioSavedObj() {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.removeObjectForKey(keyBrokerBrandingBioObj)
    }
    
    //save Brokerage WEBSITE Custom Object
    func saveBrokerageBrandingWebsiteObject(object: DPBrandingWebsiteAddrObj) {
        let encodedObject: NSData = NSKeyedArchiver.archivedDataWithRootObject(object);
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.setObject(encodedObject, forKey:keyBrokerageBrandingWebsiteObj);
        defaults.synchronize();
        
    }
    
    func loadBrokerageBrandingWebsiteObjectWithKey()->DPBrandingWebsiteAddrObj? {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        if let encodedObject: NSData = defaults.objectForKey(keyBrokerageBrandingWebsiteObj) as? NSData
        {
            if let object: DPBrandingWebsiteAddrObj? = NSKeyedUnarchiver.unarchiveObjectWithData(encodedObject) as? DPBrandingWebsiteAddrObj {
                return object;
            }
        }
        return nil
    }
    
    func removeBrokerageBrandingWebsiteSavedObj() {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.removeObjectForKey(keyBrokerageBrandingWebsiteObj)
    }

    //DPBrandingImageColorObj
    //save Brokerage COLOR Custom Object
    func saveBrokerageBrandingColorObject(object: DPBrandingColorObj) {
        let encodedObject: NSData = NSKeyedArchiver.archivedDataWithRootObject(object);
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.setObject(encodedObject, forKey:keyBrokerageBrandingColorObj);
        defaults.synchronize();
        
    }
    
    func loadBrokerageBrandingColorObjectWithKey()->DPBrandingColorObj? {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        if let encodedObject: NSData = defaults.objectForKey(keyBrokerageBrandingColorObj) as? NSData
        {
            if let object: DPBrandingColorObj? = NSKeyedUnarchiver.unarchiveObjectWithData(encodedObject) as? DPBrandingColorObj {
                return object;
            }
        }
        return nil
    }
    
    func removeBrokerageBrandingImageColorSavedObj() {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.removeObjectForKey(keyBrokerageBrandingColorObj)
    }
    
    //save Brokerage WEBSITE&YOUTUBE Custom Object
    func saveBrokerageBrandingWebsiteYoutubeObject(object: DPBrandingWebsiteYoutubeAddrObj) {
        let encodedObject: NSData = NSKeyedArchiver.archivedDataWithRootObject(object);
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.setObject(encodedObject, forKey:keyBrokerageBrandingWebsiteYoutubeObj);
        defaults.synchronize();
        
    }
    
    func loadBrokerageBrandingWebsiteYoutubeObjectWithKey()->DPBrandingWebsiteYoutubeAddrObj? {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        if let encodedObject: NSData = defaults.objectForKey(keyBrokerageBrandingWebsiteYoutubeObj) as? NSData
        {
            if let object: DPBrandingWebsiteYoutubeAddrObj? = NSKeyedUnarchiver.unarchiveObjectWithData(encodedObject) as? DPBrandingWebsiteYoutubeAddrObj {
                return object;
            }
        }
        return nil
    }
    
    func removeBrokerageBrandingWebsiteYoutubeSavedObj() {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.removeObjectForKey(keyBrokerageBrandingWebsiteYoutubeObj)
    }
    
    //set the profile broker object
    func saveBrokerProfileObject(object: DPBrokerProfileObj) {
        let encodedObject: NSData = NSKeyedArchiver.archivedDataWithRootObject(object);
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.setObject(encodedObject, forKey:keyBrokerProfileObj);
        defaults.synchronize();
        
    }
    
    func loadBrokerProfileObjectWithKey()->DPBrokerProfileObj? {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        if let encodedObject: NSData = defaults.objectForKey(keyBrokerProfileObj) as? NSData
        {
            if let object: DPBrokerProfileObj? = NSKeyedUnarchiver.unarchiveObjectWithData(encodedObject) as? DPBrokerProfileObj {
                return object;
            }
        }
        return nil
    }
    
    func removeBrokerProfileSavedObj() {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.removeObjectForKey(keyBrokerProfileObj)
    }

}
