//
//  PublicRecordsDetailModel.swift
//  XomeRestClient
//
//  Created by Xome on 2/4/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper
import PromiseKit

public class PublicRecordsDetailModel: Mappable {
    
    public var assessorRecord: AssessorModel?
    public var priceHistoryRecords = [PriceHistoryRecords]()
    public var taxHistoryRecords = [TaxHistoryRecords]()
    public var valuation: ValuationRecords?

    // These fields are set by local APIs, not by serialization over the wire.
    public struct LocalFields {
        public var nearbySoldProperties: Promise<PropertySearchResultModel>?
        public var nearbyActiveProperties: Promise<PropertySearchResultModel>?
    }
    public var additionalInfo: LocalFields
    
    required public init?(_ map: Map) {
        additionalInfo = LocalFields()
    }
    
    public func mapping(map: Map) {
        assessorRecord <- map["assessorRecord"]
        priceHistoryRecords <- map["priceHistoryRecords"]
        taxHistoryRecords <- map["taxHistoryRecords"]
        valuation <- map["valuation"]
    }
}