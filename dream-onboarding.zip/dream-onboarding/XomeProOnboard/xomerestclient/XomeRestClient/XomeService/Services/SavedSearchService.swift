//
//  SavedSearchService.swift
//  XomeRestClient
//
//  Created by Xome on 1/27/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper
import CoreLocation
import PromiseKit

public extension XomeService {

    // MARK: SavedSearch
    
    public func saveSearch(region region: PropertySearchRegion,
        sortBy: PropertySortOption,
        name: String,
        description: String) -> Promise<SavedSearchResponseModel>
    {
        let path = "SavedSearches/"
        
        let request = SavedSearchRequestModel(name: name,
            description: description,
            propertyDetails: PropertyRequestModel(sortId: sortBy,
                searchMapNe: region.northEast,
                searchMapSw: region.southWest,
                searchFilter: region.filter))
        
        let body = NSDictionary( dictionary: Mapper().toJSON(request) ).xome_jsonData()
        
        return operationFactory.promise(OperationVerb.POST, path: path, queryParameters: nil, bodyData: body)
    }
    
    public func savedSearches() -> Promise<SavedSearchListModel>
    {
        let path = "savedSearches"
        return operationFactory.promise(.GET, path: path, queryParameters: nil, bodyData: nil)
    }
    
    public func removeSavedSearch(savedSearchKey: String) -> XomeRestOperation
    {
        let path = "savedsearches/\(savedSearchKey)"
        return operationFactory.operation(.DELETE, path: path, queryParameters: nil, bodyData: nil)
    }
}