//
//  XomeRestClientExtensions.swift
//  XomeRestClient
//
//  Created by David Parton on 12/2/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import ObjectMapper
import PromiseKit

public let JSONSerializationError = NSError(domain: "JSON Serialization", code: 0, userInfo: [NSLocalizedDescriptionKey:"Failed to deserialize JSON"])

/// MARK: - XomeRestOperation method chanining and automatic ObjectMapper mapping

public extension XomeRestOperation {
    public func handleSuccess(handler: (XomeRestOperation, NSData) -> ()) -> Self {
        return handleSuccess {
            handler(self, $0)
        }
    }
    public func handleSuccess(handler: (XomeRestOperation, String) -> ()) -> Self {
        return handleSuccess {
            handler(self, String(data: $0, encoding: NSUTF8StringEncoding)!)
        }
    }
    public func handleError(handler: (XomeRestOperation, NSError) -> ()) -> Self {
        return handleError {
            handler(self, $0)
        }
    }
    
    /// Attach a success handler that automatically maps the received data to the `ObjectMapper.Mappable` model type
    /// - parameter handler: A callback that receives the operation (for marking as failed if necessary) and the translated model object.
    /// - returns: self
    func handleSuccess<T: Mappable>(handler: (operation: XomeRestOperation, model: T) -> ()) -> Self {
        self.handleSuccess { (operation: XomeRestOperation, dataString: String) -> Void in
            guard let model = Mapper<T>().map(dataString) else {
                operation.fail(JSONSerializationError)
                return
            }
            handler(operation: operation, model: model)
        }
        return self
    }
    
    /// Attach a success handler that automatically maps the received data to an array of `ObjectMapper.Mappable` model types
    /// - parameter handler: A callback that receives the operation (for marking as failed if necessary) and the array of models.
    /// - returns: self
    func handleSuccess<T: Mappable>(handler: (operation: XomeRestOperation, model: [T]) -> ()) -> Self {
        self.handleSuccess { (operation: XomeRestOperation, dataString: String) -> Void in
            guard let model = Mapper<T>().mapArray(dataString) else {
                operation.fail(JSONSerializationError)
                return
            }
            handler(operation: operation, model: model)
        }
        return self
    }
}

/// MARK: - XomeRestOperationFactory extensions

public enum OperationVerb: String {
    case GET, POST, DELETE, PUT, HEAD
}

public extension XomeRestOperationFactory {
    public typealias FinalRequestMutator = (request: NSMutableURLRequest!) -> Void
    
    /// An extension method of the same Objective-C class but using a enum for the verb instead of a string.
    /// Add handlers using `handleSuccess` and `handleError` and call the `start` method to schedule the operation.
    /// Callback handlers are NOT executed in the main thread.
    /// - parameter path:
    ///   If the path is a relative URL string, the selected api environment endpoint will be used.
    ///
    ///   If the path is an absolute URL string, that URL will serve as the base for query string manipulation.
    /// - parameter operation: The HTTP verb to use for the request. See OperationVerb
    /// - parameter queryParameters: A mapping of String -> String representing the query parameters for the request
    /// - parameter bodyData: The data to send in the body of the request
    /// - parameter outgoingRequestMutator: An optional callback that can be used to modify the NSMutableURLRequest before it is scheduled
    /// - returns: XomeRestOperation!
    public func operation(operation: OperationVerb, path: String, queryParameters: [String : String]?, bodyData: NSData?, outgoingRequestMutator: FinalRequestMutator? = nil) -> XomeRestOperation! {
        return self.operation(operation.rawValue, host: nil, resourcePath: path, queryParameters: queryParameters, postData: bodyData, mutateRequestHandler: outgoingRequestMutator)
    }
    
    /// A shortcut factory method for populating GET requests
    /// Add handlers using `handleSuccess` and `handleError` and call the `start` method to schedule the operation.
    /// Callback handlers are NOT executed in the main thread.
    /// - parameter path:
    ///   If the path is a relative URL string, the selected api environment endpoint will be used.
    ///
    ///   If the path is an absolute URL string, that URL will serve as the base for query string manipulation.
    /// - parameter queryParameters: A mapping of String -> String representing the query parameters for the request
    /// - parameter outgoingRequestMutator: An optional callback that can be used to modify the NSMutableURLRequest before it is scheduled
    /// - returns: XomeRestOperation!
    public func get(path path: String, queryParameters: [String : String]?, outgoingRequestMutator: FinalRequestMutator? = nil) -> XomeRestOperation! {
        return self.operation(.GET, path: path,
            queryParameters: queryParameters,
            bodyData: nil,
            outgoingRequestMutator: outgoingRequestMutator)
    }
    
    /// A shortcut factory method for populating POST requests
    /// Add handlers using `handleSuccess` and `handleError` and call the `start` method to schedule the operation.
    /// Callback handlers are NOT executed in the main thread.
    /// - parameter path:
    ///   If the path is a relative URL string, the selected api environment endpoint will be used.
    ///
    ///   If the path is an absolute URL string, that URL will serve as the base for query string manipulation.
    /// - parameter queryParameters: A mapping of String -> String representing the query parameters for the request
    /// - parameter postData: The data to send in the body of the request
    /// - parameter outgoingRequestMutator: An optional callback that can be used to modify the NSMutableURLRequest before it is scheduled
    /// - returns: XomeRestOperation!
    public func post(path path: String, queryParameters: [String : String]?, postData: NSData?, outgoingRequestMutator: FinalRequestMutator? = nil) -> XomeRestOperation! {
        return self.operation(.POST, path: path,
            queryParameters: queryParameters,
            bodyData: postData,
            outgoingRequestMutator: outgoingRequestMutator)
    }
    
    /// A shortcut factory method for populating PUT requests
    /// Add handlers using `handleSuccess` and `handleError` and call the `start` method to schedule the operation.
    /// Callback handlers are NOT executed in the main thread.
    /// - parameter path:
    ///   If the path is a relative URL string, the selected api environment endpoint will be used.
    ///
    ///   If the path is an absolute URL string, that URL will serve as the base for query string manipulation.
    /// - parameter queryParameters: A mapping of String -> String representing the query parameters for the request
    /// - parameter putData: The data to send in the body of the request
    /// - parameter outgoingRequestMutator: An optional callback that can be used to modify the NSMutableURLRequest before it is scheduled
    /// - returns: XomeRestOperation!
    public func put(path path: String, queryParameters: [String : String]?, putData: NSData, outgoingRequestMutator: FinalRequestMutator? = nil) -> XomeRestOperation! {
        return self.operation(.PUT, path: path,
            queryParameters: queryParameters,
            bodyData: putData,
            outgoingRequestMutator: outgoingRequestMutator)
    }
    
    /// A shortcut factory method for populating DELETE requests
    /// Add handlers using `handleSuccess` and `handleError` and call the `start` method to schedule the operation.
    /// Callback handlers are NOT executed in the main thread.
    /// - parameter path:
    ///   If the path is a relative URL string, the selected api environment endpoint will be used.
    ///
    ///   If the path is an absolute URL string, that URL will serve as the base for query string manipulation.
    /// - parameter queryParameters: A mapping of String -> String representing the query parameters for the request
    /// - parameter data: The data to send in the body of the request
    /// - parameter outgoingRequestMutator: An optional callback that can be used to modify the NSMutableURLRequest before it is scheduled
    /// - returns: XomeRestOperation!
    public func delete(path path: String, queryParameters: [String : String]?, data: NSData, outgoingRequestMutator: FinalRequestMutator? = nil) -> XomeRestOperation! {
        return self.operation(.DELETE, path: path,
            queryParameters: queryParameters,
            bodyData: data,
            outgoingRequestMutator: outgoingRequestMutator)
    }
    
    /// A shortcut factory method for populating HEAD requests
    /// Add handlers using `handleSuccess` and `handleError` and call the `start` method to schedule the operation.
    /// Callback handlers are NOT executed in the main thread.
    /// - parameter path:
    ///   If the path is a relative URL string, the selected api environment endpoint will be used.
    ///
    ///   If the path is an absolute URL string, that URL will serve as the base for query string manipulation.
    /// - parameter queryParameters: A mapping of String -> String representing the query parameters for the request
    /// - parameter data: The data to send in the body of the request
    /// - parameter outgoingRequestMutator: An optional callback that can be used to modify the NSMutableURLRequest before it is scheduled
    /// - returns: XomeRestOperation!
    public func head(path path: String, queryParameters: [String : String]?, data: NSData, outgoingRequestMutator: FinalRequestMutator? = nil) -> XomeRestOperation! {
        return self.operation(.HEAD, path: path,
            queryParameters: queryParameters,
            bodyData: data,
            outgoingRequestMutator: outgoingRequestMutator)
    }
    
    /// Return a promise for a Mappable model received from the XomeRestClient
    public func promise<T: Mappable>(operation: OperationVerb = .GET, path: String, queryParameters: [String : String]?, bodyData: NSData?, outgoingRequestMutator: FinalRequestMutator? = nil) -> Promise<T> {
        return promise(operation, path: path, queryParameters: queryParameters, bodyData: bodyData, outgoingRequestMutator: outgoingRequestMutator).then { (data: NSData) -> T in
            var jsonString = String(data: data, encoding: NSUTF8StringEncoding)
            if jsonString == nil || jsonString!.isEmpty {
                jsonString = "{}"
            }
            guard let model = Mapper<T>().map(jsonString)
                else { throw JSONSerializationError }
            return model
        }
    }
    
    /// Return a promise for an array of Mappable models received from the XomeRestClient
    public func promise<T: Mappable>(operation: OperationVerb = .GET, path: String, queryParameters: [String : String]?, bodyData: NSData?, outgoingRequestMutator: FinalRequestMutator? = nil) -> Promise<[T]> {
        return self.promise(operation, path: path, queryParameters: queryParameters, bodyData: bodyData, outgoingRequestMutator: outgoingRequestMutator).then { (data: NSData) -> [T] in
            var jsonString = String(data: data, encoding: NSUTF8StringEncoding)
            if jsonString == nil || jsonString!.isEmpty {
                jsonString = "[]"
            }
            guard let models = Mapper<T>().mapArray(jsonString)
                else { throw JSONSerializationError }
            return models
        }
    }
    
    /// Return a promise for a raw NSData object
    public func promise(operation: OperationVerb = .GET, path: String, queryParameters: [String : String]?, bodyData: NSData?, outgoingRequestMutator: FinalRequestMutator? = nil) -> Promise<NSData> {
        return Promise { (resolve, reject) in
            let operation = self.operation(operation.rawValue, host: nil, resourcePath: path, queryParameters: queryParameters, postData: bodyData, mutateRequestHandler: outgoingRequestMutator)
            operation
                .handleSuccess { (data: NSData) in resolve(data) }
                .handleError { (error) in reject(error) }
                .start()
        }
    }
}
