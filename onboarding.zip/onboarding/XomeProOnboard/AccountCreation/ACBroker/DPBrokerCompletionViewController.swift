//
//  DPBrokerCompletionViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/17/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrokerCompletionViewController: UIViewController {
    
    func closeView(sender: UIBarButtonItem) {
        self.dismissViewControllerAnimated(true, completion: nil);
    }
    
    func inVite (sender: AnyObject) {        
        let nextViewController: DPBrandingInviteWelcomeViewController = DPBrandingInviteWelcomeViewController()
        self.navigationItem.backBarButtonItem?.title = " "
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        // Do any additional setup after loading the view.
        self.navigationItem.title = "Account Created"
        self.navigationItem.setHidesBackButton(true, animated: false)
        
        self.view.backgroundColor = UIColor.lightGrayColor()
        
        let viewBackGround: UIView  = UIView()
        viewBackGround.backgroundColor = UIColor.whiteColor()
        self.view.addSubview(viewBackGround)
        
        viewBackGround.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self.view).offset(68)
            make.leading.equalTo(self.view).offset(5)
            make.trailing.equalTo(self.view).offset(-5)
            make.bottom.equalTo(self.view).offset(-50)
        }
        
        let imageCompleted: UIImageView = UIImageView()
        imageCompleted.image = UIImageCustom().getImageFromString("stepCompletion")
        viewBackGround.addSubview(imageCompleted)
        
        let headerLbl: UILabel = UILabel()
        headerLbl.text = "Well Done! MLS data has been verified."
        headerLbl.font = UIFont(name: MuseoSansRounded100Font, size: 20)
        headerLbl.numberOfLines=0
        headerLbl.textAlignment = .Center
        headerLbl.textColor = UIColor.baoGunmetalColor()
        viewBackGround.addSubview(headerLbl)
        
        let headerSubLbl: UILabel = UILabel()
        headerSubLbl.numberOfLines = 0
        headerSubLbl.textAlignment = .Center
        headerSubLbl.text = "You can now start inviting Agents & Clients!"
        headerSubLbl.font = UIFont(name: MuseoSansRounded300Font, size: 16)
        headerSubLbl.textColor = UIColor(red: 51.0/255.0, green: 51.0/255.0, blue: 51.0/255.0, alpha: 1.0)
        viewBackGround.addSubview(headerSubLbl)
        
        let continueOnBoarding: UIButton = UIButton()
        continueOnBoarding.backgroundColor = UIColor.baoGunmetalColor()
        continueOnBoarding.titleLabel?.font = UIFont(name: MuseoSansRounded300Font, size: 16.0)
        continueOnBoarding.setTitle("Continue", forState: .Normal)
        continueOnBoarding.addTarget(self, action: "inVite:", forControlEvents: .TouchUpInside)
        continueOnBoarding.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        self.view.addSubview(continueOnBoarding)
        
        imageCompleted.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(viewBackGround).offset(100)
            make.centerX.equalTo(viewBackGround).offset(0)
            make.width.equalTo(90)
            make.height.equalTo(90)
        }
        
        headerLbl.snp_makeConstraints {(make) ->Void in
            make.top.equalTo(imageCompleted).offset(90+50)
            make.leading.equalTo(viewBackGround).offset(10)
            make.trailing.equalTo(viewBackGround).offset(-10)
        }
        
        headerSubLbl.snp_makeConstraints {(make) ->Void in
            make.leading.equalTo(viewBackGround).offset(10)
            make.trailing.equalTo(viewBackGround).offset(-10)
            make.top.equalTo(headerLbl).offset(50+30)
        }
        
        continueOnBoarding.snp_makeConstraints {(make) ->Void in
            make.leading.equalTo(self.view).offset(0)
            make.trailing.equalTo(self.view).offset(0)
            make.bottom.equalTo(self.view).offset(0)
            make.height.equalTo(50)
        }
        
        //self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .Plain, target: nil, action: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
