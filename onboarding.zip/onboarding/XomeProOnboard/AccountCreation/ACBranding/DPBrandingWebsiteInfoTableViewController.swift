//
//  DPBrandingWebsiteInfoTableViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/9/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrandingWebsiteInfoTableViewController: UITableViewController, UITextFieldDelegate {
    var brokerWebSiteInfo: UITextField!
    
    func setDataFields() -> Bool
    {
        let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
        let brokerWebsiteInfoObj: DPBrandingWebsiteAddrObj = DPBrandingWebsiteAddrObj()
        
        if brokerWebSiteInfo.text != "" && brokerWebSiteInfo.text != " " {
            brokerWebsiteInfoObj.websiteAddressStr = brokerWebSiteInfo.text
            if UtilitiesFunc.isValidURL(brokerWebsiteInfoObj.websiteAddressStr!) == true {
                brokerWebsiteInfoObj.isSet = true
            }
            else {
                let alertView: UIAlertView = UIAlertView(title: "", message: "Not a valid URL", delegate: nil, cancelButtonTitle: "OK")
                alertView.show()
                return false
            }
            
        }
        else {
            brokerWebsiteInfoObj.isSet = false
            brokerWebsiteInfoObj.websiteAddressStr = " "
        }
        brokerOnboardingInfo.BrokerageWebsiteModelObj(brokerWebsiteInfoObj)
        brokerOnboardingInfo.saveBrokerageBrandingWebsiteObject(brokerWebsiteInfoObj)
        return true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        tableView.delegate=self
        tableView.dataSource=self
        tableView.showsHorizontalScrollIndicator=false
        tableView.showsVerticalScrollIndicator=false
        tableView.separatorStyle = .None
        tableView.registerClass(ACBrokerageStep1HeaderCell.self, forCellReuseIdentifier: "reuseIdentifier")
        tableView.registerClass(ACBrokerageTextCell.self, forCellReuseIdentifier: "DPBrandingWSCellIdentiifer")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Tableview delegates
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 2
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 100
        }
        return tableView.frame.height-100
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        // fill the fields if saved offline
        if(indexPath.row == 0)
        {
            let cell: ACBrokerageStep1HeaderCell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath) as! ACBrokerageStep1HeaderCell
            let label: UILabel? = cell.viewWithTag(34) as? UILabel
            
            label!.text = "Provide Your Brokerage Website."
            
            cell.selectionStyle = .None
            return cell
        }
        
        //DPBrandingBioCell
        let cell: ACBrokerageTextCell = tableView.dequeueReusableCellWithIdentifier("DPBrandingWSCellIdentiifer", forIndexPath: indexPath) as! ACBrokerageTextCell
        
        let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
        
        let label: UILabel = cell.viewWithTag(33) as! UILabel
        label.text = "WEBSITE ADDRESS"
        
        let textFieldInfo : UITextField? = cell.viewWithTag(32) as? UITextField
        
        brokerWebSiteInfo = textFieldInfo
        brokerWebSiteInfo.keyboardType = .URL
        brokerWebSiteInfo.returnKeyType = .Done
        if let brokerBrandingWebsiteInfo: DPBrandingWebsiteAddrObj = brokerOnboardingInfo.loadBrokerageBrandingWebsiteObjectWithKey() {
            brokerWebSiteInfo.text = brokerBrandingWebsiteInfo.websiteAddressStr
        }
        brokerWebSiteInfo.delegate=self
        cell.selectionStyle = .None
        
        return cell
    }
    
    func textFieldDidEndEditing(textField: UITextField) // may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
    {
        textField.resignFirstResponder()
        if !textField.text!.isEmpty {
            let parentViewC : DPBrandingWebsiteInfoViewController =  self.parentViewController as! DPBrandingWebsiteInfoViewController
            parentViewC.createNextbutton(NEXTBUTTON)
        }
        return
    }
    
    func textFieldDidBeginEditing(textField: UITextField) // may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
    {
        let parentViewC : DPBrandingWebsiteInfoViewController =  self.parentViewController as! DPBrandingWebsiteInfoViewController
        parentViewC.createNextbutton(NEXTBUTTON)
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool
    {
        textField.resignFirstResponder()
        let parentViewC : DPBrandingWebsiteInfoViewController =  self.parentViewController as! DPBrandingWebsiteInfoViewController

        if !textField.text!.isEmpty {
            parentViewC.createNextbutton(NEXTBUTTON)
        }
        else
        {
            parentViewC.createSkipbutton()

        }
        return true
    }

}
