//
//  PropertyDirectionMapModel.swift
//  XomeRestClient
//
//  Created by imayaselvan on 2/2/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public struct PropertyDirectionMapModel: Mappable {
    public var token: String
    
    public init?(_ map: Map) {
        token = map["cookie"].valueOrFail()
        if !map.isValid {
            return nil
        }
    }
    
    public mutating func mapping(map: Map) {
        token <- map["cookie"]
    }
}
