//
//  DPBrandingLicenseTableViewCell.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/13/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrandingLicenseTableViewCell: UITableViewCell {
    
    var brokerLicenseStateInfo: UILabel!
    var brokerLicenseInfo: UILabel!
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String!)
    {
        super.init(style: UITableViewCellStyle.Value1, reuseIdentifier: reuseIdentifier)
        var imageCheck : UIImageView
        imageCheck = UIImageView()
        imageCheck.image = UIImageCustom().getImageFromString("stepCompletion")
        self.addSubview(imageCheck)
        
        var labelTextBL : UILabel
        labelTextBL = UILabel()
        labelTextBL.numberOfLines=0
        labelTextBL.textAlignment = .Left
        labelTextBL.tag=90
        labelTextBL.backgroundColor=UIColor.clearColor()
        labelTextBL.font = UIFont(name: MuseoSansRounded300Font, size: 12.0)
        labelTextBL.text = "BROKERAGE LICENSE NUMBER"
        self.addSubview(labelTextBL)
        
        let textFieldBL : UILabel = UILabel()
        textFieldBL.font = UIFont(name: MuseoSansRounded300Font, size: 20.0)
        textFieldBL.tag=91
        textFieldBL.textAlignment = .Left
        self.addSubview(textFieldBL)
        brokerLicenseInfo = textFieldBL
        
        var labelTextState : UILabel
        labelTextState = UILabel()
        labelTextState.numberOfLines=0
        labelTextState.textAlignment = .Center
        labelTextState.tag=92
        labelTextState.text="STATE"
        labelTextState.backgroundColor=UIColor.clearColor()
        labelTextState.font = UIFont(name: MuseoSansRounded300Font, size: 12.0)
        self.addSubview(labelTextState)
        
        let textFieldState : UILabel = UILabel()
        textFieldState.font = UIFont(name: MuseoSansRounded300Font, size: 20.0)
        textFieldState.tag=93
        self.addSubview(textFieldState)
        brokerLicenseStateInfo = textFieldState
        
        let separatorLine: UIView = UIView()
        separatorLine.backgroundColor = UIColor.baoTableBorderColor()
        self.addSubview(separatorLine)
        
        imageCheck.snp_makeConstraints { (make) -> Void in
            make.centerY.equalTo(self).offset(0)
            make.leading.equalTo(self).offset(35)
            make.height.equalTo(25)
            make.width.equalTo(25)
        }
        
        labelTextBL.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self).offset(10)
            make.leading.equalTo(imageCheck).offset(40)
        }
        
        textFieldBL.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(labelTextBL).offset(20)
            make.leading.equalTo(labelTextBL).offset(0)
        }
        
        labelTextState.snp_makeConstraints { (make) -> Void in
            make.trailing.equalTo(self).offset(-40)
            make.top.equalTo(labelTextBL).offset(0)
        }
        
        textFieldState.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(labelTextState).offset(20)
            make.centerX.equalTo(labelTextState).offset(0)
        }
        
        separatorLine.snp_makeConstraints {(make) -> Void in
            make.bottom.equalTo(self).offset(-1)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-1)
            make.height.equalTo(1)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
