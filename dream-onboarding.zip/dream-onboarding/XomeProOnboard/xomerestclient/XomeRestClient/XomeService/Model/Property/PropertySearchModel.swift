import ObjectMapper
import XomeFoundation

private let boundaryTypeMap: [PropertySearchType: String] = [
    .City: "city",
    .Zip: "zip",
    .Neighborhood: "neighborhood",
    .School: "school",
    .ElementarySchool: "elementary school",
    .MiddleSchool: "middle school",
    .HighSchool: "high school",
    .SchoolDistrict: "school district"
]

public enum PropertySearchType: Int {
    case Address
    case StreetName
    case ListingNumber
    case City
    case County
    case Zip
    case Neighborhood
    case School
    case ElementarySchool
    case MiddleSchool
    case HighSchool
    case SchoolDistrict

    public var boundaryRequestName: String? {
        return boundaryTypeMap[self]
    }
}

public class PropertySearchModel: NSObject, Mappable {
    public var name: String!
    public var type: String!
    public var itemType: PropertySearchType!
    public var city: String?
    public var state: String?
    public var bid: String?
    public var propertyId: String?
    public var listingId: String?

    public init(copy: PropertySearchModel) {
        name = copy.name
        type = copy.type
        itemType = copy.itemType
        city = copy.city
        state = copy.state
        bid = copy.bid
        propertyId = copy.propertyId
        listingId = copy.listingId
    }

    public init(name: String, type: String) {
        self.name = name
        self.type = type
        self.itemType = nil
        self.state = nil
        self.city = nil
        self.bid = nil
        self.propertyId = nil
        self.listingId = nil

        super.init()
    }

    required public init?(_ map: Map) {
    }

    public func mapping(map: Map) {
        name <- map["Name"]
        type <- map["Type"]
        itemType <- map["ItemType"]
        city <- map["City"]
        state <- map["State"]
        bid <- map["BID"]
        propertyId <- (map["PropertyId"], TransformOf<String, Int>(
            fromJSON: { i -> String? in
                guard let _i = i else { return nil }
                return String(_i)
            }, toJSON: { s -> Int? in
                guard let _s = s else { return nil }
                return Int(_s)
        }))
        listingId <- map["ListingId"]
    }

    public var resolvedItemType: PropertySearchType {
        guard itemType == nil else {
            if itemType == .School {
                switch type {
                case "High School": itemType = .HighSchool
                case "Elementary School": itemType = .ElementarySchool
                case "Middle School": itemType = .MiddleSchool
                default: break
                }
            }
            return itemType
        }

        switch type {
        case "City"?: return .City
        case "Zip"?: return .Zip
        case "County"?: return .County
        case "Neighborhood"?: return .Neighborhood
        case "School"?: return .School
        case "Elementary School"?: return .ElementarySchool
        case "Middle School"?: return .MiddleSchool
        case "High School"?: return .HighSchool
        case "School District"?: return .SchoolDistrict
        case "MLS #": return .ListingNumber

        // pick something that doesn't boundary resolve:
        default: return .Address
        }
    }

    public var boundaryRequestValue: String? {
        switch resolvedItemType {
        case .City, .Zip:
            return name
        case .Neighborhood, .School, .HighSchool, .MiddleSchool, .ElementarySchool, .SchoolDistrict:
            return bid
        default:
            return nil
        }
    }

    public var boundaryRequestName: String? {
        return resolvedItemType.boundaryRequestName
    }
}


extension PropertySearchModel {
    public override var description: String {
        return [name, city, state].flatMap{ $0 }.joinWithSeparator(", ")
    }
    
    public override func isEqual(object: AnyObject?) -> Bool {
        let lhs = object as! PropertySearchModel
        return self.description.lowercaseString == lhs.description.lowercaseString
    }
}
