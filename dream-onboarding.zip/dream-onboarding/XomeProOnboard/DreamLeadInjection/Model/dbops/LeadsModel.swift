//
//  LeadsModel.swift
//  ProfessionalTools
//
//  Created by MacMini5 on 21/10/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class LeadsModel: NSObject {
    
    var leadsDataArray      :NSMutableArray = NSMutableArray()
    var leadDataDictionary  :NSMutableDictionary   = NSMutableDictionary()
    
    func createAndGetDataSample()->NSMutableArray{
        
        
        leadDataDictionary["status"]        = true
        leadDataDictionary["leadSource"]    = "FROM ZILLOW"
        leadDataDictionary["leadType"]      = "Buyer"
        leadDataDictionary["leadName"]      = "Marie Hayes"
        leadDataDictionary["leadLegend"]    = "Jennifer Smith declined this lead"
        leadDataDictionary["timeSince"]     = "1 hr. ago"
        
        leadsDataArray.addObject(leadDataDictionary)
        leadDataDictionary = NSMutableDictionary(capacity: 0)
        
        leadDataDictionary["status"]        = false
        leadDataDictionary["leadSource"]    = "FROM XOME"
        leadDataDictionary["leadType"]      = "Seller"
        leadDataDictionary["leadName"]      = "Lena Rivera"
        leadDataDictionary["leadLegend"]    = "Need an agent to sell my Seattle home"
        leadDataDictionary["timeSince"]     = "10 hrs. ago"
        
        leadsDataArray.addObject(leadDataDictionary)
        leadDataDictionary = NSMutableDictionary(capacity: 0)
        
        leadDataDictionary["status"]        = false
        leadDataDictionary["leadSource"]    = "FROM Website"
        leadDataDictionary["leadType"]      = "Unknown"
        leadDataDictionary["leadName"]      = "Jason Fuller"
        leadDataDictionary["leadLegend"]    = "Need an agent to sell my Seattle home"
        leadDataDictionary["timeSince"]     = "1 day ago"
        
        leadsDataArray.addObject(leadDataDictionary)
        
        return leadsDataArray
    }
    
}
