//
//  DPloginViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 9/18/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

enum STATE {
    case BEFOREBROKERDISPLAYSTATE
    case BROKEROPTIONDISPLAYSTATE
    case BROKERSELECTEDSTATE
}



public class DPloginViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UITextFieldDelegate {
    public var delegateParent: DPPaginateParent? = nil

    let cellIdentifier = "cellIdentifier"
    
    var brokerTextField: UITextField!
    
    var usernameTextField: UITextField!
    var userNameSeparator: UIView!
    var passwordTextField: UITextField!
    var passWordSeparator: UIView!

    var signUpBtn: UIButton!
    var forgotPassWdBtn: UIButton!
    var loginInBtn: UIButton!
    
    var brokerInfoDisplayView: UIView!
    var brokerInfoTableView: UITableView!
    var selectedBroker: UIButton!
    var editBroker: UIButton!
    
    //TODO: need to interate with API to fetch brokers
    var selectedBrokerArr: NSMutableArray = []
    var selectedBrokerInfo = "";
    
    let backgroundImg: UIImageView =  UIImageView()
    let closeButton: UIButton = UIButton()
    let dimmUIView: UIView = UIView()
    let xomeHeader: UILabel = UILabel()

    var timer       = NSTimer()
    var eState: STATE = .BEFOREBROKERDISPLAYSTATE
    
    var loginPostDta:JSON?
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        
        backgroundImg.image = UIImageCustom().getImageFromString("backgroundImage")
        self.view.addSubview(backgroundImg)
        
        dimmUIView.backgroundColor = UIColor.baoTwilightBlue20Color()
        self.view.addSubview(dimmUIView)
        
        closeButton.setBackgroundImage(UIImageCustom().getImageFromString("closeButtonImage"), forState: .Normal)
        dimmUIView.addSubview(closeButton)
        closeButton.addTarget(self, action: "closeView:", forControlEvents: .TouchUpInside)
        
        xomeHeader.text = "LOGIN"
        xomeHeader.numberOfLines=0
        xomeHeader.font = UIFont(name: MuseoSansRounded300Font, size: 25.0)
        xomeHeader.textColor = UIColor.whiteColor()
        dimmUIView.addSubview(xomeHeader)
        
        self.basicControlDisplay(dimmUIView)
        self.createTableView(dimmUIView)
        
        self.usernameTextField.delegate = self
        self.passwordTextField.delegate = self
        self.displayBrokerInfo(false)
    }
    
    override public func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    //MARK - create Views
    func basicControlDisplay(dimmUIView: UIView) {
        let userNamelTextField: UITextField = UITextField()
        let color: UIColor = UIColor.whiteColor();
        userNamelTextField.attributedPlaceholder = NSAttributedString(string: "Email", attributes: [NSForegroundColorAttributeName: color])
        userNamelTextField.placeholder = "Email"
        userNamelTextField.textColor = UIColor.whiteColor()
        dimmUIView.addSubview(userNamelTextField)
        userNamelTextField.delegate = self
        usernameTextField = userNamelTextField
        
        let userNameSepView: UIView = UIView()
        userNameSepView.backgroundColor = UIColor(red: 220.0/255.0, green:220.0/255.0, blue: 220.0/255.0, alpha: 1.0)
        dimmUIView.addSubview(userNameSepView)
        userNameSeparator = userNameSepView
        
        let brokerDetails: UIButton = UIButton()
        dimmUIView.addSubview(brokerDetails)
        selectedBroker = brokerDetails
        selectedBroker.titleLabel?.font = UIFont(name: MuseoSansRounded300Font, size: 15)
        selectedBroker.addTarget(self, action: "editBroker:", forControlEvents: .TouchUpInside)

        let brokerEditDetails: UIButton = UIButton()
        dimmUIView.addSubview(brokerEditDetails)
        editBroker = brokerEditDetails
        editBroker.setTitle("Change", forState: .Normal)
        editBroker.titleLabel?.font = UIFont(name: MuseoSansRounded300Font, size: 15)
        editBroker.addTarget(self, action: "editBroker:", forControlEvents: .TouchUpInside)

        let passWordlTextField: UITextField = UITextField()
        passWordlTextField.textColor = UIColor.whiteColor()
        passWordlTextField.attributedPlaceholder = NSAttributedString(string: "Password", attributes: [NSForegroundColorAttributeName: color])
        passWordlTextField.secureTextEntry = true
        dimmUIView.addSubview(passWordlTextField)
        passwordTextField = passWordlTextField
        passwordTextField?.delegate=self
        
        let passwordSepView: UIView = UIView()
        passwordSepView.backgroundColor = UIColor(red: 220.0/255.0, green:220.0/255.0, blue: 220.0/255.0, alpha: 1.0)
        dimmUIView.addSubview(passwordSepView)
        passWordSeparator = passwordSepView
        
        let loginBtn: UIButton = UIButton()
        loginBtn.setTitle("LOG IN", forState: UIControlState.Normal)
        loginBtn.backgroundColor = UIColor.whiteColor()
        loginBtn.setTitleColor(UIColor.baoGunmetalColor(), forState: .Normal)
        loginBtn.addTarget(self, action: "login:", forControlEvents: .TouchUpInside)
        dimmUIView.addSubview(loginBtn)
        loginInBtn = loginBtn
        
        let signUPBtn: UIButton = UIButton()
        signUPBtn.setTitle("SIGN UP", forState: UIControlState.Normal)
        signUPBtn.addTarget(self, action: "signUpdisplay:", forControlEvents: .TouchUpInside)
        signUPBtn.titleLabel?.font = UIFont(name: MuseoSansRounded300Font, size: 15)
        dimmUIView.addSubview(signUPBtn)
        signUpBtn = signUPBtn
        
        let forgotPassBtn: UIButton = UIButton()
        forgotPassBtn.setTitle("FORGOT PASSWORD", forState: UIControlState.Normal)
        forgotPassBtn.titleLabel?.font = UIFont(name: MuseoSansRounded300Font, size: 15)
        forgotPassBtn.addTarget(self, action: "forgotPassword:", forControlEvents: .TouchUpInside)
        dimmUIView.addSubview(forgotPassBtn)
        forgotPassWdBtn = forgotPassBtn
    }
    
    //create table, broker display  view
    func createTableView(dimmUIView: UIView) {
        
        let tablebrokerView : UITableView = UITableView()
        dimmUIView.addSubview(tablebrokerView)
        brokerInfoTableView = tablebrokerView
        brokerInfoTableView.backgroundColor = UIColor.clearColor()
        self.brokerInfoTableView?.registerClass(UITableViewCell.self, forCellReuseIdentifier: self.cellIdentifier)
        
        
        brokerInfoTableView.delegate=self
        brokerInfoTableView.dataSource=self

    }
    

    @IBAction func login(sender: AnyObject) {
//MARK: Api todo:
/*%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        *todo:
            • move data fetch to separate thread/process
            • show loading activity
            • spend more time on robust validations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%*/
        if(self.usernameTextField.text != nil && self.passwordTextField.text != nil)
        {
            var dreamTenant = "abcrealty"
            if eState == .BROKERSELECTEDSTATE {
                dreamTenant = selectedBrokerInfo
            }
            let params = [
                "username":self.usernameTextField.text!,
                "password":self.passwordTextField.text!,
                "user-type":"Broker",
                "dream-tenant": dreamTenant
            ]


            Alamofire.request(.POST,SwaggerApi.ApiEndpoints.SWAGGER_LOGIN,headers:SwaggerApi.ApiHeaders.SWAGGER_BASIC_HDRS,parameters:params,encoding:.JSON)
                .responseJSON { response in
                    debugPrint("Response: \(response)\n")
                    print("RESPONSE: \(response.response)")
                    
                    if(response.result.value == nil)
                    {
                        let alertView = UIAlertView(title: "Invalid Credentials", message: "Username or Password Incorrect", delegate: nil, cancelButtonTitle: "dismiss") as UIAlertView
                        alertView.show()
                    }
                    if let jDta = response.result.value {
                        self.loginPostDta = JSON(jDta)
                        print(self.loginPostDta!)
                        if(self.loginPostDta!["statusCode"] == 400){
                            let alertView = UIAlertView(title: "Fields Required", message: "Please fill in required fields", delegate: nil, cancelButtonTitle: "done") as UIAlertView
                            alertView.show()
                        }
                        
                        if(self.loginPostDta!["dreamAuthToken"] != nil){
//MARK: temp view to demonstrate validated against api...
                            let vc = UIViewController()
                            let tmpNav = UINavigationController(rootViewController: vc)
                            tmpNav.navigationBar.barTintColor = UIColor.baoPrimaryColor()
                            vc.title = "API Valid User"
                            
                            vc.view.backgroundColor = UIColor.baoGunmetalColor()
                            
                            self.presentViewController(tmpNav, animated: true, completion: nil)
                            let alertView = UIAlertView(title: "Validation Success", message: "User validated against API", delegate: nil, cancelButtonTitle: "OK") as UIAlertView
                            alertView.show()
                        }

                    }
            }
        }

        
    }
    

    // to reatin single instance calling parent view to launch the sign up screen
    func signUpdisplay(sender: AnyObject) {
        let signUp: DPSignInViewController = DPSignInViewController()
        self.presentViewController(signUp, animated: true, completion: nil)
    }
    
    @IBAction func closeView(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    // validate the username & password
    func validateloginCred() -> Bool
    {
        if let unwrappedUserStr = usernameTextField.text {
            print("Unwrapped! \(unwrappedUserStr.uppercaseString)")
        }
        else
        {
            let alertView = UIAlertView(title: "", message: "Please enter valid Email", delegate: nil, cancelButtonTitle: "Ok") as UIAlertView
            alertView.show()
            return false;
        }
        if let unwrappedPasswordStr = passwordTextField.text {
            print("Unwrapped! \(unwrappedPasswordStr.uppercaseString)")
        }
        else
        {
            let alertView = UIAlertView(title: "", message: "Please enter valid Password", delegate: nil, cancelButtonTitle: "Ok") as UIAlertView
            alertView.show()
            return false;
        }
        
        return true;
    }
    
    @IBAction func editBroker(sender: AnyObject) {
        self.displayBrokerInfoAfterSelection(true)
        self.brokerInfoTableView.reloadData()
    }
    
    func commonControlDisplay(isControlDisplay: Bool)
    {
        signUpBtn?.hidden = isControlDisplay
        forgotPassWdBtn?.hidden = true
        passwordTextField?.hidden = isControlDisplay
        passWordSeparator?.hidden = isControlDisplay
        loginInBtn?.hidden = isControlDisplay
        
    }

    func displayBrokerInfoAfterSelection(isBrokerDisplay: Bool)
    {
//        brokerInfoDisplayView.hidden = !isBrokerDisplay
        self.brokerInfoTableView.hidden = !isBrokerDisplay
        self.commonControlDisplay(isBrokerDisplay)
        editBroker.hidden = isBrokerDisplay
        selectedBroker.hidden = isBrokerDisplay
    }
    
    func displayBrokerInfo(isBrokerDisplay: Bool)
    {
//            brokerInfoDisplayView?.hidden = !isBrokerDisplay
            brokerInfoTableView?.hidden = !isBrokerDisplay
            self.commonControlDisplay(isBrokerDisplay)
            editBroker?.hidden = !isBrokerDisplay
            selectedBroker?.hidden = !isBrokerDisplay
    }
    
    func displayBrokerInfoBeforeSelection(isBrokerDisplay: Bool)
    {
//        brokerInfoDisplayView.hidden = !isBrokerDisplay
        brokerInfoTableView?.hidden = !isBrokerDisplay
        self.commonControlDisplay(isBrokerDisplay)
        editBroker.hidden = isBrokerDisplay
        selectedBroker.hidden = isBrokerDisplay
        eState = .BROKEROPTIONDISPLAYSTATE
    }
    
    func displayInfoAfterBrokerSelection(isBrokerDisplay: Bool)
    {
//        brokerInfoDisplayView.hidden = !isBrokerDisplay
        brokerInfoTableView?.hidden = !isBrokerDisplay
        self.commonControlDisplay(isBrokerDisplay)
        if selectedBrokerArr.count == 0 {
            editBroker.hidden = true
        }
        else {
            editBroker.hidden = isBrokerDisplay
        }
        selectedBroker.hidden = isBrokerDisplay
        selectedBroker.setTitle(selectedBrokerInfo, forState: .Normal)
        self.view.setNeedsUpdateConstraints()
    }
    
    override public func updateViewConstraints() {
        super.updateViewConstraints()
        //add constriants

        backgroundImg.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self.view).offset(0.0)
            make.bottom.equalTo(self.view).offset(0.0)
            make.leading.equalTo(self.view).offset(0.0)
            make.trailing.equalTo(self.view).offset(0.0)
        }
        
        dimmUIView.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self.view).offset(0.0)
            make.bottom.equalTo(self.view).offset(0.0)
            make.leading.equalTo(self.view).offset(0.0)
            make.trailing.equalTo(self.view).offset(0.0)
        }
        
        closeButton.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(self.view).offset(30.0)
            make.leading.equalTo(self.view).offset(20.0)
            make.height.equalTo(24.0)
            make.width.equalTo(24.0)
        }
        
        xomeHeader.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(dimmUIView).offset(100.0)
            make.centerX.equalTo(dimmUIView)
        }
        
        //add constriants
        passwordTextField.snp_makeConstraints { (make) ->Void in
            make.leading.equalTo(dimmUIView).offset(20)
            make.centerY.equalTo(dimmUIView).offset(0)
            make.trailing.equalTo(dimmUIView).offset(-20)
        }
        
        passWordSeparator.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(passwordTextField).offset(20)
            make.leading.equalTo(dimmUIView).offset(20)
            make.trailing.equalTo(dimmUIView).offset(-20)
            make.height.equalTo(1)
        }
        
        loginInBtn.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(passWordSeparator).offset(40)
            make.leading.equalTo(dimmUIView).offset(20)
            make.trailing.equalTo(dimmUIView).offset(-20)
        }
        signUpBtn.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(loginInBtn).offset(40)
            make.leading.equalTo(dimmUIView).offset(20)
        }
        forgotPassWdBtn.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(loginInBtn).offset(40)
            make.trailing.equalTo(dimmUIView).offset(-20)
        }
        
        self.brokerInfoTableView.snp_makeConstraints { (make) ->Void in
            make.trailing.equalTo(-10)
            make.leading.equalTo(10)
            make.height.equalTo(200)
            make.top.equalTo(userNameSeparator).offset(0)
        }
        
        //add constriants
        var height: Int = -40
        
        if eState == .BROKERSELECTEDSTATE {
            height = -80
        }
            
        usernameTextField.snp_makeConstraints { (make) ->Void in
            make.bottom.equalTo(passwordTextField).offset(height)
            make.leading.equalTo(self.view).offset(20)
            make.trailing.equalTo(self.view).offset(-20)
        }
        userNameSeparator.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(usernameTextField).offset(20)
            make.leading.equalTo(self.view).offset(20)
            make.trailing.equalTo(self.view).offset(-20)
            make.height.equalTo(1)
        }
        
        selectedBroker.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(userNameSeparator).offset(15)
            make.leading.equalTo(userNameSeparator).offset(0)
        }
        
        editBroker.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(userNameSeparator).offset(15)
            make.trailing.equalTo(userNameSeparator).offset(-10)
        }
    }
    
//MARK:- textField delegates
    
    
    public func textFieldShouldEndEditing(textField: UITextField) -> Bool
    {
        if textField == usernameTextField {
            usernameTextField.resignFirstResponder()
            //passwordTextField.becomeFirstResponder()
            // call the get broker API
            if let usernameStr = textField.text {
                if usernameStr.isEmpty {
                    return true;
                }
                let loginAPIObj = DPLoginAPI()
                loginAPIObj.getBrokerList(usernameStr, cb: { json, error in
                    if (json.count > 0) {
                        var count: Int = 0
                        if json.count == 1 {
                            let broker = json[count]["tenant"]
                            self.selectedBrokerInfo = broker.rawString()!
                            self.eState = .BROKERSELECTEDSTATE
                            self.displayInfoAfterBrokerSelection(false)
                        }
                        else {
                            for (count = 0; count < json.count; count++ ) {
                                let broker = json[count]["tenant"]
                                self.selectedBrokerArr.addObject(broker.rawString() as! AnyObject)
                                self.displayBrokerInfoBeforeSelection(true)
                                self.brokerInfoTableView.reloadData()
                            }
                        }
                    }
                })
            }
        }
        else {
            passwordTextField.resignFirstResponder()
        }
        return true;
    }
    
//tableview delegates
    public func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    public func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return selectedBrokerArr.count;
    }
  public   
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell:UITableViewCell = self.brokerInfoTableView.dequeueReusableCellWithIdentifier(self.cellIdentifier) as UITableViewCell!
        cell.textLabel?.text=selectedBrokerArr[indexPath.row] as? String
        cell.textLabel?.font = UIFont(name: "Helvetica", size: 15)
        cell.textLabel?.textColor = UIColor.whiteColor()
        cell.backgroundColor = UIColor.clearColor()
        return cell;
    }
    
    public func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        selectedBrokerInfo = selectedBrokerArr[indexPath.row] as! String;
        eState = .BROKERSELECTEDSTATE
        self.displayInfoAfterBrokerSelection(false)
    }
}
