//
//  DPBrandingColorPickerViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/14/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrandingColorPickerViewController: DPAccountCreationBaseViewController {
    override func nextViewC1(sender: UIBarButtonItem) {
        
        print(self.childViewControllers)
        let accountViewCntrl = self.childViewControllers[0] as! DPBrandingDisplayColorTableViewController
        let (isSaved, colorSel) = accountViewCntrl.setDataFields()
        
        if isSaved == true {
            let nextViewController: DPBrandingWebsiteInfoViewController = DPBrandingWebsiteInfoViewController()
            self.navigationItem.backBarButtonItem?.title = " "
            self.navigationController?.pushViewController(nextViewController, animated: true)
            self.setNavigationPreferences(colorSel)
        }
    }
    
    func closeView(sender: UIBarButtonItem) {
        self.dismissViewControllerAnimated(true, completion: nil);
    }
    
    func applyColorView(colorSel: UIColor) {
        self.setNavigationPreferences(colorSel)
    }
    
    override func skipViewC1(sender: UIBarButtonItem) {
        print(self.childViewControllers)
//        let accountViewCntrl = self.childViewControllers[0] as! DPBrandingDisplayColorTableViewController
//        if accountViewCntrl.setDataFields() == true {
//            let nextViewController: DPBrandingStep2BioViewController = DPBrandingStep2BioViewController()
//            self.navigationItem.backBarButtonItem?.title = " "
//            self.navigationController?.pushViewController(nextViewController, animated: true)
//        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        // Do any additional setup after loading the view.
        self.navigationItem.title = "Branding"
        
        self.view.backgroundColor = UIColor.lightGrayColor()
        
        let tablecontr: DPBrandingDisplayColorTableViewController = DPBrandingDisplayColorTableViewController()
        self.addChildViewController(tablecontr)
        self.view.addSubview(tablecontr.view)
        tablecontr.didMoveToParentViewController(self)
        
        tablecontr.view.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self.view).offset(138)
            make.leading.equalTo(self.view).offset(5)
            make.trailing.equalTo(self.view).offset(-5)
            make.bottom.equalTo(self.view).offset(-5)
        }
        self.setStepIndication(tagStep1, state: 5)
        self.setStepIndication(tagStep2, state: 2)
        
        let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
        if let brokerBrandingcolorInfo: DPBrandingColorObj = brokerOnboardingInfo.loadBrokerageBrandingColorObjectWithKey() {
            if brokerBrandingcolorInfo.isSet == false {
                self.createSkipbutton()
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
