//
//  BrokerageRootView.swift
//  ProfessionalTools
//
//  Created by Pike Dev 01 on 25/10/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class BrokerageRootView: NSObject {
    
    var vwController                :UIViewController!
    var vwTabbarController          : UITabBarController!
    var vwHomeController            : UIViewController!
    var vwSearchController          : UIViewController!
    var vwAlertsController          : UIViewController!
    var vwMyAgentsController        : UIViewController!
    var vwMoreController            : UIViewController!
    
    var imgHome                     : UIImage!
    var imgSearch                   : UIImage!
    var imgAlerts                   : UIImage!
    var imgMyAgent                  : UIImage!
    var imgMore                     : UIImage!
    
    
    
    
    


    
    
    func loadBrokerageRootUI(inViewController :UIViewController){
        
        vwController            = inViewController
        
        createUIElements()
        setProperties()
        setProfileData()
        addElements2UI()
    }
    func createUIElements(){
        
        vwTabbarController      = UITabBarController()
        
        vwHomeController        =   BrokerageHomeViewController()
        vwSearchController      =   UIViewController()
        vwAlertsController      =   UIViewController()
        vwMyAgentsController    =   UIViewController()
        vwMoreController        =   BrokerageMoreViewController()
        
        

        
    }
    
    func setProperties()
    {
        imgHome             =      UIImageCustom().getImageFromString("homeInactive@3x.png")
        imgSearch           =      UIImageCustom().getImageFromString("searchInactive@3x.png")
        imgAlerts           =      UIImageCustom().getImageFromString("taskalertsInactive@3x.png")
        imgMyAgent          =      UIImageCustom().getImageFromString("myAgentInactive@3x.png")
        imgMore             =      UIImageCustom().getImageFromString("moreInactive@3x.png")

        let controllers : [UIViewController]    = [vwHomeController,vwSearchController,vwAlertsController,vwMyAgentsController,vwMoreController]
        vwTabbarController.viewControllers = controllers
        
        
        vwHomeController.tabBarItem         =   UITabBarItem(title: "HOME", image: imgHome, tag: 1)
        vwSearchController.tabBarItem       =   UITabBarItem(title: "SEARCH", image: imgSearch, tag: 2)
        vwAlertsController.tabBarItem       =   UITabBarItem(title: "ALERTS", image: imgAlerts, tag: 3)
        vwMyAgentsController.tabBarItem     =   UITabBarItem(title: "MYAGENTS", image: imgMyAgent, tag: 4)
        vwMoreController.tabBarItem         =   UITabBarItem(title: "MORE", image: imgMore, tag: 5)
        
        
        
        
        

        
    
    }
    func setProfileData()
    {
    
    }
    func addElements2UI()
    {
    vwController.presentViewController(vwTabbarController, animated: true, completion: nil)
    }
    
    

}
