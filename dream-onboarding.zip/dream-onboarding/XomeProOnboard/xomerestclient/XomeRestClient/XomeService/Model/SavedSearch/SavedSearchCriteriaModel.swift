//
//  SavedSearchCriteriaModel.swift
//  XomeRestClient
//
//  Created by Xome on 2/17/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class SavedSearchCriteriaModel: Mappable {
    public var associationFee: Double?
    public var builder: String?
    public var cumulativeDaysOnMarket: Int?
    public var developmentName: String?
    public var extendedCriteriaIds: [Int]?
    public var fullBaths: Int?
    public var halfBaths: Int?
    public var isAuctionContext: Bool?
    public var isAuctionTypeSearch: Bool?
    public var listingNumber: String?
    public var listingTypeId: Int?
    public var locations: [[PropertyRequestLocationModel]]?
    public var maxAcreage: Double?
    public var maxBaths: Int?
    public var maxBedrooms: Int?
    public var maxPrice: Int?
    public var maxSquareFootage: Int?
    public var maxUnits: Int?
    public var maxYearBuilt: Int?
    public var minAcreage: Double?
    public var minBaths: Int?
    public var minBedrooms: Int?
    public var minPrice: Int?
    public var minSquareFootage: Int?
    public var minUnits: Int?
    public var minYearBuilt: Int?
    public var newConstruction: Bool?
    public var openHouseNextXDays: Int?
    public var propertyTypeIds: String?
    public var propertyTypeIdsString: String?
    public var propertyTypes: String?
    public var publicRemarks: String?
    public var quarterBaths: Int?
    public var searchMapNeLat: Double?
    public var searchMapNeLong: Double?
    public var searchMapSwLat: Double?
    public var searchMapSwLong: Double?
    public var soldDate: Int?
    public var sortId: PropertySortOption?
    public var status: String?
    public var summary: String?
    public var threeQuarterBaths: Int?
    public var township1: String?
    public var township2: String?
    public var townshipRange1: String?
    public var townshipRange2: String?
    public var townshipSection1: String?
    public var townshipSection2: String?
    public var viewType: String?
    public var virtualTour: Bool?
    public var zoning: String?

    required public init?(_ map: Map) {
    }
    
    public func mapping(map: Map) {
        associationFee <- map["associationFee"]
        builder <- map["builder"]
        cumulativeDaysOnMarket <- map["cumulativeDaysOnMarket"]
        developmentName <- map["developmentName"]
        extendedCriteriaIds <- map["extendedCriteriaIds"]
        fullBaths <- map["fullBaths"]
        halfBaths <- map["halfBaths"]
        isAuctionContext <- map["isAuctionContext"]
        isAuctionTypeSearch <- map["isAuctionTypeSearch"]
        listingNumber <- map["listingNumber"]
        listingTypeId <- map["listingTypeId"]
        locations <- map["locations"]
        maxAcreage <- map["maxAcreage"]
        maxBaths <- map["maxBaths"]
        maxBedrooms <- map["maxBedrooms"]
        maxPrice <- map["maxPrice"]
        maxSquareFootage <- map["maxSquareFootage"]
        maxUnits <- map["maxUnits"]
        maxYearBuilt <- map["maxYearBuilt"]
        minAcreage <- map["minAcreage"]
        minBaths <- map["minBaths"]
        minBedrooms <- map["minBedrooms"]
        minPrice <- map["minPrice"]
        minSquareFootage <- map["minSquareFootage"]
        minUnits <- map["minUnits"]
        minYearBuilt <- map["minYearBuilt"]
        newConstruction <- map["newConstruction"]
        openHouseNextXDays <- map["openHouseNextXDays"]
        propertyTypeIds <- map["propertyTypeIds"]
        propertyTypeIdsString <- map["propertyTypeIdsString"]
        propertyTypes <- map["propertyTypes"]
        publicRemarks <- map["publicRemarks"]
        quarterBaths <- map["quarterBaths"]
        searchMapNeLat <- map["searchMapNeLat"]
        searchMapNeLong <- map["searchMapNeLong"]
        searchMapSwLat <- map["searchMapSwLat"]
        searchMapSwLong <- map["searchMapSwLong"]
        soldDate <- map["soldDate"]
        sortId <- map["sortId"]
        status <- map["status"]
        summary <- map["summary"]
        threeQuarterBaths <- map["threeQuarterBaths"]
        township1 <- map["township1"]
        township2 <- map["township2"]
        townshipRange1 <- map["townshipRange1"]
        townshipRange2 <- map["townshipRange2"]
        townshipSection1 <- map["townshipSection1"]
        townshipSection2 <- map["townshipSection2"]
        viewType <- map["viewType"]
        virtualTour <- map["virtualTour"]
        zoning <- map["zoning"]
    }
}