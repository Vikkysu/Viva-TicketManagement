//
//  PropertyDetailsInfoTransform.swift
//  XomeRestClient
//
//  Created by Vikas on 1/19/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class PropertyDetailsInfoTransform
    : TransformOf</*Object=*/PropertyDetailsInfoModel, /*JSON=*/[String:AnyObject]>
{

    init() {
        super.init(fromJSON: PropertyDetailsInfoTransform.catchAllTransformer,
            toJSON: PropertyDetailsInfoTransform.toJSONisNotSupported)
    }

    private static func toJSONisNotSupported(_ : Object?) -> JSON? {
        return nil
    }

    public static func catchAllTransformer(input: JSON?) -> Object? {
        guard let json = input,
            let id = PropertyDetailsInfoModel.Id(rawValue: json["id"] as? String ?? "") else {
            return nil
        }
        let builders : [PropertyDetailsInfoModel.Id : (JSON, Map) -> Object? ] = [
            .RoomInfo: self.roomInfo,
            .ListingInfo: self.listingInfo,
            .CommunityInfo: self.communityInfo,
            .ExteriorInfo: self.exteriorInfo,
            .FinanceInfo: self.financeInfo,
            .InteriorInfo: self.interiorInfo,
            .SchoolInfo: self.schoolInfo
        ]
        if let builder = builders[id] {
            return builder(json, Map(mappingType: .FromJSON, JSONDictionary: json))
        } else {
            return nil
        }
    }

    private static func roomInfo(json: JSON, map: Map) -> Object? {
        // items.items contains [[String:String]] where the "name" and "value" keys are an entry for this section
        guard let sectionsArray = json["items"] as? [[String:AnyObject]]
            else { return nil }

        let sectionNames = sectionsArray.map { $0["name"] as! String }
        let entries = sectionsArray.map {
            ($0["items"] as! [JSON]).map { json -> String in
                let name = json["name"] as? String
                if let value = json["value"] as? String where value.characters.count != 0 {
                    return "\(name!) \(value)"
                } else {
                    return name!
                }
            }
        }
        let sections = zip(sectionNames, entries)
            .map { return PropertyDetailsRoomInfoModel.InfoSection(name: $0, entries: $1) }
        return PropertyDetailsRoomInfoModel(sections: sections, map: map)
    }

    private static func simpleInfo<T: PropertyDetailsSimpleInfoModel>(map: Map) -> T? {
        return T(map)
    }
    private static func listingInfo(json: JSON, map: Map) -> PropertyDetailsListingInfoModel? {
        return simpleInfo(map)
    }
    private static func communityInfo(json: JSON, map: Map) -> PropertyDetailsCommunityInfoModel? {
        return simpleInfo(map)
    }
    private static func exteriorInfo(json: JSON, map: Map) -> PropertyDetailsExteriorInfoModel? {
        return simpleInfo(map)
    }
    private static func financeInfo(json: JSON, map: Map) -> PropertyDetailsFinanceInfoModel? {
        return simpleInfo(map)
    }
    private static func interiorInfo(json: JSON, map: Map) -> PropertyDetailsInteriorInfoModel? {
        return simpleInfo(map)
    }
    private static func schoolInfo(json: JSON, map: Map) -> PropertyDetailsSchoolInfoModel? {
        return simpleInfo(map)
    }

}
