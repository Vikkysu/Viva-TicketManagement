//
//  MakeAnOfferModel.swift
//  XomeRestClient
//
//  Created by Shivakumar Chandramouli on 2/5/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper


public class MakeAnOfferModel: Mappable {

    public var isOfferAccepted: Bool?
    public var redirectUrl: String?
    
    public init() {
        
    }
    
    required public init?(_ map: Map) {
        
    }
    
    public func mapping(map: Map) {
        isOfferAccepted <- map["isOfferAccepted"]
        redirectUrl <- map["redirectUrl"]
    }
}
