//
//  profileModel.swift
//  ProfessionalTools
//
//  Created by Vikas on 9/29/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class profileModel: NSObject {
    var profilePhoto : UIImage!
    var firstNameStr: String!
    var lastNameStr: String!
    var emailStr: String!
    var mobileNumStr: String!
    var passwordStr: String!
}
