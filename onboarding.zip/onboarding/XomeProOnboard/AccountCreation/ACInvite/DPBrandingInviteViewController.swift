//
//  DPBrandingInviteViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/20/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrandingInviteViewController: DPAccountCreationBaseViewController {
    
    var eState: flowStateInvite = .IAGENT
    
    func geteState()->flowStateInvite {
        return eState
    }
    
    func changeeState(lState : flowStateInvite) {
        eState = lState
    }

    override func nextViewC1(sender: UIBarButtonItem) {
        print("Invite agents")
        
        if eState == flowStateInvite.IAGENT {
            let nextViewController: DPBrandingInviteViewController = DPBrandingInviteViewController()
            self.navigationItem.backBarButtonItem?.title = " "
            nextViewController.eState = flowStateInvite.ICLIENT
            self.navigationController?.pushViewController(nextViewController, animated: true)
        }
        else {
            let nextViewController: DPBrandingSetupCompleteViewController = DPBrandingSetupCompleteViewController()
            self.navigationItem.backBarButtonItem?.title = " "
            self.navigationController?.pushViewController(nextViewController, animated: true)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        var titleText = "Invite Agents"
        if eState == flowStateInvite.ICLIENT {
            titleText = "Invite Clients"
        }
        self.navigationItem.title = titleText
        
        self.view.backgroundColor = UIColor.lightGrayColor()
        
        let tablecontr: DPBrandingInviteTableViewController = DPBrandingInviteTableViewController()
        self.addChildViewController(tablecontr)
        self.view.addSubview(tablecontr.view)
        tablecontr.didMoveToParentViewController(self)
        
        tablecontr.view.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self.view).offset(138)
            make.leading.equalTo(self.view).offset(5)
            make.trailing.equalTo(self.view).offset(-5)
            make.bottom.equalTo(self.view).offset(-5)
        }
        self.setStepIndication(tagStep1, state: 5)
        self.setStepIndication(tagStep2, state: 5)
        self.setStepIndication(tagStep3, state: 5)
        if eState == flowStateInvite.IAGENT {
            self.setStepIndication(tagStep4, state: 3)
        }
        else {
            self.setStepIndication(tagStep4, state: 4)
        }
        
        self.createNextbutton(INVITEBUTTON)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
