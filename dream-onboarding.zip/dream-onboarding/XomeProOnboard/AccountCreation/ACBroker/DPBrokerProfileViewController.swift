//
//  DPBrokerProfileViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/15/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrokerProfileViewController: DPAccountCreationBaseViewController {
    
    override func nextViewC1(sender: UIBarButtonItem) {
        
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            let accountViewCntrl = self.childViewControllers[0] as! DPBrokerProfileTableViewController
            if accountViewCntrl.setDataFields() == true {
                let vc = DPAgentBrokerageInfoViewController()
                self.navigationItem.backBarButtonItem?.title = " "
                self.navigationController?.pushViewController(vc, animated: true)
            }
        }
        else
        {
            let accountViewCntrl = self.childViewControllers[0] as! DPBrokerProfileTableViewController
            if accountViewCntrl.setDataFields() == true {
                let nextViewController: ACBrokarageStep3ViewController = ACBrokarageStep3ViewController()
                self.navigationItem.backBarButtonItem?.title = " "
                nextViewController.changeeState(flowState.MANAGEBROKER)
                self.navigationController?.pushViewController(nextViewController, animated: true)
            }
        }
    }
    
    func closeView(sender: UIBarButtonItem) {
        self.dismissViewControllerAnimated(true, completion: nil);
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        // Do any additional setup after loading the view.

        self.navigationItem.title = "Create an Account"
        
        self.view.backgroundColor = UIColor.lightGrayColor()
        
        let tablecontr: DPBrokerProfileTableViewController = DPBrokerProfileTableViewController()
        self.addChildViewController(tablecontr)
        self.view.addSubview(tablecontr.view)
        tablecontr.didMoveToParentViewController(self)
        
        tablecontr.view.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self.view).offset(138)
            make.leading.equalTo(self.view).offset(5)
            make.trailing.equalTo(self.view).offset(-5)
            make.bottom.equalTo(self.view).offset(-5)
        }
        
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
        }
        else
        {
            self.setStepIndication(tagStep1, state: 5)
            self.setStepIndication(tagStep2, state: 5)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    //    func textFieldDidBeginEditing(textField: UITextField) {
    //        var cell: UITableViewCell;
    //        // Load resources for iOS 7 or later
    //        cell = textField.superview as! UITableViewCell
    //        // TextField -> UITableVieCellContentView -> (in iOS 7!)ScrollView -> Cell!
    //        tableView.scrollToRowAtIndexPath(tableView.indexPathForCell(cell)!, atScrollPosition:.Top, animated: true)
    //    }
    
}
