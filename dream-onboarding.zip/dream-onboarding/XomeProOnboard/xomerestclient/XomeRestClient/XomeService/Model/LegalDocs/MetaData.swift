//
//  MetaData.swift
//  XomeRestClient
//
//  Created by Shivakumar Chandramouli on 4/5/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

@objc public class MetaData: NSObject, Mappable {
    
    public var phoneNumber : String?
    
    override public init() {
        
    }
    
    required public init?(_ map: Map) {
        
    }
    
    public func mapping(map: Map) {
        
        phoneNumber <- map["PhoneNumber"]
    }
}

