//
//  DPStepIndicationBarView.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/11/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPStepIndicationBarView: UIView {
    static let sharedInstance = DPStepIndicationBarView(rect: CGRectZero)
    
    init(rect: CGRect) {
        super.init(frame: CGRectMake(0, 0, 320, 70))
    }
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
    
    func setStepIndication(tagIdentification: Int, state: Int)
    {
        let stepLabel: UIImageView = self.viewWithTag(tagIdentification) as! UIImageView
        let myColor : UIColor = UIColor.grayColor()
        stepLabel.layer.borderColor = myColor.CGColor
        
        //TODO: set the angle based on the CALCULATION
        let startAngle: CGFloat = CGFloat(3*M_PI/2)
        var endAngle: CGFloat = CGFloat(2*M_PI)
        if state == 3 {
            endAngle = CGFloat(M_PI/2)
        } else if state == 4 {
            endAngle = CGFloat(M_PI)
        } else if state == 5 {
            endAngle = CGFloat(45)
        }
        
        if state > 1 {
            let circle: CAShapeLayer = CAShapeLayer();
            let circlePath : UIBezierPath = UIBezierPath(arcCenter: CGPointMake(15, 15), radius: 15, startAngle: startAngle, endAngle: endAngle, clockwise: true)
            circle.path = circlePath.CGPath
            circle.fillColor=UIColor.clearColor().CGColor;
            let greenCol = UIColor.baoDarkLimeGreenColor()
            
            circle.strokeColor=greenCol.CGColor;
            circle.lineWidth=2;
            
            let animation: CABasicAnimation = CABasicAnimation(keyPath: "strokeEnd")
            animation.duration=0.5;
            animation.removedOnCompletion=false;
            animation.fromValue = (0);
            animation.toValue = (1);
            animation.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionLinear)
            circle.addAnimation(animation, forKey: "drawCircleAnimation")
            
            stepLabel.layer.sublayers?.removeAll()
            stepLabel.layer.addSublayer(circle)
            
        }
        
        if state == 5 {
            stepLabel.image = UIImageCustom().getImageFromString("stepCompletion")
        }
    }

    func createViewForStepIndication(rect: CGRect, stepNum: String, stepName: String, tagIdentification: Int) ->UIView {
        let stepView = UIView(frame: rect)
        stepView.backgroundColor = UIColor.clearColor()
        
        let stepLayer = UIImageView(frame: CGRectMake(rect.size.width/2-15, 5, 30, 30))
        stepLayer.tag = tagIdentification
        stepLayer.image = UIImageCustom().getImageFromString(stepNum)
        stepView.addSubview(stepLayer)
        
        let stepLayerLabel = UILabel(frame: CGRectMake(0, stepLayer.frame.size.height+5, rect.size.width, 20))
        stepLayerLabel.text = stepName
        stepLayerLabel.textAlignment = NSTextAlignment.Center
        stepLayerLabel.font = UIFont.systemFontOfSize(8)
        stepLayerLabel.textColor = UIColor.lightGrayColor()
        stepView.addSubview(stepLayerLabel)
        return stepView
    }
    
    func createStepIndicationBar() ->UIView {
        let screenRect: CGRect = UIScreen.mainScreen().bounds //[[UIScreen mainScreen] bounds];
        let screenWidth: CGFloat = screenRect.size.width;
        
        
        let exampleView = UIView(frame: CGRectMake(0, 0, screenWidth, 70))
        exampleView.backgroundColor = UIColor.whiteColor()
        
        let myColor : UIColor = UIColor.lightGrayColor()
        exampleView.layer.borderWidth = 1
        exampleView.layer.borderColor = myColor.CGColor
        
        self.addSubview(exampleView)
        
        let heightRect: CGFloat = 50.0
        let width: CGFloat = screenWidth/4
        
        //TODO:- Need to support agent creation
        exampleView.addSubview(self.createViewForStepIndication(CGRectMake(0, 5, width, heightRect), stepNum: "step1", stepName: "BROKERAGE", tagIdentification: tagStep1))
        exampleView.addSubview(self.createViewForStepIndication(CGRectMake(width, 5, width, heightRect), stepNum: "step2", stepName: "BRANDING", tagIdentification: tagStep2))
        exampleView.addSubview(self.createViewForStepIndication(CGRectMake(width*2, 5, width, heightRect), stepNum: "step3", stepName: "BROKER", tagIdentification: tagStep3))
        exampleView.addSubview(self.createViewForStepIndication(CGRectMake(width*3, 5, width, heightRect), stepNum: "step4", stepName: "INVITES", tagIdentification: tagStep4))
        return self
    }
    
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
