//
//  DreamOnboardingRouteConfig.swift
//  XomeProOnboard
//
//  Created by Vikas on 10/16/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import XomeRouting

class DreamOnboardingRouteConfig: NSObject, XomeRouteConfiguration {
    
    init(copy:DreamOnboardingRouteConfig!){
        
    }
    
    override init(){
        super.init()
    }
    
    func copyWithZone(zone: NSZone) ->AnyObject{
        return DreamOnboardingRouteConfig(copy:self)
    }
    
    func navigationBarItemsForRouteController(routeController:XomeRouteController!)->[AnyObject]! {
        return []
        
    }
    
    func viewControllerForScene() -> UIViewController {
        return DPSignInViewController()
    }
    
    
}
