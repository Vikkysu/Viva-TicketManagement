//
//  LeadsViewController.swift
//  ProfessionalTools
//
//  Created by MacMini5 on 21/10/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class LeadsViewController: UIViewController {

    var leadsView   :LeadsView  = LeadsView()
    var leadsModel  :LeadsModel = LeadsModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.loadLeadsView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        leadsView.touchesDetermined()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func loadLeadsView(){
        
        let leadsDataArray  :NSMutableArray = leadsModel.createAndGetDataSample()
        leadsView.loadLeadsUI(self, inDataArray: leadsDataArray,isInitialController: true)
        
    }
    
}
