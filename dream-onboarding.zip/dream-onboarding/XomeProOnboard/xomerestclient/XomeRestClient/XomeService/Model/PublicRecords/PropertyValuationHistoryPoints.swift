//
//  PropertyValuationHistoryPoints.swift
//  XomeRestClient
//
//  Created by Xome on 2/4/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class PropertyValuationHistoryPoints: Mappable {
    
    public var date: NSDate?
    public var value: Double?
    
    required public init?(_ map: Map) {
        
    }
    
    public func mapping(map: Map) {
        date <- (map["date"], XomeBadDateStringTransform())
        value <- map["value"]
    }
}