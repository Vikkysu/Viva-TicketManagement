//
//  AppDelegate.swift
//  ProfessionalTools
//
//  Created by rluas on 9/18/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit
import Fabric
import Crashlytics

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        window = UIWindow(frame: UIScreen.mainScreen().bounds)
        window!.rootViewController = self.initSB()
        window!.makeKeyAndVisible()
        
        Fabric.with([Crashlytics.self()])
        return true
    }

    func applicationWillResignActive(application: UIApplication) {

    }

    func applicationDidEnterBackground(application: UIApplication) {

    }

    func applicationWillEnterForeground(application: UIApplication) {

    }

    func applicationDidBecomeActive(application: UIApplication) {

    }

    func applicationWillTerminate(application: UIApplication) {

    }
    
    
    
//MARK: jump to the vc your working on...
    func initSB() -> (UIViewController) {
        let sb = Global().spinUpBoard("NewUser")
        let initVC = sb?.instantiateViewControllerWithIdentifier("DPPaginateParent")
        return initVC!
    }
    
    
}
