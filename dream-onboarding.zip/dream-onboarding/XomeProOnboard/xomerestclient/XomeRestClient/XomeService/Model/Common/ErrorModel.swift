//
//  ErrorModel.swift
//  XomeRestClient
//
//  Created by Brendan Farrington on 2/2/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class ErrorModel: MessageModel {
    public var code: NSNumber?

    public override func mapping(map: Map) {
        super.mapping(map)
        code <- map["code"]
    }
}