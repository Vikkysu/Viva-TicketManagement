//
//  Global.swift
//  ProfessionalTools
//
//  Created by Vikas on 9/18/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import UIKit

class Global:NSObject {
    
    var isFirstUse:Bool? = true
    
    
    func spinUpBoard(boardName:String) -> UIStoryboard?
    {
        let targetSB = UIStoryboard(name:boardName,bundle:NSBundle.mainBundle())
        return targetSB
    }
    
    struct GlobalIntegers {
        static let NUM_PAGES = 3
    }
    
    struct BrandableFonts {
        static let MSR_100 = UIFont(name:"MuseoSansRounded",size:16.0)
        static let MSR_300 = UIFont(name:"MuseoSansRounded",size:25.0)//used on welcome screens
    }

}
