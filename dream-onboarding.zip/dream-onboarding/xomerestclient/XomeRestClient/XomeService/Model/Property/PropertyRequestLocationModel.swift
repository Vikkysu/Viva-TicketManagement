//
//  PropertyRequestLocationModel.swift
//  XomeRestClient
//
//  Created by Vikas on 12/16/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import CoreLocation
import ObjectMapper

public class PropertyRequestLocationModel: MappableCluster {
    public var type: String?

    public static func objectForMapping(map: Map) -> Mappable? {
        if let type: String = map["type"].value() {
            switch type {
            case "points":
                return PropertyRequestBoundaryModel(map)
            default:
                return PropertyRequestQueryModel(map)
            }
        }
        return nil
    }
    
    public init(type: String?) {
        self.type = type
    }
    
    public required init?(_ map: Map){
    }
    
    public func mapping(map: Map) {
        type <- map["type"]
    }
}

public class PropertyRequestQueryModel: PropertyRequestLocationModel {
    public var name: String?
    public var value: String?
    public var invert: String?

    public init(name: String? = nil, type: PropertyQueryType? = nil, value: String? = nil, invert: Bool = false) {
        super.init(type: type?.rawValue)
        self.name = name
        self.value = value
        self.invert = invert ? "true" : "false"
    }

    public required init?(_ map: Map) {
        super.init(map)
    }

    public override func mapping(map: Map) {
        super.mapping(map)
        
        name <- map["name"]
        value <- map["value"]
        invert <- map["isNot"]
    }
}

public class PropertyRequestBoundaryModel: PropertyRequestLocationModel {
    public var name: String!
    public var value: String!
    public var isOr: Bool!
    public let points: [CLLocationCoordinate2D]
    
    public init(points: [CLLocationCoordinate2D]) {
        self.points = points

        super.init(type: "points")
        name = "Rectangle"
        isOr = true
        value = points
            .map { "\($0.latitude),\($0.longitude)" }
            .joinWithSeparator(",")
    }
    
    required public init?(_ map: Map) {
        let value = map["value"].valueOr("")
        let latLongList = value.componentsSeparatedByString(",").flatMap { CLLocationDegrees($0) }
        points = (0..<latLongList.count/2).map {
            let index = $0 * 2
            return CLLocationCoordinate2D(latitude: latLongList[index], longitude: latLongList[index+1])
        }
        super.init(map)
    }

    public override func mapping(map: Map) {
        super.mapping(map)
        
        name <- map["name"]
        value <- map["value"]
        isOr <- (map["isOr"], TransformOf<Bool, String>(
            fromJSON: { str -> Bool? in
                guard let _str = str else { return nil }
                return NSString(string: _str).boolValue
            },
            toJSON: { value -> String? in
                guard let _value = value else { return nil }
                return _value ? "true" : "false"
        }))
    }
}
