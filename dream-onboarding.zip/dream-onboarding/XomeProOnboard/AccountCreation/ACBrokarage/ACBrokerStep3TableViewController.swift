//
//  ACBrokerStep3TableViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/4/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class ACBrokerStep3TableViewController: UITableViewController, UITextFieldDelegate {
    var brokerLicenseArr: NSMutableArray = NSMutableArray()
    var totalcount: Int = 0
    
    func setDataFields() -> Bool
    {
        var isValidated: Bool = false
        
        isValidated = addLicenseInfo()
        
        //TODO: Need to refactor to obtimize the code
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            let brokerOnboardingInfo: DPAgentOnBoardingModel = DPAgentOnBoardingModel.sharedInstance
            let brokerBrokerageLicenseInfo: DPBrokerLicenseInfo = DPBrokerLicenseInfo()
                brokerBrokerageLicenseInfo.brokerLicenseArr = brokerLicenseArr
                
            if isValidated == true {
                brokerOnboardingInfo.brokerLicenseModelObj(brokerBrokerageLicenseInfo)
                brokerOnboardingInfo.saveBrokerLicenseCustomObject(brokerBrokerageLicenseInfo)
            }
        }
        else
        {
            let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
            let parentViewC : ACBrokarageStep3ViewController =  self.parentViewController as! ACBrokarageStep3ViewController
            let eState: flowState = parentViewC.geteState()
            
            if(eState == flowState.BROKERAGE) {
                let brokerBrokerageLicenseInfo: DPBrokerageLicenseInfo = DPBrokerageLicenseInfo()
                brokerBrokerageLicenseInfo.brokerLicenseArr = brokerLicenseArr
                
                if isValidated == true {
                    brokerOnboardingInfo.brokerageLicenseModelObj(brokerBrokerageLicenseInfo)
                    brokerOnboardingInfo.saveBrokerageLicenseCustomObject(brokerBrokerageLicenseInfo)
                }
            }
            else {
                let brokerBrokerageLicenseInfo: DPBrokerLicenseInfo = DPBrokerLicenseInfo()
                brokerBrokerageLicenseInfo.brokerLicenseArr = brokerLicenseArr
                
                if isValidated == true {
                    brokerOnboardingInfo.brokerLicenseModelObj(brokerBrokerageLicenseInfo)
                    brokerOnboardingInfo.saveBrokerLicenseCustomObject(brokerBrokerageLicenseInfo)
                }
            }

        }

        return isValidated
    }
    
    func addLicenseInfo()-> Bool {
        var isValidated: Bool = true

        if brokerLicenseArr.count == 0 {
            let brokerCell: ACBrokerLicenseInfoTableViewCell = tableView.cellForRowAtIndexPath(NSIndexPath(forRow: brokerLicenseArr.count == 0 ? brokerLicenseArr.count+1: brokerLicenseArr.count, inSection: 0)) as! ACBrokerLicenseInfoTableViewCell
            if(brokerCell.brokerLicenseInfo.text != "" || (brokerCell.brokerLicenseStateInfo.text != "")) {
                print("has text")
            }
            else
            {
                let alertView: UIAlertView = UIAlertView(title: "", message: "Please enter atleast one License info", delegate: self, cancelButtonTitle: "OK")
                alertView.show()
                isValidated = false
                return isValidated
            }
        }
        
        // remove all elemts in array
        brokerLicenseArr.removeAllObjects()
        
        brokerLicenseArr = NSMutableArray()
        
        var count: Int = 1
        
        for (count; count < totalcount; count++)
        {
            if let brokerCell: ACBrokerLicenseInfoTableViewCell = tableView.cellForRowAtIndexPath(NSIndexPath(forRow: count == 0 ? count+1: count, inSection: 0)) as? ACBrokerLicenseInfoTableViewCell {
                var brokerLicenseInfo: String = ""
                let brokerageLicense: DPBrokerageLicenseObj = DPBrokerageLicenseObj()

                if(brokerCell.brokerLicenseInfo.text != "") {
                    brokerLicenseInfo = brokerCell.brokerLicenseInfo.text!
                    brokerageLicense.brokerageLicenseNumber = brokerLicenseInfo
                }
                var brokerLicenseState: String = ""
                if(brokerCell.brokerLicenseStateInfo.text != "") {
                    brokerLicenseState = brokerCell.brokerLicenseStateInfo.text!
                    brokerageLicense.brokerageLicenseState = brokerLicenseState
                    brokerLicenseArr.addObject(brokerageLicense)
                }
                brokerCell.editing = true;
            }
        }
        return isValidated
    }

    @IBAction func addBrokerLicenseInfo(sender: AnyObject) {
        print("add another license")
        self.addLicenseInfo()
        tableView.reloadData()
    }

    override func viewDidLoad() {
        // Do any additional setup after loading the view.
        
        //TODO: Need to refactor to obtimize the code
        // fill the fields if saved offline
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            //in case of Agent
            let brokerOnboardingInfo: DPAgentOnBoardingModel = DPAgentOnBoardingModel.sharedInstance
            //brokerOnboardingInfo.removeBrokerageLicenseSavedObj()
            
            let parentViewC : ACBrokarageStep3ViewController =  self.parentViewController as! ACBrokarageStep3ViewController
            let eState: flowState = parentViewC.geteState()
            if eState == flowState.BROKERAGE {
                let brokerObj: DPBrokerLicenseInfo? = brokerOnboardingInfo.loadBrokerLicenseCustomObjectWithKey()
                if let brokerModelObj = brokerObj {
                    brokerLicenseArr = brokerModelObj.brokerLicenseArr
                }
                
            }
        }
        else
        {
            //in case of Broker
            let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
            //brokerOnboardingInfo.removeBrokerageLicenseSavedObj()
            
            let parentViewC : ACBrokarageStep3ViewController =  self.parentViewController as! ACBrokarageStep3ViewController
            let eState: flowState = parentViewC.geteState()
            if eState == flowState.BROKERAGE {
                let brokerObj: DPBrokerageLicenseInfo? = brokerOnboardingInfo.loadBrokerageLicenseCustomObjectWithKey()
                if let brokerModelObj = brokerObj {
                    brokerLicenseArr = brokerModelObj.brokerLicenseArr
                }

            }
            else {
                let brokerObj: DPBrokerLicenseInfo? = brokerOnboardingInfo.loadBrokerLicenseCustomObjectWithKey()
                if let brokerModelObj = brokerObj {
                    brokerLicenseArr = brokerModelObj.brokerLicenseArr
                }
            }
        }

        tableView.delegate=self
        tableView.dataSource=self
        tableView.showsHorizontalScrollIndicator=false
        tableView.showsVerticalScrollIndicator=false
        tableView.separatorStyle = .None
        tableView.registerClass(ACBrokerageStep1HeaderCell.self, forCellReuseIdentifier: "reuseIdentifier")
        tableView.registerClass(ACBrokerLicenseInfoTableViewCell.self, forCellReuseIdentifier: "brokerLicenseInfo")
    }
    
    
    // MARK: Tableview delegates    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if brokerLicenseArr.count == 0 {
            totalcount = 2
        }
        else {
            totalcount = brokerLicenseArr.count+2
        }
        return totalcount
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 100
        }
        return 60
    }

    override
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        //headerBrokerInfo
        if(indexPath.row == 0)
        {
            let cell: ACBrokerageStep1HeaderCell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath) as! ACBrokerageStep1HeaderCell
            let label: UILabel? = cell.viewWithTag(34) as? UILabel
            
            let parentViewC : ACBrokarageStep3ViewController =  self.parentViewController as! ACBrokarageStep3ViewController

            if parentViewC.geteState() == flowState.BROKERAGE {
                label!.text = "Great! Now Provide\nBrokerage License(s)."
            }
            else {
                label!.text = "Provide your Brokerage License(s)."
            }
            cell.selectionStyle = .None
            return cell
        }
        
        let cell: ACBrokerLicenseInfoTableViewCell = tableView.dequeueReusableCellWithIdentifier("brokerLicenseInfo") as! ACBrokerLicenseInfoTableViewCell
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        let headerLbl : UILabel = cell.viewWithTag(50) as! UILabel

        let parentViewC : ACBrokarageStep3ViewController =  self.parentViewController as! ACBrokarageStep3ViewController
        
        if parentViewC.geteState() == flowState.BROKERAGE {
            headerLbl.text = "BROKERAGE LICENSE NUMBER"
        }
        else {
            headerLbl.text = "BROKER LICENSE NUMBER"
        }
        
        let addBtnView : UIButton = cell.viewWithTag(54) as! UIButton
        let textFieldInfo : UITextField? = cell.viewWithTag(51) as? UITextField
        let textFieldState : UITextField? = cell.viewWithTag(53) as? UITextField
        
        textFieldInfo?.delegate=self
        textFieldState?.delegate=self
        
        //logic to show the add button for last row
        
        if(indexPath.row == totalcount-1) {
//            addPressed--
        }

        if(indexPath.row == totalcount-1 && totalcount <= 2 && self.brokerLicenseArr.count == 1) // this condition hekps to show the + button only when there is 1 row filled with data
        {
                addBtnView.hidden = false
        }
        else
        {
            if(indexPath.row == totalcount-1)
            {
                //addBtnView.hidden = false
            }
            else
            {
                addBtnView.hidden = true
            }
        }
        addBtnView.addTarget(self, action: "addBrokerLicenseInfo:", forControlEvents: .TouchUpInside)
        
        if brokerLicenseArr.count > indexPath.row-1 {
            let brokerDict: DPBrokerageLicenseObj = brokerLicenseArr[indexPath.row-1] as! DPBrokerageLicenseObj
            cell.brokerLicenseInfo.text = brokerDict.brokerageLicenseNumber
            cell.brokerLicenseStateInfo.text = brokerDict.brokerageLicenseState
        }
        
        return cell
    }
    
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        if indexPath.row <= 1 {
            return false
        }
        
        return true
    }
    
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if (editingStyle == UITableViewCellEditingStyle.Delete) {
            // handle delete (by removing the data from your array and updating the tableview)
            //if(brokerLicenseArr.count > indexPath.row)
            //{
                brokerLicenseArr.removeObjectAtIndex(indexPath.row)
            //}
            tableView.reloadData()
        }
    }
    
    //MARK:- custom text field methods
    func endEditingNow() {
        self.view.endEditing(true)
    }
    
    func addKeypadToolBar(textField: UITextField) {
        // Create a button bar for the number pad
        let keyboardDoneButtonView = UIToolbar()
        keyboardDoneButtonView.sizeToFit()
        
        // Setup the buttons to be put in the system.
        let item = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.Plain, target: self, action: Selector("endEditingNow") )
        let toolbarButtons = [item]
        
        //Put the buttons into the ToolBar and display the tool bar
        keyboardDoneButtonView.setItems(toolbarButtons, animated: false)
        textField.inputAccessoryView = keyboardDoneButtonView
    }
    
    func displayNextField(textField: UITextField) {
//        if let brokerCell: ACBrokerLicenseInfoTableViewCell = tableView.cellForRowAtIndexPath(NSIndexPath(forRow: totalcount == 0 ? totalcount+1: totalcount-1, inSection: 0)) as? ACBrokerLicenseInfoTableViewCell {
//            if textField.tag == 51 {
//                brokerCell.brokerLicenseStateInfo.becomeFirstResponder()
//            }
//            else
//            {
//                let string: String? = textField.text?.uppercaseString
//                brokerCell.brokerLicenseStateInfo.text = string
//                let addBtnView : UIButton = brokerCell.viewWithTag(54) as! UIButton
//                if string!.isEmpty {
//                    addBtnView.hidden = true
//                }
//                else
//                {
//                    addBtnView.hidden = false
//                }
//                //self.addLicenseInfo()
//            }
//        }
        
        if textField.tag == 51 {
            textField.resignFirstResponder()
        }
        else
        {
            let string: String? = textField.text?.uppercaseString
            textField.text = string
            if let brokerCell: ACBrokerLicenseInfoTableViewCell = tableView.cellForRowAtIndexPath(NSIndexPath(forRow: totalcount == 0 ? totalcount+1: totalcount-1, inSection: 0)) as? ACBrokerLicenseInfoTableViewCell {
                let addBtnView : UIButton = brokerCell.viewWithTag(54) as! UIButton
                if string!.isEmpty {
                    addBtnView.hidden = true
                }
                else
                {
                    addBtnView.hidden = false
                }
            }
            //self.addLicenseInfo()
        }

    }

    //MARK: - text field delegates
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        if textField.tag == 51 {
            addKeypadToolBar(textField)
        }
        return true
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        displayNextField(textField)
    }

    func textFieldShouldReturn(textField: UITextField) -> Bool
    {
        displayNextField(textField)
        textField.resignFirstResponder()
        return true
    }
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        if textField.tag != 51 {
            let countLen = textField.text!.characters.count + string.characters.count
            if countLen > 2 {
                return false
            }
        }
        return true
    }

}
