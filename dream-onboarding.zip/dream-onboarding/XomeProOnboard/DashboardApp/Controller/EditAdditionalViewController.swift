//
//  EditProfileViewController.swift
//  ProfessionalTools
//
//  Created by MACMINI4 on 23/10/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class EditAdditionalViewController: UIViewController {

    var profileModel  : ProfileModel = ProfileModel()
    
    let editAdditionalModel : EditAdditionalModel = EditAdditionalModel()
    let editAdditionalView   : EditAdditionalVIew   = EditAdditionalVIew()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.editProfileViewModel()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    func editProfileViewModel() {
        
        editAdditionalModel.fillProfile(profileModel, cb: { (EditAdditionalModel) -> () in
            self.editAdditionalView.loadEditProfileUI(self, inEditAdditionalModel: EditAdditionalModel)
        })
    }
}