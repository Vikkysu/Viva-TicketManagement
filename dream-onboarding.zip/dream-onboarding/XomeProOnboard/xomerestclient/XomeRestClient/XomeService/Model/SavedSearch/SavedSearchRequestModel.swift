//
//  SavedSearchRequestModel.swift
//  XomeRestClient
//
//  Created by Xome on 1/27/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper
import CoreLocation

public class SavedSearchRequestModel: Mappable {

    public var name: String?
    public var description: String?
    public var propertyDetails: PropertyRequestModel?
    
    public init(name: String? = nil,
        description: String? = nil,
        propertyDetails: PropertyRequestModel)
    {
        self.name = name
        self.description = description
        self.propertyDetails = propertyDetails
    }
    
    required public init?(_ map: Map) {
        
    }
    
    public func mapping(map: Map) {
        name <- map["Name"]
        description <- map["Description"]
        propertyDetails <- map["Criteria"]
    }
}