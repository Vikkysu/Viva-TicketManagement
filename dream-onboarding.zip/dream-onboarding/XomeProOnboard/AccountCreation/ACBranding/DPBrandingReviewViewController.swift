//
//  DPBrandingReviewViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/8/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrandingReviewViewController: UIViewController {
    var eState: flowState = .BROKERAGE

    func closeView(sender: UIBarButtonItem) {
        self.dismissViewControllerAnimated(true, completion: nil);
    }
    
    func CreatingAccount(sender: AnyObject) {
        print("Account created")
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            let agentCreation = createAgentAccount()
            agentCreation.createAgent() { json, error in
                print(json)
                if (json.error == nil) {
                let completion: DPBrokerCompletionViewController = DPBrokerCompletionViewController()
                self.navigationController?.pushViewController(completion, animated: true)
                return;
                }
            }
        }
        else {
            let createBroker = createBrokerageAccount()
            createBroker.createBroker() { json, error in
                if (json.error == nil) {
                    print(json)
                    let completion: DPBrokerCompletionViewController = DPBrokerCompletionViewController()
                    self.navigationController?.pushViewController(completion, animated: true)
                    return;
                }
            }
        }
    }
    
    func geteState()->flowState {
        return eState
    }
    
    func changeeState(lState : flowState) {
        eState = lState
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        // Do any additional setup after loading the view.
        self.navigationItem.title = "Review and Submit"
        self.view.backgroundColor = UIColor.lightGrayColor()
        let headerView: DPBrandingReviewMainHeader = DPBrandingReviewMainHeader(rect: CGRectZero)
        
        self.view.addSubview(headerView.displayHeaderView())
        
        let tablecontr: DPBrandingReviewTableViewController = DPBrandingReviewTableViewController()
        self.addChildViewController(tablecontr)
        self.view.addSubview(tablecontr.view)
        tablecontr.didMoveToParentViewController(self)
        
        let continueOnBoarding: UIButton = UIButton()
        continueOnBoarding.backgroundColor = UIColor.baoPrimaryColor()
        continueOnBoarding.setTitle("Submit MLS Verification", forState: .Normal)
        continueOnBoarding.titleLabel?.font = UIFont(name: MuseoSansRounded300Font, size: 16.0)
        continueOnBoarding.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        continueOnBoarding.addTarget(self, action: "CreatingAccount:", forControlEvents: .TouchUpInside)
        self.view.addSubview(continueOnBoarding)
        
        tablecontr.view.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self.view).offset(143)
            make.leading.equalTo(self.view).offset(5)
            make.trailing.equalTo(self.view).offset(-5)
            make.bottom.equalTo(self.view).offset(-50)
        }
        
        continueOnBoarding.snp_makeConstraints {(make) ->Void in
            make.leading.equalTo(self.view).offset(0)
            make.trailing.equalTo(self.view).offset(0)
            make.bottom.equalTo(self.view).offset(0)
            make.height.equalTo(50)
        }

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
