//
//  ProfileView.swift
//  ProfessionalTools
//
//  Created by Developer on 23/10/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class ProfileView: NSObject {

    var profileModel                : ProfileModel!
    var vwController                :UIViewController!
    
    var vwMain                      :UIView!
    var vwHeader                    :UIView!
    var vwHeaderRight               :UIImageView!
    var vwDisplayPic                :UIView!
    var imgProfilePic               :UIImageView!
    //var vwGreyBand                :UIView!
    var vwContactInfo               :UIView!
    var vwAdditionalInfo            :UIView!
    var vwFooter                    :UIView!
    var segOperations               :UISegmentedControl!
    
    var lblContact1                 :UILabel!
    var lblEditContact              :UILabel!
    var imgEdit                     :UIImageView!
    var btnEditContact          : UIButton!
    var lblContactInfoHdr           :UILabel!
    var lblContactData              :UILabel!
    
    
    var btnXheader                  :UIButton!
    var lblHeader                   :UILabel!
    var btnRtHeader                 :UIButton!
    
    var lblShopper                  :UILabel!
    var lblAgent                    :UILabel!
    
    var cgScreenWidth               :CGFloat!
    var cgScreenHeight              :CGFloat!
    
    var lblAddition                 :UILabel!
    var lblEditAddition              :UILabel!
    var imgAdditionalEdit                    :UIImageView!
    var btnEditAdditionalInfo          : UIButton!

    var lblAdditionAddrInfoHdr           :UILabel!
    var lblAdditionAddrData              :UILabel!
    
    var lblAdditionInterestInfoHdr           :UILabel!
    var lblAdditionInterestData              :UILabel!
    
    
    func loadProfileUI(inViewController :UIViewController, inProfileModel: ProfileModel){
        
        vwController   = inViewController
        profileModel   = inProfileModel
        
        getScreenDimensions()
        createUIElements()
        setProperties()
        setProfileData()
        addElements2UI()
        
    }
    
    func getScreenDimensions(){
        
        let screenDimensions = UIScreen.mainScreen().bounds
        cgScreenWidth        = screenDimensions.width
        cgScreenHeight       = screenDimensions.height
    }
    
    func centreX(inWidth: CGFloat)->CGFloat{
        
        let tWidth:CGFloat  = cgScreenWidth - CGFloat(inWidth)
        let pX: CGFloat     = tWidth/2
        
        return pX
    }
    
    func centreY(inHeight: CGFloat)->CGFloat{
        
        let tHeight:CGFloat  = cgScreenHeight - CGFloat(inHeight)
        let pY: CGFloat      = tHeight/2
        
        return pY
    }
    
    func convert2Pixels(points:CGFloat)->CGFloat{
        
        let pixels  :CGFloat = points * 96 / 72
        return pixels
    }
    
    func createUIElements(){
        
        let hdrVwHeight :CGFloat = self.convert2Pixels(65)
        let hdrWidth    :CGFloat = self.convert2Pixels(80)
        let hdrHeight   :CGFloat = self.convert2Pixels(22)
        let hdRtWidth   :CGFloat = self.convert2Pixels(30)
        let hdRtHeight  :CGFloat = self.convert2Pixels(30)
        let hdRtX       :CGFloat = cgScreenWidth - hdRtWidth - 20 //constraint set to hdRtWidth
        let hdRTY       :CGFloat = self.convert2Pixels(31)
        let hdrX        :CGFloat = self.centreX(hdrWidth)
        let hdrY        :CGFloat = self.convert2Pixels(31)
        let vwDHeight   :CGFloat = self.convert2Pixels(150)
        //let bandWidth   :CGFloat = self.convert2Pixels(60)
        let segMenuItems         = ["Overview", "Statistics"]
        let segWidth    :CGFloat = cgScreenWidth - 100 //constraint set to 100
        let segHeight   :CGFloat = self.convert2Pixels(30)
        let segX        :CGFloat = self.centreX(325)
        let segY        :CGFloat = hdrVwHeight+vwDHeight+15
        let conY        :CGFloat = segY+segHeight+15
        let conHeight   :CGFloat = self.convert2Pixels(123)
        let addY        :CGFloat = conY+conHeight+15
        let addHeight   :CGFloat = cgScreenHeight - addY-4
        let profX       :CGFloat = self.centreX(110)
        let ci1Y        :CGFloat = self.convert2Pixels(15)
        let ci1X        :CGFloat = self.convert2Pixels(16)
        let ciWidth     :CGFloat = self.convert2Pixels(130)
        let ciHeight    :CGFloat = self.convert2Pixels(18)

        let ai1Y        :CGFloat = self.convert2Pixels(15)
        let ai1X        :CGFloat = self.convert2Pixels(16)
        let aiWidth     :CGFloat = self.convert2Pixels(130)
        let aiHeight    :CGFloat = self.convert2Pixels(18)
        
        
        vwMain              = UIView(frame:CGRectMake(0, 0, cgScreenWidth, cgScreenHeight))
        vwHeader            = UIView(frame:CGRectMake(0, 0, cgScreenWidth, hdrVwHeight))
        btnXheader          = UIButton(frame:CGRectMake(0, hdrY, 33, 33))
        lblHeader           = UILabel(frame:CGRectMake(hdrX, hdrY, hdrWidth, hdrHeight))
        btnRtHeader         = UIButton(frame:CGRectMake(hdRtX , hdRTY, hdRtWidth, hdRtHeight))
        
        vwDisplayPic        = UIView(frame:CGRectMake(0, hdrVwHeight, cgScreenWidth, vwDHeight))
        //vwGreyBand          = UIView(frame:CGRectMake(0, hdrVwHeight+vwDHeight, cgScreenWidth, bandWidth))
        
        imgProfilePic       = UIImageView(frame:CGRectMake(profX, 30, 110, 110))
        lblShopper          = UILabel(frame:CGRectMake(0, hdrHeight+110, cgScreenWidth, hdrHeight))
        lblAgent            = UILabel(frame:CGRectMake(0, hdrHeight+hdrHeight+105, cgScreenWidth, hdrHeight))
        
        segOperations       = UISegmentedControl(items: segMenuItems)
        segOperations.frame = CGRectMake(segX, segY	, segWidth, segHeight)
        
        vwContactInfo       = UIView(frame:CGRectMake(0, conY, cgScreenWidth, conHeight))
        lblContact1         = UILabel(frame:CGRectMake(ci1X, ci1Y, ciWidth, ciHeight))
        lblEditContact      = UILabel(frame:CGRectMake(ci1X, ci1Y+ciHeight, ciWidth+50, ciHeight))
        imgEdit             = UIImageView(frame:CGRectMake(cgScreenWidth-45, 30, 30, 30))
        btnEditContact      = UIButton(type: UIButtonType.Custom)
        btnEditContact.frame    = imgEdit.frame
        
        lblContactInfoHdr   = UILabel(frame:CGRectMake(ci1X, ci1Y+ciHeight+25, ciWidth, ciHeight))
        lblContactData      = UILabel(frame:CGRectMake(ci1X, ci1Y+ciHeight+ciHeight+14, cgScreenWidth-ci1X, 75))
        lblContactData.numberOfLines = 0

        
        vwAdditionalInfo    = UIView(frame:CGRectMake(0, addY, cgScreenWidth, addHeight))
        lblAddition         = UILabel(frame:CGRectMake(ai1X, ai1Y, aiWidth, aiHeight))
        lblEditAddition     = UILabel(frame:CGRectMake(ci1X, ci1Y+ciHeight, aiWidth+50, aiHeight))
        
        imgAdditionalEdit             = UIImageView(frame:CGRectMake(cgScreenWidth-45, 30, 30, 30))
        btnEditAdditionalInfo      = UIButton(type: UIButtonType.Custom)
        btnEditAdditionalInfo.frame    = imgAdditionalEdit.frame
        
        lblAdditionAddrInfoHdr   = UILabel(frame:CGRectMake(ai1X, ai1Y+ciHeight+25, aiWidth, aiHeight))
        lblAdditionAddrData      = UILabel(frame:CGRectMake(ai1X, ai1Y+aiHeight+aiHeight+14, cgScreenWidth-ai1X, 50))
        lblAdditionAddrData.numberOfLines = 0
        
        
        lblAdditionInterestInfoHdr   = UILabel(frame:CGRectMake(ai1X, ai1Y+ciHeight+90, aiWidth, aiHeight))
        lblAdditionInterestData      = UILabel(frame:CGRectMake(ai1X, ai1Y+aiHeight+aiHeight+74, cgScreenWidth-ai1X,50))
        lblAdditionInterestData.numberOfLines = 0
        
        
        
    }
    
    
    func setProperties(){
        
        vwMain.backgroundColor          = UIColor(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
        
        //setup header
        vwHeader.backgroundColor        = UIColor(red: 217/255, green: 2/255, blue: 9/255, alpha: 1)
        let imgBtnImage     :UIImage    = UIImage(named:"btnSave3.png")!
        btnXheader.setImage(imgBtnImage, forState: .Normal)
        btnXheader.addTarget(self, action: Selector("back"), forControlEvents: UIControlEvents.TouchUpInside)
        
        let image           :UIImage = UIImageCustom().getImageFromString("settings.png")!
        btnRtHeader.setImage(image, forState: .Normal)
        btnRtHeader.backgroundColor = UIColor.clearColor()
        
        lblHeader.text              = "My Profile"
        let headerFont      :UIFont = UIFont(name: "MuseoSansRounded-300", size: 18.0)!
        lblHeader.font              = headerFont
        lblHeader.textColor         = UIColor.whiteColor()
        
        vwDisplayPic.backgroundColor = UIColor.whiteColor()
        let pImage          :UIImage = UIImage(named:"profile.png")!
        imgProfilePic.image          = pImage
        imgProfilePic.image?.circleMask
        
        lblShopper.textColor          = UIColor.blackColor()
        lblShopper.textAlignment      = NSTextAlignment.Center
        let shopperFont      :UIFont  = UIFont(name: "MuseoSansRounded-300", size: 17.0)!
        lblShopper.font               = shopperFont
        lblAgent.textColor          = UIColor.blackColor()
        lblAgent.textAlignment      = NSTextAlignment.Center
        let agentFont      :UIFont  = UIFont(name: "MuseoSansRounded-300", size: 12.0)!
        lblAgent.font               = agentFont
        
        //setup segmented menu
        segOperations.selectedSegmentIndex  = 0
        segOperations.tintColor             = UIColor(red: 217/255, green: 2/255, blue: 9/255, alpha: 1)
        segOperations.backgroundColor       = UIColor.whiteColor()
        
        vwContactInfo.backgroundColor       = UIColor.whiteColor()
        lblContact1.textColor               = UIColor.blackColor()
        lblContact1.text                    = "CONTACT INFO"
        let c1Font                  :UIFont = UIFont(name: "MuseoSansRounded-300", size: 15.0)!
        lblContact1.font                    = c1Font
        lblEditContact.textColor            = UIColor.blackColor()
        lblEditContact.text                 = "Edit contact information"
        lblContactData.textColor            = UIColor.blackColor()
        let c2Font                  :UIFont = UIFont(name: "MuseoSansRounded-300", size: 11.0)!
        lblEditContact.font                 = c2Font
        lblContactInfoHdr.text              = "CONTACT INFO"
        lblContactInfoHdr.font              = c2Font
        let editImage           :UIImage = UIImageCustom().getImageFromString("edit@3x.png")!
        imgEdit.image                       = editImage
        
        btnEditContact.addTarget(self, action: Selector("loadEditProfile"), forControlEvents: UIControlEvents.TouchUpInside)

        
        vwAdditionalInfo.backgroundColor    = UIColor.whiteColor()
        lblAddition.textColor               = UIColor.blackColor()
        lblAddition.text                    = "ADDITIONAL INFO"
        let a1Font                  :UIFont = UIFont(name: "MuseoSansRounded-300", size: 15.0)!
        lblAddition.font                    = a1Font
        lblEditAddition.textColor            = UIColor.blackColor()
        lblEditAddition.text                 = "Edit address and interest"
        let a2Font                  :UIFont = UIFont(name: "MuseoSansRounded-300", size: 11.0)!
        lblEditAddition.font                 = a2Font
        
        imgAdditionalEdit.image                 = editImage
        btnEditAdditionalInfo.addTarget(self, action: Selector("loadAdditionalInfoView"), forControlEvents: UIControlEvents.TouchUpInside)

        lblAdditionAddrInfoHdr.text             = "ADDRESS"
        lblAdditionAddrInfoHdr.font             = a2Font
        lblAdditionAddrData.textColor         = UIColor.blackColor()

        lblAdditionInterestInfoHdr.text          = "I'M INTERESTED IN"
        lblAdditionInterestInfoHdr.font          = a2Font
        lblAdditionInterestData.textColor      = UIColor.blackColor()
        
        
        
        
        
    }
    
    
    func setProfileData(){
        lblShopper.text  = profileModel.shopperFirstName + " " + profileModel.shopperLastName
        lblAgent.text    = "Agent: " + profileModel.agentName
        lblContactData.text = profileModel.contactEmail
        lblAdditionAddrData.text = profileModel.addr1 + " " + profileModel.addr2 + " " + profileModel.addrCity + "" + profileModel.addrState + "" + profileModel.zipCode
        lblAdditionInterestData.text = profileModel.interest

    }
    
    func addElements2UI(){
        
        vwController.view.addSubview(vwMain)
        vwMain.addSubview(vwHeader)
        vwMain.addSubview(vwDisplayPic)
        //vwMain.addSubview(vwGreyBand)
        vwMain.addSubview(segOperations)
        vwMain.addSubview(vwContactInfo)
        vwMain.addSubview(vwAdditionalInfo)
        
        vwDisplayPic.addSubview(imgProfilePic)
        vwDisplayPic.addSubview(lblShopper)
        vwDisplayPic.addSubview(lblAgent)
        vwHeader.addSubview(btnXheader)
        vwHeader.addSubview(lblHeader)
        vwHeader.addSubview(btnRtHeader)
        vwContactInfo.addSubview(lblContact1)
        vwContactInfo.addSubview(lblEditContact)
        vwContactInfo.addSubview(imgEdit)
        vwContactInfo.addSubview(btnEditContact)
        vwContactInfo.addSubview(lblContactInfoHdr)
        vwContactInfo.addSubview(lblContactData)
        
        vwAdditionalInfo.addSubview(lblAddition)
        vwAdditionalInfo.addSubview(lblEditAddition)
        vwAdditionalInfo.addSubview(imgAdditionalEdit)
        vwAdditionalInfo.addSubview(btnEditAdditionalInfo)
        vwAdditionalInfo.addSubview(lblAdditionAddrInfoHdr)
        vwAdditionalInfo.addSubview(lblAdditionAddrData)
        vwAdditionalInfo.addSubview(lblAdditionInterestInfoHdr)
        vwAdditionalInfo.addSubview(lblAdditionInterestData)


        
    }
    
    func back(){
        
        vwController.dismissViewControllerAnimated(true, completion: nil)
    }
    func loadEditProfile(){
        print("Load Edit Profile")
        let editProfileController : EditProfileViewController = EditProfileViewController()
        editProfileController.profileModel = self.profileModel
        vwController.navigationController?.pushViewController(editProfileController, animated: true)

    }
    
    func loadAdditionalInfoView(){
        print("Load Additional Info")
        let editAdditionalInfo : EditAdditionalViewController = EditAdditionalViewController()
        vwController.navigationController?.pushViewController(editAdditionalInfo, animated: true)
        
    }
    
    
}

extension UIImage {
    var circleMask: UIImage {
        let square = CGSize(width: 150, height: 150)
        let imageView = UIImageView(frame: CGRect(origin: CGPoint(x: 0, y: 0), size: square))
        imageView.contentMode = UIViewContentMode.ScaleAspectFill
        imageView.image = self
        imageView.layer.cornerRadius = square.width/2
        imageView.layer.borderColor = UIColor.redColor().CGColor
        imageView.layer.borderWidth = 1
        imageView.layer.masksToBounds = true
        UIGraphicsBeginImageContext(imageView.bounds.size)
        imageView.layer.renderInContext(UIGraphicsGetCurrentContext()!)
        let result = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return result
    }
}

