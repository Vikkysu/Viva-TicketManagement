//
//  TaxHistoryRecords.swift
//  XomeRestClient
//
//  Created by Xome on 2/4/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class TaxHistoryRecords: Mappable {
    
    public var taxYear: Double?
    public var taxValue: String?
    public var taxValueDouble: Double?
    public var taxAssessment: String?
    public var taxAssessmentDouble: Double?
    public var taxValueChange: String?
    public var taxAssessmentChange: String?
    
    required public init?(_ map: Map) {
        
    }
    
    public func mapping(map: Map) {
        
        taxYear <- map["taxYear"]
        taxValue <- map["taxValue"]
        taxValueDouble <- map["taxValueDouble"]
        taxAssessment <- map["taxAssessment"]
        taxAssessmentDouble <- map["taxAssessmentDouble"]
        taxValueChange <- map["taxValueChange"]
        taxAssessmentChange <- map["taxAssessmentChange"]
    }
}