//
//  OnboardTmpVC.swift
//  XomeProOnboard
//
//  Created by Vikas on 10/16/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import UIKit

class OnboardTmpVC:UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.orangeColor()
        
    }
}
