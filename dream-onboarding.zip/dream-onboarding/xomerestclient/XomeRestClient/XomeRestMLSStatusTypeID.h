//
//  XomeRestMLSStatusTypeID.h
//  Xome
//
//  Created by Vikas on 8/4/15.
//  Copyright (c) 2015 Xome. All rights reserved.
//

typedef NS_ENUM(NSUInteger, XomeRestMLSStatusTypeID) {
    XomeRestMLSStatusTypeID_LISTING_TRANSFER = 0,
    XomeRestMLSStatusTypeID_ACTIVE = 1,
    XomeRestMLSStatusTypeID_CLOSED = 2,
    XomeRestMLSStatusTypeID_EXPIXomeRest = 3,
    XomeRestMLSStatusTypeID_OFF_MARKET = 4,
    XomeRestMLSStatusTypeID_PENDING = 5,
    XomeRestMLSStatusTypeID_CONTINGENT = 6,
    XomeRestMLSStatusTypeID_FELL_THROUGH = 7,
    XomeRestMLSStatusTypeID_ZAPPED = 8,
    XomeRestMLSStatusTypeID_RENTED = 9,
    XomeRestMLSStatusTypeID_ACTIVECONTINGENT = 10,
    XomeRestMLSStatusTypeID_BACKUP_OFFERS = 11,
};
