//
//  EditProfileModel.swift
//  ProfessionalTools
//
//  Created by MACMINI4 on 23/10/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class EditProfileModel: NSObject {
    
    typealias Callback = (EditProfileModel) -> ()
    
    var shopperFirstName:String!
    var shopperLastName:String!
    var contactEmail:String!
    var contactPhone:String!
    
    func fillProfile(profileModel: ProfileModel, cb: Callback) {
        let editProfileModel = EditProfileModel()
        editProfileModel.shopperFirstName = profileModel.shopperFirstName
        editProfileModel.shopperLastName = profileModel.shopperLastName
        editProfileModel.contactEmail = profileModel.contactEmail
        editProfileModel.contactPhone = profileModel.contactPhone
        cb(editProfileModel)
    }
}