//
//  SwiftExtensionTests.swift
//  XomeRestClient
//
//  Created by Vikas on 12/2/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import XCTest
import Typhoon
@testable import XomeRestClient

class SwiftExtensionTests : XCTestCase {
    // MARK: - Mocks/Fakes/Stubs
    internal class StubOperation : NSObject, XomeRestOperation {
        func handleSuccess(handler: XomeRestOperationSuccessHandler) -> Self {
            return self
        }
        func handleError(handler: XomeRestOperationErrorHandler) -> Self {
            return self
        }
        func finally(handler: XomeRestOperationFinallyHandler) -> Self {
            return self
        }
        func callbackOnMainThread() -> Self {
            return self
        }
        func start() {
            
        }
        func fail(error: NSError) {
            
        }
    }

    internal class StubOperationFactory : NSObject, XomeRestOperationFactory {
        func operation(operation: String, resourcePath: String, queryParameters: [NSObject : AnyObject], postData data: NSData) -> XomeRestOperation! {
            return StubOperation()
        }

        func operation(operation: String, host: String, resourcePath: String, queryParameters: [NSObject : AnyObject], postData data: NSData) -> XomeRestOperation! {
            return StubOperation()
        }
        func operation(operation: String, host: String, resourcePath: String, queryParameters: [NSObject : AnyObject], postData data: NSData, mutateRequestHandler handler: XomeRestOperationFactoryFinalRequestMutationHandler) -> XomeRestOperation! {
            return StubOperation()
        }
    }

    // MARK: - Tests

    var operationFactory : XomeRestOperationFactory!

    override func setUp() {
        super.setUp()
        let assembly = XomeRestClientAssembly().activate()
        let patcher = TyphoonPatcher()
        patcher.patchDefinitionWithSelector("operationFactory") { () -> AnyObject! in
            return StubOperationFactory()
        }
        assembly.attachDefinitionPostProcessor(patcher)

        self.operationFactory = assembly.operationFactory() as! XomeRestOperationFactory
    }

    func test_extension_compile_syntax_get_method_default_arguments() {
        let operation = operationFactory.get(path: "foo", queryParameters: [ "key": "value"])

        operation.handleSuccess { (data: NSData!) in
        }
        operation.handleError { (error: NSError!) in
        }
        operation.start()
    }

    func test_extension_compile_syntax_get_method_with_extra_headers() {
        let operation = operationFactory.get(path: "foo/path/baz", queryParameters: ["key": "value"]) { (request: NSMutableURLRequest!) in
            request.addValue("this is some token info", forHTTPHeaderField: "x-dream-auth-token")
        }

        operation.handleSuccess { (data: NSData!) in
        }
        operation.handleError { (error: NSError!) in
        }
        operation.start()
    }

    func test_extension_compile_syntax_post_method_default_arguments() {
        let someData = NSData()
        let operation = operationFactory.post(path: "foo", queryParameters: [ "key": "value"], postData: someData)

        operation.handleSuccess { (data: NSData!) in
        }
        operation.handleError { (error: NSError!) in
        }
        operation.start()
    }

    func test_extension_compile_syntax_post_method_with_extra_headers() {
        let someData = NSData()
        let operation = operationFactory.post(path: "foo/path/baz", queryParameters: ["key": "value"], postData: someData) { (request: NSMutableURLRequest!) in
            request.addValue("this is some token info", forHTTPHeaderField: "x-dream-auth-token")
        }

        operation.handleSuccess { (data: NSData!) in
        }
        operation.handleError { (error: NSError!) in
        }
        operation.start()
    }

    func test_extension_compile_syntax_method_chaining() {
        let someData = NSData()
        let operation = operationFactory.post(path: "foo/path/baz", queryParameters: ["key": "value"], postData: someData) { (request: NSMutableURLRequest!) in
            request.addValue("this is some token info", forHTTPHeaderField: "x-dream-auth-token")
        }

        operation.handleSuccess { (data: NSData!) in

        }.handleError { (error: NSError!) in
        }
        operation.start()
    }



}