//
//  XomeService.swift
//  XomeRestClient
//
//  Created by Brendan Farrington on 12/2/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import ObjectMapper
import PromiseKit

@objc
public class XomeService: NSObject {
    var operationFactory: XomeRestOperationFactory!
    var imageService: ImageService!
    var environment: XomeRestClientServiceEnvironment!
    var mapLayerData: MapLayerData!

    private var cachedServiceDetailsTime: NSDate?
    private var cachedServiceDetails: ServiceDetailsModel?
    private static let SERVICE_DETAILS_CACHE_TIME: NSTimeInterval = 60 * 5
    public func serviceDetails() -> Promise<ServiceDetailsModel> {
        var getNewData: Bool = cachedServiceDetails == nil
        if let cacheTime = cachedServiceDetailsTime where NSDate().timeIntervalSinceDate(cacheTime) > XomeService.SERVICE_DETAILS_CACHE_TIME {
            getNewData = true
        }
        let path = environment.webURL()!.URLByAppendingPathComponent("mobile/v3/account/data.aspx").absoluteString
        return !getNewData ? Promise(cachedServiceDetails!) : operationFactory.promise(.GET, path: path,
            queryParameters: ["op": "brand", "bypass": "1"],
            bodyData: nil
        ).then { (details: ServiceDetailsModel) -> ServiceDetailsModel in
            self.cachedServiceDetails = details
            self.cachedServiceDetailsTime = NSDate()
            return details
        }
    }
}