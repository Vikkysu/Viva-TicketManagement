//
//  DreamOnboardAssembly.swift
//  XomeProOnboard
//
//  Created by Vikas on 10/16/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import XomeAssembly

public class DreamOnboardingAssembly : TyphoonAssembly,XomeAssemblyInitialComponent {
    dynamic func dreamOnboardIntroToAppViewController() -> AnyObject {
            return TyphoonDefinition.withClass(DPSignInViewController.self,configuration:{(definition:TyphoonDefinition!) in
        })
    }
    
    dynamic func dreamOnboardRouteConfig() -> AnyObject {
        return TyphoonDefinition.withClass(DreamOnboardingRouteConfig.self,configuration:{(definition: TyphoonDefinition!) in
        })
    }
}
