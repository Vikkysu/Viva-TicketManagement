//
//  POITypeResultsModel.swift
//  XomeRestClient
//
//  Created by Thomas De Leon on 3/2/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class POITypeResultsModel: Mappable {
    
    private struct Keys {
        private static let POI = "poi"
    }
    
    public var items = [POIModel]()
    
    private let transformPOIType = TransformOf<POIType, String>(fromJSON: {
        let typeInt = Int($0!) ?? 0
        return POIType(rawValue: typeInt)
        }, toJSON: {
            $0.map{ String($0.rawValue)}
    })
    
    required public init?(_ map: Map) {

    }
    
    public func mapping(map: Map) {
        items <- map[Keys.POI]
    }
}
