//
//  PropertySearchFilter.swift
//  XomeRestClient
//
//  Created by David Parton on 1/29/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper
import XomeFoundation

public class PropertySearchFilter: Mappable {
    public var status: String
    public var listingType: String?
    public var minBeds: Int?
    public var minBaths: Int?
    public var minPrice: Int?
    public var maxPrice: Int?
    public var residentialType: String?
    public var minSquareFootage: Int?
    public var minAcreage: Int?
    public var maxAcreage: Int?
    public var minYearBuilt: Int?
    public var maxYearBuilt: Int?
    public var daysOnMarket: Int?
    public var openHouseInDays: Int?

    public init(other: PropertySearchFilter) {
        status = other.status
        listingType = other.listingType
        minBeds = other.minBeds
        minBaths = other.minBaths
        minPrice = other.minPrice
        maxPrice = other.maxPrice
        residentialType = other.residentialType
        minSquareFootage = other.minSquareFootage
        minAcreage = other.minAcreage
        maxAcreage = other.maxAcreage
        minYearBuilt = other.minYearBuilt
        maxYearBuilt = other.maxYearBuilt
        daysOnMarket = other.daysOnMarket
        openHouseInDays = other.openHouseInDays
    }

    public init(status: String,
        listingType: String?,
        minBeds: Int?,
        minBaths: Int?,
        minPrice: Int?,
        maxPrice: Int?,
        residentialType: String?,
        minSquareFootage: Int?,
        minAcreage: Int?,
        maxAcreage: Int?,
        minYearBuilt: Int?,
        maxYearBuilt: Int?,
        daysOnMarket: Int?,
        openHouseInDays: Int?)
    {
        self.status = status
        self.listingType = listingType
        self.minBeds = minBeds
        self.minBaths = minBaths
        self.minPrice = minPrice
        self.maxPrice = maxPrice
        self.residentialType = residentialType
        self.minSquareFootage = minSquareFootage
        self.minAcreage = minAcreage
        self.maxAcreage = maxAcreage
        self.minYearBuilt = minYearBuilt
        self.maxYearBuilt = maxYearBuilt
        self.daysOnMarket = daysOnMarket
        self.openHouseInDays = openHouseInDays
    }

    public required init?(_ map: Map) {
        status = map["status"].valueOrFail()
        if !map.isValid { return nil }
    }

    public func mapping(map: Map) {
        let zeroNilTransform = TransformOf<Int, Int>(fromJSON: { $0 ~~ 0 ? nil : $0 },
                                                       toJSON: { $0 ~~ 0 ? nil : $0 })
        status <- map["status"]
        minBeds <- (map["minBedrooms"], zeroNilTransform)
        minBaths <- (map["minBaths"], zeroNilTransform)
        minPrice <- map["minPrice"]
        maxPrice <- map["maxPrice"]
        listingType <- map["listingTypeId"]
        residentialType <- map["propertyTypeIds"]
        minSquareFootage <- map["minSquareFootage"]
        minAcreage <- (map["minAcreage"], zeroNilTransform)
        maxAcreage <- (map["maxAcreage"], zeroNilTransform)
        minYearBuilt <- (map["minYearBuilt"], zeroNilTransform)
        maxYearBuilt <- (map["maxYearBuilt"], zeroNilTransform)
        daysOnMarket <- (map["cumulativeDaysOnMarket"], zeroNilTransform)
        openHouseInDays <- (map["openHouseNextXDays"], zeroNilTransform)
    }
}

