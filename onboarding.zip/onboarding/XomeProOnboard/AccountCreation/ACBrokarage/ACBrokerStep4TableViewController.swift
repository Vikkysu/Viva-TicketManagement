//
//  ACBrokerStep4TableViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/4/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class ACBrokerStep4TableViewController: UITableViewController, UITextFieldDelegate {
    var brokerMLSArr: NSMutableArray = NSMutableArray()
    var addPressed: Int = 0
    var totalcount: Int = 0
    
    func setDataFields() -> Bool
    {
        var isValidated: Bool = false
        
        isValidated = addBrokerMLSInfo()
        
        //TODO: Need to refactor to obtimize the code
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            let brokerOnboardingInfo: DPAgentOnBoardingModel = DPAgentOnBoardingModel.sharedInstance
            
            let brokerMLSInfo: DPBrokerMLSInfo = DPBrokerMLSInfo()
            brokerMLSInfo.brokerMLSInfoArr = brokerMLSArr
            if isValidated == true {
                brokerOnboardingInfo.brokerMLSModelObj(brokerMLSInfo)
                brokerOnboardingInfo.saveBrokerMLSCustomObject(brokerMLSInfo)
            }
        }
        else
        {
            let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
            
            let parentViewC : ACBrokarageStep4ViewController =  self.parentViewController as! ACBrokarageStep4ViewController
            let eState: flowState = parentViewC.geteState()
            
            if (eState == flowState.BROKERAGE) {
                let brokerMLSInfo: DPBrokerageMLSInfo = DPBrokerageMLSInfo()
                brokerMLSInfo.brokerMLSInfoArr = brokerMLSArr
                
                
                if isValidated == true {
                    brokerOnboardingInfo.brokerageMLSModelObj(brokerMLSInfo)
                    brokerOnboardingInfo.saveBrokerageMLSCustomObject(brokerMLSInfo)
                }
            }
            else {
                let brokerMLSInfo: DPBrokerMLSInfo = DPBrokerMLSInfo()
                brokerMLSInfo.brokerMLSInfoArr = brokerMLSArr
                
                
                if isValidated == true {
                    brokerOnboardingInfo.brokerMLSModelObj(brokerMLSInfo)
                    brokerOnboardingInfo.saveBrokerMLSCustomObject(brokerMLSInfo)
                    print("Brokerage mls data saved")
                }
            }
        }
        return isValidated
    }

    
    @IBAction func addBrokerMLSRowInfo(sender: AnyObject) {
        print("add another MLS")
        self.addBrokerMLSInfo()
        addPressed++;
        tableView.reloadData()
    }
    
    func addBrokerMLSInfo()-> Bool {
        var isValidated: Bool = true
        
        if brokerMLSArr.count == 0 {
            let brokerCell: ACBrokerMLSInfoTableViewCell = tableView.cellForRowAtIndexPath(NSIndexPath(forRow: brokerMLSArr.count == 0 ? brokerMLSArr.count+1: brokerMLSArr.count, inSection: 0)) as! ACBrokerMLSInfoTableViewCell
            if(brokerCell.brokerMLSBrokerageIDInfo.text != "" || (brokerCell.brokerMLSNameInfo.text != "")) {
                print("has text")
            }
            else
            {
                let alertView: UIAlertView = UIAlertView(title: "", message: "Please enter atleast one MLS info", delegate: self, cancelButtonTitle: "OK")
                alertView.show()
                isValidated = false
                return isValidated
            }
        }
        
        // remove all elemts in array
        brokerMLSArr.removeAllObjects()
        
        brokerMLSArr = NSMutableArray()
        
        var count: Int = 1
        
        for (count; count < totalcount; count++)
        {
            let brokerCell: ACBrokerMLSInfoTableViewCell = tableView.cellForRowAtIndexPath(NSIndexPath(forRow: count == 0 ? count+1: count, inSection: 0)) as! ACBrokerMLSInfoTableViewCell
            var brokerMLSInfo: String = ""
            if(brokerCell.brokerMLSBrokerageIDInfo.text != "") {
                brokerMLSInfo = brokerCell.brokerMLSBrokerageIDInfo.text!
            }
            var brokerMLSName: String = ""
            if(brokerCell.brokerMLSNameInfo.text != "") {
                brokerMLSName = brokerCell.brokerMLSNameInfo.text!
            }
            brokerCell.editing = true;
            let brokerageMLS: DPBrokerageMLSObj = DPBrokerageMLSObj()
            brokerageMLS.brokerageMLSID = brokerMLSInfo
            brokerageMLS.brokerageMLSName = brokerMLSName
            
            brokerMLSArr.addObject(brokerageMLS)
        }
        return isValidated
    }

    
    override func viewDidLoad() {
        // Do any additional setup after loading the view.
        
        //TODO: Need to refactor to obtimize the code
        // fill the fields if saved offline
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            let brokerOnboardingInfo: DPAgentOnBoardingModel = DPAgentOnBoardingModel.sharedInstance
            let brokerObj: DPBrokerMLSInfo? = brokerOnboardingInfo.loadBrokerMLSCustomObjectWithKey()
            if let brokerModelObj = brokerObj {
                brokerMLSArr = brokerModelObj.brokerMLSInfoArr
            }
        }
        else
        {
            let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
            //brokerOnboardingInfo.removeBrokerageLicenseSavedObj()
            let parentViewC : ACBrokarageStep4ViewController =  self.parentViewController as! ACBrokarageStep4ViewController
            let eState: flowState = parentViewC.geteState()
            if eState == flowState.BROKERAGE {
                let brokerObj: DPBrokerageMLSInfo? = brokerOnboardingInfo.loadBrokerageMLSCustomObjectWithKey()
                if let brokerModelObj = brokerObj {
                    brokerMLSArr = brokerModelObj.brokerMLSInfoArr
                }
            }
            else {
                let brokerObj: DPBrokerMLSInfo? = brokerOnboardingInfo.loadBrokerMLSCustomObjectWithKey()
                if let brokerModelObj = brokerObj {
                    brokerMLSArr = brokerModelObj.brokerMLSInfoArr
                }
            }
        }
        tableView.delegate=self
        tableView.dataSource=self
        tableView.showsHorizontalScrollIndicator=false
        tableView.showsVerticalScrollIndicator=false
        tableView.separatorStyle = .None
        tableView.registerClass(ACBrokerageStep1HeaderCell.self, forCellReuseIdentifier: "reuseIdentifier")
        tableView.registerClass(ACBrokerMLSInfoTableViewCell.self, forCellReuseIdentifier: "brokerMLSInfo")
        
    }
    
    
    // MARK: Tableview delegates
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if brokerMLSArr.count == 0 {
            totalcount = 2
        }
        else {
            totalcount = brokerMLSArr.count+1+addPressed
        }
        return totalcount
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 100
    }
    
    override
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        //headerBrokerInfo
        if(indexPath.row == 0)
        {
            let cell: ACBrokerageStep1HeaderCell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath) as! ACBrokerageStep1HeaderCell
            let label: UILabel? = cell.viewWithTag(34) as? UILabel
            
            label!.text = "Provide Brokerage MLS Memberships."
            
            cell.selectionStyle = .None
            return cell
        }
        
        let cell: ACBrokerMLSInfoTableViewCell = tableView.dequeueReusableCellWithIdentifier("brokerMLSInfo") as! ACBrokerMLSInfoTableViewCell
        cell.selectionStyle = UITableViewCellSelectionStyle.None
        let parentViewC : ACBrokarageStep4ViewController =  self.parentViewController as! ACBrokarageStep4ViewController
        let headerLbl : UILabel = cell.viewWithTag(50) as! UILabel

        if parentViewC.geteState() == flowState.BROKERAGE {
            headerLbl.text = "MLS BROKERAGE ID"
        }
        else {
            headerLbl.text = "MLS USER ID"
        }
        
        let addBtnView : UIButton = cell.viewWithTag(54) as! UIButton
        let textFieldInfo : UITextField? = cell.viewWithTag(51) as? UITextField
        let textFieldState : UITextField? = cell.viewWithTag(53) as? UITextField
        
        textFieldInfo?.delegate=self
        textFieldState?.delegate=self
        
        if(indexPath.row == totalcount-1 && totalcount <= 2 && self.brokerMLSArr.count == 1)
        {
            addBtnView.hidden = false
        }
        else
        {
            if(indexPath.row == totalcount-1)
            {
                //addBtnView.hidden = false
            }
            else
            {
                addBtnView.hidden = true
            }
        }
        addBtnView.addTarget(self, action: "addBrokerMLSRowInfo:", forControlEvents: .TouchUpInside)
        //assing the value
        if brokerMLSArr.count > indexPath.row-1 {
            let brokerDict: DPBrokerageMLSObj = brokerMLSArr[indexPath.row-1] as! DPBrokerageMLSObj
            cell.brokerMLSBrokerageIDInfo.text = brokerDict.brokerageMLSID
            cell.brokerMLSNameInfo.text = brokerDict.brokerageMLSName
        }
        return cell
    }
    
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        if indexPath.row <= 1 {
            return false
        }
        return true
    }
    
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if (editingStyle == UITableViewCellEditingStyle.Delete) {
            // handle delete (by removing the data from your array and updating the tableview)
            if(brokerMLSArr.count > indexPath.row)
            {
                brokerMLSArr.removeObjectAtIndex(indexPath.row)
            }
            addPressed--;
            tableView.reloadData()
        }
    }
    
    //MARK:- custom text field methods
    func endEditingNow() {
        self.view.endEditing(true)
    }
    
    func addKeypadToolBar(textField: UITextField) {
        // Create a button bar for the number pad
        let keyboardDoneButtonView = UIToolbar()
        keyboardDoneButtonView.sizeToFit()
        
        // Setup the buttons to be put in the system.
        let item = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.Plain, target: self, action: Selector("endEditingNow") )
        let toolbarButtons = [item]
        
        //Put the buttons into the ToolBar and display the tool bar
        keyboardDoneButtonView.setItems(toolbarButtons, animated: false)
        textField.inputAccessoryView = keyboardDoneButtonView
    }
    
    //MARK: - text field delegates
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        
            if textField.tag == 51 {
                addKeypadToolBar(textField)
            }
        return true
    }

    func textFieldShouldReturn(textField: UITextField) -> Bool
    {
        if let brokerCell: ACBrokerMLSInfoTableViewCell = tableView.cellForRowAtIndexPath(NSIndexPath(forRow: totalcount == 0 ? totalcount+1: totalcount-1, inSection: 0)) as? ACBrokerMLSInfoTableViewCell {
            if textField == brokerCell.brokerMLSBrokerageIDInfo {
                brokerCell.brokerMLSNameInfo.becomeFirstResponder()
            }
            else
            {
                let addBtnView : UIButton = brokerCell.viewWithTag(54) as! UIButton
                let StringMLSName: String! = brokerCell.brokerMLSNameInfo.text
                if StringMLSName.isEmpty {
                    addBtnView.hidden = true
                }
                else
                {
                    addBtnView.hidden = false
                }
                //self.addMLSInfo()
            }
        }
        textField.resignFirstResponder()
        return true
    }
}
