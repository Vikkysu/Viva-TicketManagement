//
//  MessageModel.swift
//  XomeRestClient
//
//  Created by Brendan Farrington on 2/2/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class MessageModel: Mappable {
    public var message: String = ""

    required public init?(_ map: Map) {

    }

    public func mapping(map: Map) {
        message <- map["message"]
    }
}