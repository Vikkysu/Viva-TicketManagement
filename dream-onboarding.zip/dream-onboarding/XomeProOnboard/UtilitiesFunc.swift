//
//  UtilitiesFunc.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/10/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

var NEXTBUTTON: String = "Next"
var INVITEBUTTON: String = "Invite"

class UtilitiesFunc: NSObject {
    class func isValidEmail(emailStr:String) -> Bool {
        let emailRegEx = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluateWithObject(emailStr)
    }
    
    class func isValidURL(urlStr: String) -> Bool {
        
        let urlRegEx = "(http|https)://((\\w)*|([0-9]*)|([-|_])*)+([\\.|/]((\\w)*|([0-9]*)|([-|_])*))+"
        
        let urlTest = NSPredicate(format:"SELF MATCHES %@", urlRegEx)
        return urlTest.evaluateWithObject(urlStr)
    }
    
    class func convertText(inputText: String) -> NSAttributedString? {
        
        var html = inputText
        
        // Replace newline character by HTML line break
        while let range = html.rangeOfString("\n") {
            html.replaceRange(range, with: "<br />")
        }
        
        let data = html.dataUsingEncoding(NSUnicodeStringEncoding, allowLossyConversion: true)!
        do {
            let attrStr = try NSAttributedString(data: data, options: [NSDocumentTypeDocumentAttribute: NSHTMLTextDocumentType], documentAttributes: nil)
            return attrStr
        } catch {
            print(error)
        }
        
        return nil
    }
    
    class func encodeImageBase64 (image: UIImage) -> NSData {
        let quality:CGFloat = 1.0
        let data: NSData = UIImageJPEGRepresentation(image, quality)!
        return data
    }
}
