//
//  DPManageBrokerObj.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/16/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPManageBrokerObj: NSObject {

}

class DPBrokerProfileObj: NSObject {
    var firstNameStr : String!
    var lastNameStr: String!
    var emailStr: String!
    var phonenoStr: String!
    var profilePhoto: UIImage!
    var password: String?
    
    //save the model for offline usage
    func encodeWithCoder(encoder: NSCoder) {
        encoder.encodeObject(self.firstNameStr, forKey: "firstName")
        encoder.encodeObject(self.lastNameStr, forKey: "lastName")
        encoder.encodeObject(self.emailStr, forKey: "email")
        encoder.encodeObject(self.phonenoStr, forKey: "phoneno")
        encoder.encodeObject(self.profilePhoto, forKey: "image")
        encoder.encodeObject(self.password, forKey: "password")
    }
    
    func initWithCoder(decoder: NSCoder)->AnyObject {
        self.firstNameStr = decoder.decodeObjectForKey("firstName") as? String
        self.lastNameStr = decoder.decodeObjectForKey("lastName") as? String
        self.emailStr = decoder.decodeObjectForKey("email") as? String
        self.phonenoStr = decoder.decodeObjectForKey("phoneno") as? String
        self.profilePhoto = decoder.decodeObjectForKey("image") as? UIImage
        self.password = decoder.decodeObjectForKey("password") as? String
        return self;
    }
}

class DPBrandingWebsiteYoutubeAddrObj: NSObject {
    var websiteAddressStr : String?
    var YoutubeStr: String?
    var isSet: Bool?
    
    //save the model for offline usage
    func encodeWithCoder(encoder: NSCoder) {
        encoder.encodeObject(self.websiteAddressStr, forKey: "webSite")
        encoder.encodeObject(self.YoutubeStr, forKey: "youtube")
        encoder.encodeObject(self.isSet, forKey: "isSet")
    }
    
    func initWithCoder(decoder: NSCoder)->AnyObject {
        self.websiteAddressStr = decoder.decodeObjectForKey("webSite") as? String
        self.YoutubeStr = decoder.decodeObjectForKey("youtube") as? String
        self.isSet = decoder.decodeObjectForKey("isSet") as? Bool
        return self;
    }
}

class DPBrokerLicenseInfo: NSObject {
    var brokerLicenseArr: NSMutableArray!
    //save the model for offline usage
    func encodeWithCoder(encoder: NSCoder) {
        encoder.encodeObject(self.brokerLicenseArr, forKey: "brokerLicenseArr")
    }
    
    func initWithCoder(decoder: NSCoder)->AnyObject {
        self.brokerLicenseArr = decoder.decodeObjectForKey("brokerLicenseArr") as! NSMutableArray
        return self;
    }
}

class DPBrokerMLSInfo: NSObject {
    var brokerMLSInfoArr: NSMutableArray!
    //save the model for offline usage
    func encodeWithCoder(encoder: NSCoder) {
        encoder.encodeObject(self.brokerMLSInfoArr, forKey: "brokerMLSArr")
    }
    
    func initWithCoder(decoder: NSCoder)->AnyObject {
        self.brokerMLSInfoArr = decoder.decodeObjectForKey("brokerMLSArr") as! NSMutableArray
        return self;
    }
}