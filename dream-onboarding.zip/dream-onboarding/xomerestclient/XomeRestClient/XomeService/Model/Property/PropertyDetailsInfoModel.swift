//
//  PropertyDetailsInfoModel.swift
//  XomeRestClient
//
//  Created by Vikas on 1/19/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class PropertyDetailsInfoModel : Mappable {
    public enum Id: String {
        case ListingInfo = "10"
        case RoomInfo = "14"
        case InteriorInfo = "15"
        case ExteriorInfo = "16"
        case SchoolInfo = "11"
        case FinanceInfo = "20"
        case CommunityInfo = "17"
    }

    public var id: Id
    public var name: String
    public var items : [(String, String)] {
        fatalError("This computed property must be implemented by a subclass")
    }

    public var _rawItems: [[String: AnyObject]]

    public required init?(_ map: Map) {
        if let rawValue = map["id"].currentValue as? String,
            let evalue = PropertyDetailsInfoModel.Id(rawValue: rawValue) {
            id = evalue
        } else {
            id = map["id"].valueOrFail()
        }
        name = map["name"].valueOrFail()
        _rawItems = map["items"].valueOrFail()

        guard map.isValid else { return nil }
    }

    public func mapping(map: Map) {
        id <- map["id"]
        name <- map["name"]
        _rawItems <- map["items"]
    }
}

public class PropertyDetailsSimpleInfoModel : PropertyDetailsInfoModel {
    public override var items : [(String, String)] {
        return _rawItems.flatMap { ($0["name"] as? String ?? "", $0["value"] as? String ?? "") }
    }
}
