//
//  DPBrokerageObj.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/2/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrokerageEmailObj: NSObject {
    var emailStr: String!
    var passwordStr : String!
    //save the model for offline usage
    func encodeWithCoder(encoder: NSCoder) {
        encoder.encodeObject(self.emailStr, forKey: "Email")
        encoder.encodeObject(self.passwordStr, forKey: "Pass")
    }
    
    func initWithCoder(decoder: NSCoder)->AnyObject {
        self.emailStr = decoder.decodeObjectForKey("Email") as! String
        self.passwordStr = decoder.decodeObjectForKey("Pass") as! String
        return self;
    }
}

class DPBrokeragePersonalInfoObj: NSObject {
    var brokerageName: String!
    var brokeragePhone: String!
    var brokerageAddress: String!
    var brokerageAddressOpt: String?
    var brokerageCity:String!
    var brokerageState:String!
    var brokerageZipcode:String!
    
    //save the model for offline usage
    func encodeWithCoder(encoder: NSCoder) {
        encoder.encodeObject(self.brokerageName, forKey: "brokerageName")
        encoder.encodeObject(self.brokeragePhone, forKey: "brokeragePhone")
        encoder.encodeObject(self.brokerageAddress, forKey: "brokerageAddress")
        encoder.encodeObject(self.brokerageAddressOpt, forKey: "brokerageAddressOpt")
        encoder.encodeObject(self.brokerageCity, forKey: "brokerageCity")
        encoder.encodeObject(self.brokerageState, forKey: "brokerageState")
        encoder.encodeObject(self.brokerageZipcode, forKey: "brokerageZipcode")
    }
    
    func initWithCoder(decoder: NSCoder)->AnyObject {
        self.brokerageName = decoder.decodeObjectForKey("brokerageName") as! String
        self.brokeragePhone = decoder.decodeObjectForKey("brokeragePhone") as! String
        self.brokerageAddress = decoder.decodeObjectForKey("brokerageAddress") as! String
        self.brokerageAddressOpt = decoder.decodeObjectForKey("brokerageAddressOpt") as? String
        self.brokerageCity = decoder.decodeObjectForKey("brokerageCity") as! String
        self.brokerageState = decoder.decodeObjectForKey("brokerageState") as! String
        self.brokerageZipcode = decoder.decodeObjectForKey("brokerageZipcode") as! String
        return self;
    }
}

class DPBrokerageLicenseObj: NSObject {
    var brokerageLicenseNumber: String?
    var brokerageLicenseState:String!
    func encodeWithCoder(encoder: NSCoder) {
        encoder.encodeObject(self.brokerageLicenseNumber, forKey: "brokerLicenseNum")
        encoder.encodeObject(self.brokerageLicenseState, forKey: "brokerLicenseState")
    }
    
    func initWithCoder(decoder: NSCoder)->AnyObject {
        self.brokerageLicenseNumber = decoder.decodeObjectForKey("brokerLicenseNum") as? String
        self.brokerageLicenseState = decoder.decodeObjectForKey("brokerLicenseState") as! String
        return self;
    }
}

class DPBrokerageLicenseInfo: NSObject {
    var brokerLicenseArr: NSMutableArray!
    //save the model for offline usage
    func encodeWithCoder(encoder: NSCoder) {
        encoder.encodeObject(self.brokerLicenseArr, forKey: "brokerLicenseArr")
    }
    
    func initWithCoder(decoder: NSCoder)->AnyObject {
        self.brokerLicenseArr = decoder.decodeObjectForKey("brokerLicenseArr") as! NSMutableArray
        return self;
    }
}

class DPBrokerageMLSObj: NSObject {
    var brokerageMLSID: String!
    var brokerageMLSName: String!
    func encodeWithCoder(encoder: NSCoder) {
        encoder.encodeObject(self.brokerageMLSID, forKey: "brokerMLSID")
        encoder.encodeObject(self.brokerageMLSName, forKey: "brokerMLSName")
    }
    
    func initWithCoder(decoder: NSCoder)->AnyObject {
        self.brokerageMLSID = decoder.decodeObjectForKey("brokerMLSID") as! String
        self.brokerageMLSName = decoder.decodeObjectForKey("brokerMLSName") as! String
        return self;
    }
}

class DPBrokerageMLSInfo: NSObject {
    var brokerMLSInfoArr: NSMutableArray!
    //save the model for offline usage
    func encodeWithCoder(encoder: NSCoder) {
        encoder.encodeObject(self.brokerMLSInfoArr, forKey: "brokerMLSArr")
    }
    
    func initWithCoder(decoder: NSCoder)->AnyObject {
        self.brokerMLSInfoArr = decoder.decodeObjectForKey("brokerMLSArr") as! NSMutableArray
        return self;
    }
}