//
//  XomeRestModel.h
//  Xome
//
//  Created by David Parton on 6/23/15.
//  Copyright (c) 2015 Xome. All rights reserved.
//

@import JSONModel;

@interface XomeRestModel : JSONModel

+ (NSString*)fieldNamesSeparatedByComma;
+ (NSArray*)arrayOfFieldNames;

@end
