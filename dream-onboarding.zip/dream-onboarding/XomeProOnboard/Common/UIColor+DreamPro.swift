//
//  UIColor+DreamPro.swift
//
//  Xome 10/10/15.
//  Copyright (c) 2015 Xome. All rights reserved.
//

import UIKit

extension UIColor {
    class func baoGunmetalColor() -> UIColor {
        return UIColor(red: 64.0 / 255.0, green: 74.0 / 255.0, blue: 89.0 / 255.0, alpha: 1.0)
    }
    
    class func baoHeaderRedColor() -> UIColor {
        return UIColor(red: 217 / 255.0, green: 4 / 255.0, blue: 10 / 255.0, alpha: 1.0)
    }

    class func baoWhite55Color() -> UIColor {
        return UIColor(white: 255.0 / 255.0, alpha: 0.55)
    }

    class func baoWhiteColor() -> UIColor {
        return UIColor(white: 255.0 / 255.0, alpha: 1.0)
    }

    class func baoDustyOrangeColor() -> UIColor {
        return UIColor(red: 241.0 / 255.0, green: 93.0 / 255.0, blue: 63.0 / 255.0, alpha: 1.0)
    }

    class func baoTwilightBlue20Color() -> UIColor {
        return UIColor(red: 13.0 / 255.0, green: 58.0 / 255.0, blue: 85.0 / 255.0, alpha: 0.2)
    }

    class func baoDarkLimeGreenColor() -> UIColor {
        return UIColor(red: 102.0 / 255.0, green: 204.0 / 255.0, blue: 0.0, alpha: 1.0)
    }
    
    class func baoTableBorderColor() -> UIColor {
        return UIColor(red: 230.0/255.0, green: 230.0/255.0, blue: 230.0/255.0, alpha: 1.0)
    }
    
    class func baoArrowColor() -> UIColor {
        return UIColor(red: 204.0/255.0, green: 204.0/255.0, blue: 204.0/255.0, alpha: 1.0)
    }
    
    class func baoInvitedAgentNaviColor() -> UIColor {
        return UIColor(red: 217.0/255.0, green: 4.0/255.0, blue: 10.0/255.0, alpha: 1.0)
    }
    
    class func baoPrimaryColor() -> UIColor {
        let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
        var colorSel : UIColor = UIColor.baoDustyOrangeColor()
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            colorSel = UIColor.baoInvitedAgentNaviColor()
        }
        if let brokerColorInfoObj: DPBrandingColorObj = brokerOnboardingInfo.loadBrokerageBrandingColorObjectWithKey() {
            if brokerColorInfoObj.isSet == true {
                colorSel = UIColor(rgba: brokerColorInfoObj.bioPrimaryColor!)
            }
        }
        return colorSel
    }
    
    class func toHexString(colSel: UIColor) -> String {
        var r:CGFloat = 0
        var g:CGFloat = 0
        var b:CGFloat = 0
        var a:CGFloat = 0
        
        colSel.getRed(&r, green: &g, blue: &b, alpha: &a)
        
        let rgb:Int = (Int)(r*255)<<16 | (Int)(g*255)<<8 | (Int)(b*255)<<0
        
        return String(format:"#%06x", rgb)
        
    }
}



