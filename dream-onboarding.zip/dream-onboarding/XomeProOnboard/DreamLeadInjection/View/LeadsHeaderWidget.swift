//
//  LeadsHeaderWidget.swift
//  ProfessionalTools
//
//  Created by Developer on 22/10/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class LeadsHeaderWidget: UIView {
    
    var btnXheader      :UIButton!
    var lblHeader       :UILabel!
    var lblHeaderRight  :UILabel!
    
    var deviceScrBounds :CGRect!
    var hdrY            :CGFloat!
    var hdrX            :CGFloat!
    var hdrWidth        :CGFloat!
    var hdrHeight       :CGFloat!
    var hdRtX           :CGFloat!
    var hdRTY           :CGFloat!
    var hdRtWidth       :CGFloat!
    var hdRtHeight      :CGFloat!
    var hdrVwHeight     :CGFloat!
    var cgScreenWidth   :CGFloat!
    var cgScreenHeight  :CGFloat!
    
    func loadAndRenderWidget(inBounds:CGRect){
        
        deviceScrBounds = inBounds
        cgScreenWidth   = inBounds.width
        cgScreenHeight  = inBounds.height
        
        self.calculateDimensions()
        self.createElements()
        self.setProperties()
        self.addElements()
    }
    
    func convert2Pixels(points:CGFloat)->CGFloat{
        
        let pixels  :CGFloat = points * 96 / 72
        return pixels
    }
    
    func centreX(inWidth: CGFloat)->CGFloat{
        
        let tWidth:CGFloat  = cgScreenWidth - CGFloat(inWidth)
        let pX: CGFloat     = tWidth/2
        
        return pX
    }
    
    func calculateDimensions(){
        
        hdrWidth        = self.convert2Pixels(60)
        hdrHeight       = self.convert2Pixels(22)
        hdrX            = centreX(hdrWidth)
        hdrY            = self.convert2Pixels(31)
        hdRtWidth       = self.convert2Pixels(44)
        hdRtHeight      = self.convert2Pixels(18)
        hdRtX           = cgScreenWidth - hdRtWidth //constraint set to hdRtWidth
        hdRTY           = self.convert2Pixels(34)
        hdrVwHeight     = self.convert2Pixels(65)
    }
    
    func createElements(){
        
        btnXheader          = UIButton(frame:CGRectMake(0, hdrY, 33, 33))
        lblHeader           = UILabel(frame:CGRectMake(hdrX, hdrY, hdrWidth, hdrHeight))
        lblHeaderRight      = UILabel(frame:CGRectMake(hdRtX, hdRTY, hdRtWidth, hdRtHeight))
    }
    
    func setProperties(){
        self.frame              = CGRectMake(0, 0, cgScreenWidth, hdrVwHeight)
        self.backgroundColor    = UIColor(red: 217/255, green: 2/255, blue: 9/255, alpha: 1)
        lblHeader.textAlignment = .Center
    }
    
    func addElements(){
        
        self.addSubview(btnXheader)
        self.addSubview(lblHeader)
        self.addSubview(lblHeaderRight)
    }
    
}
