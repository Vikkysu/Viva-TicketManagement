//
//  TourModel.swift
//  XomeRestClient
//
//  Created by Brendan Farrington on 2/29/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper


public class TourModel: Mappable {
    public var requestTourId: String?
    public var status: Int?
    public var personId: String?
    public var firstName: String?
    public var lastName: String?
    public var phoneNumber: String?
    public var comments: String?
    public var startDate: NSDate?
    public var endDate: NSDate?
    public var messages: Dictionary<String, AnyObject>?
    public var createDtm: NSDate?
    public var modifyDtm: NSDate?

    public init() {

    }

    required public init?(_ map: Map) {

    }

    public func mapping(map: Map) {
        requestTourId <- map["entity.listingId"]
        status <- map["entity.status"]
        firstName <- map["entity.firstName"]
        lastName <- map["entity.lastName"]
        phoneNumber <- map["entity.phoneNumber"]
        comments <- map["entity.comments"]
        startDate <- map["entity.startDate"]
        messages <- map["entity.messages"]
        let dateTransform = ISO8601DateTransform()
        createDtm <- (map["entity.createDtm"], dateTransform)
        modifyDtm <- (map["entity.modifyDtm"], dateTransform)
    }
}