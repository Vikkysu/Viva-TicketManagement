//
//  XomeRestPropertyDataProvider.m
//  Xome
//
//  Created by Vikas on 8/22/15.
//  Copyright (c) 2015 Xome. All rights reserved.
//

#import "XomeRestClient.h"
#import "XomeRestModel.h"

@implementation XomeRestPropertyDataProvider

- (void)singlePropertyModel:(Class)modelClass listingKey:(NSString *)listingKey handler:(XomeRestPropertyDataProviderHandler)handler {
    if (!handler || ![modelClass isSubclassOfClass:[XomeRestModel class]]) {
        return;
    }

    [self singlePropertyFields:[modelClass fieldNamesSeparatedByComma]
                    listingKey:listingKey
                       handler:^(id objectOrArray, NSError *error) {
                           if (error) {
                               handler(nil, error);
                               return;
                           }

                           NSDictionary* dict = [objectOrArray xome_as:[NSDictionary class]];
                           id result = [[modelClass alloc] initWithDictionary:dict error:&error];
                           handler(result, error);
                       }];
}

- (void)singlePropertyFields:(NSString *)fields listingKey:(NSString *)listingKey handler:(XomeRestPropertyDataProviderHandler)handler {
    if (!handler || !listingKey.length) {
        return;
    }

    id<XomeRestOperation> search = [self.operationFactory operation:@"GET"
                                                  resourcePath:[@"/properties/" stringByAppendingString:listingKey]
                                               queryParameters:fields ? @{ @"fields": fields } : nil
                                                      postData:nil];
    [search handleError:^(NSError *error) {
        handler(nil, error);
    }];
    [search handleSuccess:^(NSData *data) {
        __autoreleasing NSError* error;
        id result = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
        handler(result, error);
    }];
    [search start];
}

- (void)searchPropertiesModel:(Class)modelClass criteria:(NSDictionary *)criteria handler:(XomeRestPropertyDataProviderHandler)handler {
    if (!handler || ![modelClass isSubclassOfClass:[XomeRestModel class]]) {
        return;
    }

    id<XomeRestOperation> search = [self.operationFactory operation:@"POST"
                                                  resourcePath:@"/properties"
                                               queryParameters:@{ @"fields": [modelClass fieldNamesSeparatedByComma],
                                                                  @"pageSize": @(100) }
                                                      postData:criteria.xome_jsonData];
    [search handleError:^(NSError *error) {
        handler(nil, error);
    }];
    [search handleSuccess:^(NSData *data) {
        __autoreleasing NSError* error;
        XomeRestPagedArrayResult* result = [[XomeRestPagedArrayResult alloc] initWithData:data error:&error];
        NSArray* models = [modelClass arrayOfModelsFromDictionaries:result.items];
        handler(models, error);
    }];
    [search start];
}

@end
