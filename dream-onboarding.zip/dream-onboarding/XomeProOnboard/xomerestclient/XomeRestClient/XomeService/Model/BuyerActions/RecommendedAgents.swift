//
//  RecommendedAgents.swift
//  XomeRestClient
//
//  Created by Shivakumar Chandramouli on 2/8/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import UIKit
import ObjectMapper

public class RecommendedAgents: Mappable {

    public var firstName: String?
    public var lastName: String?
    public var mobilePhoneNumber: String?
    public var portraitUrl: String?
    public var primaryEmailAddress: String?
    public var rating: NSNumber?
    public var personId: Double?
    public var videoResume: String?
    public var youTubeVideoId: String?
    public var calculatedSavings: Double?
    public var commissionContributionRatePercent: Double?
    public var brokerageName: String?
    
    public init() {
        
    }
    
    required public init?(_ map: Map) {
        
    }
    
    public func mapping(map: Map) {
        
        firstName <- map["firstName"]
        lastName <- map["lastName"]
        mobilePhoneNumber <- map["mobilePhoneNumber"]
        portraitUrl <- map["portraitUrl"]
        primaryEmailAddress <- map["primaryEmailAddress"]
        rating <- map["rating"]
        youTubeVideoId <- map["youTubeVideoId"]
        calculatedSavings <- map["calcualtedSavings"]
        commissionContributionRatePercent <- map["commissionContributionRatePercent"]
        personId <- map["personID"]
        brokerageName <- map["brokerageName"]
    }
}
