//
//  DPBrandingReviewOptionalTableViewCell.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/13/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrandingReviewOptionalTableViewCell: UITableViewCell {
    
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String!)
    {
        super.init(style: UITableViewCellStyle.Value1, reuseIdentifier: reuseIdentifier)
        var imageCheck : UIImageView
        imageCheck = UIImageView()
        imageCheck.tag = 111
        imageCheck.image = UIImageCustom().getImageFromString("stepCompletion")
        self.addSubview(imageCheck)
        
        var labelSubText : UILabel
        labelSubText = UILabel()
        labelSubText.numberOfLines=0
        labelSubText.textAlignment = .Left
        labelSubText.tag=110
        labelSubText.backgroundColor=UIColor.clearColor()
        labelSubText.font = UIFont(name: MuseoSansRounded300Font, size: 15.0)
        self.addSubview(labelSubText)
        
        //        let expandBtn: UIButton = UIButton()
        //        expandBtn.setTitle("^", forState: .Normal)
        //        expandBtn.setTitleColor(UIColor.baoArrowColor(), forState: .Normal)
        //        expandBtn.tag = 81
        //        self.addSubview(expandBtn)
        
        let separatorLine: UIView = UIView()
        separatorLine.backgroundColor = UIColor.baoTableBorderColor()
        self.addSubview(separatorLine)
        
        imageCheck.snp_makeConstraints { (make) -> Void in
            make.centerY.equalTo(self).offset(0)
            make.leading.equalTo(self).offset(35)
            make.height.equalTo(25)
            make.width.equalTo(25)
        }
        
        labelSubText.snp_makeConstraints { (make) -> Void in
            make.centerY.equalTo(self).offset(0)
            make.leading.equalTo(imageCheck).offset(50)
            make.trailing.equalTo(self).offset(-10)
        }
        
        //        expandBtn.snp_makeConstraints { (make) -> Void in
        //            make.top.equalTo(self).offset(5)
        //            make.trailing.equalTo(self).offset(-20)
        //            make.width.equalTo(9)
        //            make.height.equalTo(16)
        //        }
        
        separatorLine.snp_makeConstraints {(make) -> Void in
            make.bottom.equalTo(self).offset(-1)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
            make.height.equalTo(1)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setSelected(selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
}
