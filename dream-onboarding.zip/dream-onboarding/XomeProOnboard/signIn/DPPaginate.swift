//
//  DPPaginate.swift
//  ProfessionalTools
//
//  Created by Vikas on 9/24/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import UIKit

class DPPaginate:UIPageViewController {
    var subviews:Array<UIView>!
    var pageControl:UIPageControl!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidLayoutSubviews() {
        
    }
    
    
}
