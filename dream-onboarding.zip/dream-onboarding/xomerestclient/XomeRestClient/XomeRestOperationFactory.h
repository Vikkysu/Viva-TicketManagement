//
//  XomeRestOperationFactory.h
//  Xome
//
//  Created by Vikas on 6/26/15.
//  Copyright (c) 2015 Xome. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol XomeRestOperation;

typedef void (^XomeRestOperationFactoryFinalRequestMutationHandler)(NSMutableURLRequest* outgoingRequest);

@protocol XomeRestOperationFactory <NSObject>

- (id<XomeRestOperation>)operation:(NSString*)operation //! HTTP verb (e.g. GET, POST, PUT, HEAD...)
                      resourcePath:(NSString*)resourcePath
                   queryParameters:(NSDictionary*)queryParameters
                          postData:(NSData*)data;

- (id<XomeRestOperation>)operation:(NSString*)operation //! HTTP verb (e.g. GET, POST, PUT, HEAD...)
                              host:(NSString*)host // override the host
                      resourcePath:(NSString*)resourcePath
                   queryParameters:(NSDictionary*)queryParameters
                          postData:(NSData*)data;

- (id<XomeRestOperation>)operation:(NSString*)operation //! HTTP verb (e.g. GET, POST, PUT, HEAD...)
                              host:(NSString*)host // override the host
                      resourcePath:(NSString*)resourcePath
                   queryParameters:(NSDictionary*)queryParameters
                          postData:(NSData*)data
              mutateRequestHandler:(XomeRestOperationFactoryFinalRequestMutationHandler)handler; // supply additional options before scheduling the connection
@end
