//
//  DPReviewInfo.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/20/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit


class DPReviewInfo: NSObject {
    let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
    let agentOnboardingInfo: DPAgentOnBoardingModel = DPAgentOnBoardingModel.sharedInstance

    let subHeaderValueArr: NSArray = ["Brokerage Information" , "Brokerage License and MLS Memberships", "Brokerage Branding (Optional)"]
    let subHeaderBrokerValueArr: NSArray = ["Broker Information" , "Broker License and MLS Memberships", "Broker Branding (Optional)"]
    let subHeaderAgentValueArr: NSArray = ["Agent Information" , "Agent License and MLS Memberships", "Agent Branding (Optional)"]

    //get the values from brokerage model
    func getBrokerageemailInfo() -> String {
         let brokerEmaiInfo: DPBrokerageEmailObj? = brokerOnboardingInfo.loadCustomObjectWithKey()
        
        return brokerEmaiInfo!.emailStr
    }
    
    func getBrokeragePersonalInfo() ->DPBrokeragePersonalInfoObj? {
         let brokerPersonalInfo: DPBrokeragePersonalInfoObj? = brokerOnboardingInfo.loadBrokerageCustomObjectWithKey()
        return brokerPersonalInfo
    }
    
    func getBrokerageLicenseInfo() ->NSMutableArray? {
         let brokerLicenseInfo: DPBrokerageLicenseInfo? = brokerOnboardingInfo.loadBrokerageLicenseCustomObjectWithKey()
        return brokerLicenseInfo?.brokerLicenseArr
    }
    
    func getBrokerageMLSInfo() ->NSMutableArray? {
         let brokerMLSInfo: DPBrokerageMLSInfo? = brokerOnboardingInfo.loadBrokerageMLSCustomObjectWithKey()
        return brokerMLSInfo?.brokerMLSInfoArr
    }
    
    func getBrokerageWebsiteInfo() ->DPBrandingWebsiteAddrObj? {
         let brokerMLSInfo: DPBrandingWebsiteAddrObj? = brokerOnboardingInfo.loadBrokerageBrandingWebsiteObjectWithKey()
        return brokerMLSInfo
    }
    
    func getBrokerageAboutUsInfo() ->DPBrandingBioObj? {
         let brokerMLSInfo: DPBrandingBioObj? = brokerOnboardingInfo.loadBrokerageBrandingBioObjectWithKey()
        return brokerMLSInfo
    }
    
    func constructCellInfo() -> [(value: String, subHeader: String, type: String)]
    {
        var cellInfoArr:[(value: String, subHeader: String, type: String)] = []
        
        for (index, headerStr) in subHeaderValueArr.enumerate() {
            let subInfo = (value: "", subHeader: headerStr  as! String, type: "HEADER")
            cellInfoArr.append(subInfo)
            if(index == 0)
            {
                let type = "BROKER INFORMATION"
                let subInfo = (value: getBrokerageemailInfo(), subHeader: "BROKERAGE EMAIL", type: type)
                let personalInfo: DPBrokeragePersonalInfoObj = getBrokeragePersonalInfo()!
                let subNameInfo = (value: personalInfo.brokerageName as String, subHeader: "BROKERAGE NAME", type: type)
                let subPhoneInfo = (value: personalInfo.brokeragePhone as String, subHeader: "BROKERAGE PHONE NUMBER", type: type)
                
                cellInfoArr.append(subNameInfo)
                cellInfoArr.append(subInfo)
                cellInfoArr.append(subPhoneInfo)
                
            }
            else if (index == 1)
            {
                var type = "BROKER LICENSE INFORMATION"
                
                let licenseInfoArray: NSMutableArray? = getBrokerageLicenseInfo()
                for LicenseInfo in licenseInfoArray! {
                    let lLicenseInfo: DPBrokerageLicenseObj = LicenseInfo as! DPBrokerageLicenseObj
                    let valStr = lLicenseInfo.brokerageLicenseNumber! + "," + lLicenseInfo.brokerageLicenseState
                    let LicenseValInfo = (value: valStr as String, subHeader: "BROKERAGE LICENSE NUMBER", type: type)
                    cellInfoArr.append(LicenseValInfo)
                }
                
                // append the MLS data
                type = "BROKER MLS INFORMATION"
                
                let MLSInfoArray: NSMutableArray? = getBrokerageMLSInfo()
                for MLSInfo in MLSInfoArray! {
                    let lMLSInfo: DPBrokerageMLSObj = MLSInfo as! DPBrokerageMLSObj
                    let valStr = lMLSInfo.brokerageMLSID + "," + lMLSInfo.brokerageMLSName
                    let MLSValInfo = (value: valStr as String, subHeader: "BROKERAGE MLS NUMBER", type: type)
                    cellInfoArr.append(MLSValInfo)
                }
                
            }
            else if (index == 2)
            {
                let type = "BROKER BRANDING"
                //TODO:- Once the logo screen is complete
                
                // append the MLS data
                let webSiteObj: DPBrandingWebsiteAddrObj = getBrokerageWebsiteInfo()!
                
                var webSiteInfoStr: String = "false"
                if webSiteObj.isSet == true {
                    webSiteInfoStr = webSiteObj.websiteAddressStr!
                }
                let LicenseValInfo = (value: webSiteInfoStr, subHeader: "BROKERAGE WEBSITE", type: type)
                cellInfoArr.append(LicenseValInfo)
                
                
                // append the MLS data
                var bioValInfoStr: String = "false"
                if let bioObj: DPBrandingBioObj = getBrokerageAboutUsInfo() {
                    if bioObj.isSet == true {
                        bioValInfoStr = bioObj.bioStr!
                    }
                }
                let bioValInfo = (value: bioValInfoStr, subHeader: "BROKERAGE ABOUT INFORMATION", type: type)
                cellInfoArr.append(bioValInfo)
                
            }
        }
        
        return cellInfoArr
    }
    
    //get the broker information
    func getBrokerPersonalInfo() ->DPBrokerProfileObj? {
         let brokerPersonalInfo: DPBrokerProfileObj? = brokerOnboardingInfo.loadBrokerProfileObjectWithKey()
        return brokerPersonalInfo
    }
    
    func getBrokerLicenseInfo() ->NSMutableArray? {
         let brokerLicenseInfo: DPBrokerLicenseInfo? = brokerOnboardingInfo.loadBrokerLicenseCustomObjectWithKey()
        return brokerLicenseInfo?.brokerLicenseArr
    }
    
    func getBrokerMLSInfo() ->NSMutableArray? {
         let brokerMLSInfo: DPBrokerMLSInfo? = brokerOnboardingInfo.loadBrokerMLSCustomObjectWithKey()
        return brokerMLSInfo?.brokerMLSInfoArr
    }
    
    func getBrokerWebsiteInfo() ->DPBrandingWebsiteYoutubeAddrObj? {
         let brokerMLSInfo: DPBrandingWebsiteYoutubeAddrObj? = brokerOnboardingInfo.loadBrokerageBrandingWebsiteYoutubeObjectWithKey()
        return brokerMLSInfo
    }
    
    func getBrokerAboutUsInfo() ->DPBrandingBioObj? {
         let brokerMLSInfo: DPBrandingBioObj? = brokerOnboardingInfo.loadBrokerBrandingBioObjectWithKey()
        return brokerMLSInfo
    }
    
    func constructBrokerCellInfo() -> [(value: String, subHeader: String, type: String)]
    {
        var cellInfoArr:[(value: String, subHeader: String, type: String)] = []
        
        for (index, headerStr) in subHeaderBrokerValueArr.enumerate() {
            let subInfo = (value: "", subHeader: headerStr  as! String, type: "HEADER")
            cellInfoArr.append(subInfo)
            if(index == 0)
            {
                let type = "BROKER INFORMATION"
                let personalInfo: DPBrokerProfileObj? = getBrokerPersonalInfo()
                let subNameInfo = (value:personalInfo!.firstNameStr + " " + personalInfo!.lastNameStr  as String, subHeader: "BROKER NAME", type: type)
                let subEmailInfo = (value: personalInfo!.emailStr as String, subHeader: "BROKER EMAIL ADDRESS", type: type)
                let subPhoneInfo = (value: personalInfo!.phonenoStr as String, subHeader: "BROKER PHONE NUMBER", type: type)
                
                cellInfoArr.append(subNameInfo)
                cellInfoArr.append(subEmailInfo)
                cellInfoArr.append(subPhoneInfo)
            }
            else if (index == 1)
            {
                var type = "BROKER LICENSE INFORMATION"
                
                let licenseInfoArray: NSMutableArray? = getBrokerLicenseInfo()
                for LicenseInfo in licenseInfoArray! {
                    let lLicenseInfo: DPBrokerageLicenseObj = LicenseInfo as! DPBrokerageLicenseObj
                    let valStr = lLicenseInfo.brokerageLicenseNumber! + "," + lLicenseInfo.brokerageLicenseState
                    let LicenseValInfo = (value: valStr as String, subHeader: "BROKER LICENSE NUMBER", type: type)
                    cellInfoArr.append(LicenseValInfo)
                }
                
                // append the MLS data
                type = "BROKER MLS INFORMATION"
                
                let MLSInfoArray: NSMutableArray? = getBrokerMLSInfo()
                for MLSInfo in MLSInfoArray! {
                    let lMLSInfo: DPBrokerageMLSObj = MLSInfo as! DPBrokerageMLSObj
                    let valStr = lMLSInfo.brokerageMLSID + "," + lMLSInfo.brokerageMLSName
                    let MLSValInfo = (value: valStr as String, subHeader: "BROKER MLS NUMBER", type: type)
                    cellInfoArr.append(MLSValInfo)
                }
                
            }
            else if (index == 2)
            {
                let type = "BROKER BRANDING"
                //TODO:- Once the logo screen is complete
                
                // append the MLS data
                let webSiteObj: DPBrandingWebsiteYoutubeAddrObj = getBrokerWebsiteInfo()!
                
                var webSiteInfoStr: String = "false"
                if webSiteObj.isSet == true {
                    webSiteInfoStr = webSiteObj.websiteAddressStr!
                }
                let LicenseValInfo = (value: webSiteInfoStr, subHeader: "BROKER WEBSITE & VIDEO LINK", type: type)
                cellInfoArr.append(LicenseValInfo)
                
                
                // append the MLS data
                var bioValInfoStr: String = "false"
                
                if let bioObj: DPBrandingBioObj = getBrokerAboutUsInfo() {
                    if bioObj.isSet == true {
                        bioValInfoStr = bioObj.bioStr!
                    }
                }
                let bioValInfo = (value: bioValInfoStr, subHeader: "BROKER ABOUT INFORMATION", type: type)
                cellInfoArr.append(bioValInfo)
            }
        }
        
        return cellInfoArr
    }
    
    //get the agent information
    func getAgentPersonalInfo() ->DPBrokerProfileObj? {
        let brokerPersonalInfo: DPBrokerProfileObj? = agentOnboardingInfo.loadBrokerProfileObjectWithKey()
        return brokerPersonalInfo
    }
    
    func getAgentLicenseInfo() ->NSMutableArray? {
        let brokerLicenseInfo: DPBrokerLicenseInfo? = agentOnboardingInfo.loadBrokerLicenseCustomObjectWithKey()
        return brokerLicenseInfo?.brokerLicenseArr
    }
    
    func getAgentMLSInfo() ->NSMutableArray? {
        let brokerMLSInfo: DPBrokerMLSInfo? = agentOnboardingInfo.loadBrokerMLSCustomObjectWithKey()
        return brokerMLSInfo?.brokerMLSInfoArr
    }
    
    func getAgentWebsiteInfo() ->DPBrandingWebsiteYoutubeAddrObj? {
        let brokerMLSInfo: DPBrandingWebsiteYoutubeAddrObj? = agentOnboardingInfo.loadBrokerageBrandingWebsiteYoutubeObjectWithKey()
        return brokerMLSInfo
    }
    
    func getAgentAboutUsInfo() ->DPBrandingBioObj? {
        let brokerMLSInfo: DPBrandingBioObj? = agentOnboardingInfo.loadBrokerBrandingBioObjectWithKey()
        return brokerMLSInfo
    }


    func constructAgentCellInfo() -> [(value: String, subHeader: String, type: String)]
    {
        var cellInfoArr:[(value: String, subHeader: String, type: String)] = []
        
        for (index, headerStr) in subHeaderAgentValueArr.enumerate() {
            let subInfo = (value: "", subHeader: headerStr  as! String, type: "HEADER")
            cellInfoArr.append(subInfo)
            if(index == 0)
            {
                let type = "BROKER INFORMATION"
                let personalInfo: DPBrokerProfileObj? = getAgentPersonalInfo()
                let subNameInfo = (value: personalInfo!.firstNameStr + " " + personalInfo!.lastNameStr as String, subHeader: "AGENT NAME", type: type)
                let subEmailInfo = (value: personalInfo!.emailStr as String, subHeader: "AGENT EMAIL ADDRESS", type: type)
                let subPhoneInfo = (value: personalInfo!.phonenoStr as String, subHeader: "AGENT PHONE NUMBER", type: type)
                
                cellInfoArr.append(subNameInfo)
                cellInfoArr.append(subEmailInfo)
                cellInfoArr.append(subPhoneInfo)
            }
            else if (index == 1)
            {
                var type = "BROKER LICENSE INFORMATION"
                
                let licenseInfoArray: NSMutableArray? = getAgentLicenseInfo()
                for LicenseInfo in licenseInfoArray! {
                    let lLicenseInfo: DPBrokerageLicenseObj = LicenseInfo as! DPBrokerageLicenseObj
                    let valStr = lLicenseInfo.brokerageLicenseNumber! + "," + lLicenseInfo.brokerageLicenseState
                    let LicenseValInfo = (value: valStr as String, subHeader: "AGENT LICENSE NUMBER", type: type)
                    cellInfoArr.append(LicenseValInfo)
                }
                
                // append the MLS data
                type = "BROKER MLS INFORMATION"
                
                let MLSInfoArray: NSMutableArray? = getAgentMLSInfo()
                for MLSInfo in MLSInfoArray! {
                    let lMLSInfo: DPBrokerageMLSObj = MLSInfo as! DPBrokerageMLSObj
                    let valStr = lMLSInfo.brokerageMLSID + "," + lMLSInfo.brokerageMLSName
                    let MLSValInfo = (value: valStr as String, subHeader: "AGENT MLS NUMBER", type: type)
                    cellInfoArr.append(MLSValInfo)
                }
                
            }
            else if (index == 2)
            {
                let type = "BROKER BRANDING"
                //TODO:- Once the logo screen is complete
                
                // append the MLS data
                let webSiteObj: DPBrandingWebsiteYoutubeAddrObj = getAgentWebsiteInfo()!
                
                var webSiteInfoStr: String = "false"
                if webSiteObj.isSet == true {
                    webSiteInfoStr = webSiteObj.websiteAddressStr!
                }
                let LicenseValInfo = (value: webSiteInfoStr, subHeader: "AGENT WEBSITE & VIDEO LINK", type: type)
                cellInfoArr.append(LicenseValInfo)
                
                
                // append the MLS data
                var bioValInfoStr: String = "false"
                
                if let bioObj: DPBrandingBioObj = getAgentAboutUsInfo() {
                    if bioObj.isSet == true {
                        bioValInfoStr = bioObj.bioStr!
                    }
                }
                let bioValInfo = (value: bioValInfoStr, subHeader: "AGENT ABOUT INFORMATION", type: type)
                cellInfoArr.append(bioValInfo)
            }
        }
        
        return cellInfoArr
    }

}
