//
//  ACBrokerStep1TableViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/1/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class ACBrokerStep1TableViewController: UITableViewController, UITextFieldDelegate {
    
    var emailTextField: UITextField!
    var passwordTextField: UITextField!
    
    func setDataFields() -> Bool
    {
        var isValidated: Bool = false
        let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
        let brokerEmaiInfo: DPBrokerageEmailObj = DPBrokerageEmailObj()

        if emailTextField.text != "" /*&& Global.isValidEmail(emailTextField.text) == true*/ {
            let isEmailValid: Bool = UtilitiesFunc.isValidEmail(emailTextField.text!)
            if(!isEmailValid)
            {
                let alertView = UIAlertView(title: "", message: NSLocalizedString("Please enter valid Email Address", comment:"Please enter valid Email Address"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
                alertView.show()
                return false
            }
            brokerEmaiInfo.emailStr = emailTextField.text
            isValidated = true
        }
        else
        {
            let alertView = UIAlertView(title: "", message: NSLocalizedString("Please enter valid Email Address", comment:"Please enter valid Email Address"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
            alertView.show()
            return false
        }
        
        if passwordTextField.text != "" {
            brokerEmaiInfo.passwordStr = passwordTextField.text
            isValidated = true
        }
        else
        {
            let alertView = UIAlertView(title: "", message: NSLocalizedString("Password field cannot be empty", comment:"Password field cannot be empty"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
            alertView.show()
            return false
        }
        
        if isValidated == true {
            brokerOnboardingInfo.brokerageEmailModelObj(brokerEmaiInfo)
            brokerOnboardingInfo.saveCustomObject(brokerEmaiInfo)
        }
        return isValidated
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        tableView.delegate=self
        tableView.dataSource=self
        tableView.showsHorizontalScrollIndicator=false
        tableView.showsVerticalScrollIndicator=false
        tableView.separatorStyle = .None
        tableView.registerClass(ACBrokerageStep1HeaderCell.self, forCellReuseIdentifier: "reuseIdentifier")
        tableView.registerClass(ACBrokerageTextCell.self, forCellReuseIdentifier: "textHeader")
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //MARK: - text field delegates
    func textFieldShouldReturn(textField: UITextField) -> Bool
    {
        if textField == emailTextField {
            self.emailTextField.resignFirstResponder()
            self.passwordTextField.becomeFirstResponder()
        }
        else {
            self.passwordTextField.resignFirstResponder()
        }
        return true;
    }

    
    // MARK: - Table view data source

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 3
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 100
        }
        return 60
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if(indexPath.row == 0)
        {
            let cell: ACBrokerageStep1HeaderCell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath) as! ACBrokerageStep1HeaderCell
            let label: UILabel? = cell.viewWithTag(34) as? UILabel
            
            label!.text = "Creating a Brokerage  Account."
            
            cell.selectionStyle = .None
            return cell
        }
        
        let cell: ACBrokerageTextCell = tableView.dequeueReusableCellWithIdentifier("textHeader", forIndexPath: indexPath) as! ACBrokerageTextCell
        
        let label: UILabel? = cell.viewWithTag(33) as? UILabel
        let displayPassword: UIButton? = cell.viewWithTag(30) as? UIButton
        let textField : UITextField? = cell.viewWithTag(32) as? UITextField
        textField?.delegate=self
        // fill the fields if saved offline
        let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
        
        let brokerObj: DPBrokerageEmailObj? = brokerOnboardingInfo.loadCustomObjectWithKey()

        if indexPath.row == 1 {
            label!.text = "EMAIL"
            textField?.keyboardType = .EmailAddress
            self.emailTextField = textField;
            if let brokerModelObj = brokerObj {
                self.emailTextField.text = brokerModelObj.emailStr
            }
            else
            {
                // leave it empty
            }
        }
        else
        {
            textField?.secureTextEntry=true
            self.passwordTextField = textField;
            self.passwordTextField.returnKeyType = .Done
            displayPassword?.hidden=false
            label!.text = "PASSWORD"
            if let brokerModelObj = brokerObj {
                self.passwordTextField.text = brokerModelObj.passwordStr
            }
            else
            {
                // leave it empty
            }
        }
        cell.selectionStyle = .None
        
        
        return cell
    }
}
