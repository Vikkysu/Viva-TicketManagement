//
//  DPSignInViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 9/18/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit
import SnapKit

public class DPSignInViewController: UIViewController {
    public var delegateParent: DPPaginateParent? = nil

    override public func viewDidLoad() {
        super.viewDidLoad()
        
        let backgroundImg: UIImageView =  UIImageView()
        backgroundImg.image = UIImageCustom().getImageFromString("backgroundImage")
        self.view.addSubview(backgroundImg)
        
        backgroundImg.snp_makeConstraints { (make) -> Void in
            make.edges.equalTo(self.view).inset(UIEdgeInsetsMake(0, 0, 0, 0))
        }
        
        let dimmUIView: UIView = UIView()
            dimmUIView.backgroundColor = UIColor.baoTwilightBlue20Color()
            self.view.addSubview(dimmUIView)
    
        dimmUIView.snp_makeConstraints { (make) -> Void in
            make.edges.equalTo(self.view).inset(UIEdgeInsetsMake(0, 0, 0, 0))
        }
        
        let closeButton: UIButton = UIButton()
        closeButton.setBackgroundImage(UIImageCustom().getImageFromString("closeButtonImage"), forState: .Normal)
        dimmUIView.addSubview(closeButton)
        closeButton.addTarget(self, action: "closeView:", forControlEvents: .TouchUpInside)
        
        let signUpLbl: UILabel = UILabel()
        signUpLbl.text = NSLocalizedString("SIGN UP", comment: "SIGN UP")
        dimmUIView.addSubview(signUpLbl)
        signUpLbl.font = UIFont(name: MuseoSansRounded300Font, size: 25.0)
        signUpLbl.textColor = UIColor.whiteColor()

        
        let brokerageBtn: UIButton = UIButton()
        brokerageBtn.setTitle(NSLocalizedString("I’M A BROKERAGE", comment: "I’M A BROKERAGE"), forState: UIControlState.Normal)
        brokerageBtn.titleLabel!.font = UIFont(name: MuseoSansRounded300Font, size: 13.0)
        brokerageBtn.setTitleColor(UIColor.blackColor(), forState: UIControlState.Normal)
        brokerageBtn.backgroundColor=UIColor.whiteColor()
        brokerageBtn.addTarget(self, action: "brokerSignUp:", forControlEvents: .TouchUpInside)
        dimmUIView.addSubview(brokerageBtn)
        
        let agentBtn: UIButton = UIButton()
        agentBtn.setTitle(NSLocalizedString("Test - Invited Agent", comment: "I’M AN AGENT / ASSOCIATE BROKER"), forState: UIControlState.Normal)
        //agentBtn.enabled=false
        agentBtn.titleLabel!.font = UIFont(name: MuseoSansRounded300Font, size: 13.0)
        agentBtn.setTitleColor(UIColor.blackColor(), forState: UIControlState.Normal)
        agentBtn.backgroundColor=UIColor.whiteColor()
        agentBtn.addTarget(self, action: "agentSignUp:", forControlEvents: .TouchUpInside)
        dimmUIView.addSubview(agentBtn)
        
        let profileBtn: UIButton = UIButton()
        profileBtn.setTitle(NSLocalizedString("Test - Profile / Dashboard", comment: "I’M AN AGENT / ASSOCIATE BROKER"), forState: UIControlState.Normal)
        //agentBtn.enabled=false
        profileBtn.titleLabel!.font = UIFont(name: MuseoSansRounded300Font, size: 13.0)
        profileBtn.setTitleColor(UIColor.blackColor(), forState: UIControlState.Normal)
        profileBtn.backgroundColor=UIColor.whiteColor()
        profileBtn.addTarget(self, action: "testProfile:", forControlEvents: .TouchUpInside)
        dimmUIView.addSubview(profileBtn)
        
        let leadsBtn: UIButton = UIButton()
        leadsBtn.setTitle(NSLocalizedString("Test - Lead Injection", comment: "I’M AN AGENT / ASSOCIATE BROKER"), forState: UIControlState.Normal)
        //agentBtn.enabled=false
        leadsBtn.titleLabel!.font = UIFont(name: MuseoSansRounded300Font, size: 13.0)
        leadsBtn.setTitleColor(UIColor.blackColor(), forState: UIControlState.Normal)
        leadsBtn.backgroundColor=UIColor.whiteColor()
        leadsBtn.addTarget(self, action: "testLeads:", forControlEvents: .TouchUpInside)
        dimmUIView.addSubview(leadsBtn)
        
        let loginBtn: UIButton = UIButton()
        loginBtn.setTitle(NSLocalizedString("LOG IN", comment: "LOG IN"), forState: UIControlState.Normal)
        loginBtn.titleLabel!.font = UIFont(name: MuseoSansRounded300Font, size: 13.0)
        loginBtn.setTitleColor(UIColor.whiteColor(), forState: UIControlState.Normal)
        loginBtn.addTarget(self, action: "loginIn:", forControlEvents: .TouchUpInside)
        //loginBtn.backgroundColor=UIColor.whiteColor()
        dimmUIView.addSubview(loginBtn)

        let XomeAppStoreBtn: UIButton = UIButton()
        XomeAppStoreBtn.setTitle(NSLocalizedString("I’M A  BUYER OR SELLER", comment: "I’M A  BUYER OR SELLER"), forState: UIControlState.Normal)
        XomeAppStoreBtn.titleLabel!.font = UIFont(name: MuseoSansRounded300Font, size: 13.0)
        XomeAppStoreBtn.setTitleColor(UIColor.whiteColor(), forState: UIControlState.Normal)
        XomeAppStoreBtn.addTarget(self, action: "redirectPage:", forControlEvents: .TouchUpInside)
        dimmUIView.addSubview(XomeAppStoreBtn)
        
        closeButton.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(dimmUIView).offset(30.0)
            make.leading.equalTo(dimmUIView).offset(20.0)
            make.height.equalTo(24.0)
            make.width.equalTo(24.0)
        }
        
        signUpLbl.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(dimmUIView).offset(150.0)
            make.centerX.equalTo(dimmUIView).offset(0.0)
        }
        
        agentBtn.snp_makeConstraints{ (make) -> Void in
            make.leading.equalTo(dimmUIView).offset(20.0)
            make.centerY.equalTo(dimmUIView).offset(0.0)
            make.trailing.equalTo(dimmUIView).offset(-20.0)
        }
        
        brokerageBtn.snp_makeConstraints{ (make) -> Void in
            make.leading.equalTo(dimmUIView).offset(20.0)
            make.trailing.equalTo(dimmUIView).offset(-20.0)
            make.bottom.equalTo(agentBtn).offset(-50.0)
        }
        
        loginBtn.snp_makeConstraints{ (make) -> Void in
            make.leading.equalTo(dimmUIView).offset(20.0)
            make.top.equalTo(agentBtn).offset(50.0)
            make.trailing.equalTo(dimmUIView).offset(-20.0)
        }
        
        profileBtn.snp_makeConstraints{ (make) -> Void in
            make.leading.equalTo(dimmUIView).offset(20.0)
            make.top.equalTo(loginBtn).offset(50.0)
            make.trailing.equalTo(dimmUIView).offset(-20.0)
        }
        
        leadsBtn.snp_makeConstraints{ (make) -> Void in
            make.leading.equalTo(dimmUIView).offset(20.0)
            make.top.equalTo(profileBtn).offset(50.0)
            make.trailing.equalTo(dimmUIView).offset(-20.0)
        }
        
        XomeAppStoreBtn.snp_makeConstraints{ (make) -> Void in
            make.leading.equalTo(dimmUIView).offset(20.0)
            make.bottom.equalTo(dimmUIView).offset(-50.0)
            make.trailing.equalTo(dimmUIView).offset(-20.0)
        }
        
    }
    
    override public func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    func testLeads(sender: AnyObject) {
        let loginVC: BrokerLeadsViewController = BrokerLeadsViewController()
        self.presentViewController(loginVC, animated: true, completion: nil)
        
    }
   
    func testProfile(sender: AnyObject) {
        let loginVC: BrokerageHomeViewController = BrokerageHomeViewController()
        self.presentViewController(loginVC, animated: true, completion: nil)
        
    }
    
    func loginIn(sender: AnyObject) {
        let loginVC: DPloginViewController = DPloginViewController()
        self.presentViewController(loginVC, animated: true, completion: nil)
    }
    
    func redirectPage(sender: AnyObject) {
        let redirectPage: DPRedirectToXomeAppViewController = DPRedirectToXomeAppViewController()
        self.presentViewController(redirectPage, animated: true, completion: nil)
    }
    
    func closeView(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil);
    }
    
    func brokerSignUp(sender: AnyObject) {
        let agentCreate: DPAccountCreationWelcomeScreenViewController = DPAccountCreationWelcomeScreenViewController()
        
        let navigationController: UINavigationController = UINavigationController(rootViewController: agentCreate)
        //navigationController.navigationController?.pushViewController(navigationController, animated: true)
        userRoleInfo.setUserRole(userType.Broker)
        self.presentViewController(navigationController, animated: true, completion: nil)
    }
    
    func agentSignUp(sender: AnyObject) {
        userRoleInfo.setUserRole(userType.InvitedAgent)

      let agentCreate: DPAgentAccountCreationWelcomeViewController = DPAgentAccountCreationWelcomeViewController()

        let navigationController: UINavigationController = UINavigationController(rootViewController: agentCreate)
        self.presentViewController(navigationController, animated: true, completion: nil)
    }
}
