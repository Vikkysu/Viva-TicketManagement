//
//  DPBrandingDisplayColorTableViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/14/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrandingDisplayColorTableViewController: UITableViewController {
    
    var colorSelected: String!
    
    func setDataFields() -> (Bool, UIColor)
    {
        let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
        var colorSel : UIColor = UIColor.baoDustyOrangeColor()

        if let brokerColorInfoObj: DPBrandingColorObj = brokerOnboardingInfo.loadBrokerageBrandingColorObjectWithKey() {
            if brokerColorInfoObj.isSet != true {
                brokerColorInfoObj.isSet = false
                brokerOnboardingInfo.BrokeragecolorModelObj(brokerColorInfoObj)
                brokerOnboardingInfo.saveBrokerageBrandingColorObject(brokerColorInfoObj)
            }
            else
            {
                colorSel = UIColor(rgba: brokerColorInfoObj.bioPrimaryColor!)
            }
        }
        return (true, colorSel)
    }
    
    func colorSelectedOption(sender :AnyObject) {
        let btnSel: UIButton = sender as! UIButton
        let colSel: UIColor = btnSel.backgroundColor!
        let hexaVal: String = UIColor.toHexString(colSel)
        //set the color to display bar
//        let cell: DPBrandingColorPickerTableViewCell = tableView.cellForRowAtIndexPath(NSIndexPath(forRow: 1, inSection: 0)) as! DPBrandingColorPickerTableViewCell

//        let displayBar: UIView? = cell.viewWithTag(130)
//        displayBar!.backgroundColor = colSel
//        print(hexaVal)
        
        let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
        let brokerColorInfoObj: DPBrandingColorObj = DPBrandingColorObj()
        
        
        brokerColorInfoObj.bioPrimaryColor = hexaVal
        brokerColorInfoObj.isSet = true
        
        brokerOnboardingInfo.BrokeragecolorModelObj(brokerColorInfoObj)
        brokerOnboardingInfo.saveBrokerageBrandingColorObject(brokerColorInfoObj)
        
        let parentViewC : DPBrandingColorPickerViewController =  self.parentViewController as! DPBrandingColorPickerViewController
        parentViewC.createNextbutton(NEXTBUTTON)
        parentViewC.applyColorView(colSel)

    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        tableView.delegate=self
        tableView.dataSource=self
        tableView.showsHorizontalScrollIndicator=false
        tableView.showsVerticalScrollIndicator=false
        tableView.separatorStyle = .None
        tableView.registerClass(ACBrokerageStep1HeaderCell.self, forCellReuseIdentifier: "reuseIdentifier")
        tableView.registerClass(DPBrandingColorPickerTableViewCell.self, forCellReuseIdentifier: "DPBrandingColorPickerTableViewCellIdentifier")
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 2
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 100
        }
        return 300
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        if(indexPath.row == 0)
        {
            let cell: ACBrokerageStep1HeaderCell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath) as! ACBrokerageStep1HeaderCell
            let label: UILabel? = cell.viewWithTag(34) as? UILabel
            
            label!.text = "Select Your Primary Color."
            
            cell.selectionStyle = .None
            return cell
        }
        
        let cell: DPBrandingColorPickerTableViewCell = tableView.dequeueReusableCellWithIdentifier("DPBrandingColorPickerTableViewCellIdentifier", forIndexPath: indexPath) as! DPBrandingColorPickerTableViewCell        
        cell.selectionStyle = .None
        
        
        return cell
    }
}
