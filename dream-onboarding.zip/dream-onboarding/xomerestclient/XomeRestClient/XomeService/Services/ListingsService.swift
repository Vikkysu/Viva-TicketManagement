//
//  ListingsService.swift
//  XomeRestClient
//
//  Created by Vikas on 12/16/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import ObjectMapper
import PromiseKit
import MapKit

extension XomeService {
    private static let PROPERTY_MODEL_KEYS = [
        "bathroomsText",
        "bedroomsTotal",
        "buildingAreaTotal",
        "buildingAreaUnits",
        "city",
        "closeDate",
        "imageFilePath",
        "latitude",
        "listOfficeName",
        "listPrice",
        "listingKey",
        "longitude",
        "postalCode",
        "propertyType",
        "savedPropertyKey",
        "standardStatus",
        "stateOrProvince",
        "unstructuredAddress",
        "modificationTimestamp",
        "openHouseStartTimestamp",
        "openHouseStopTimestamp",
        "openHouse2StartTimestamp",
        "openHouse2StopTimestamp",
    ]
    private static let PROPERTY_DETAILS_KEYS = PROPERTY_MODEL_KEYS + [
        "fieldData",
        "idxDisclaimer",
        "listAgentFirstName",
        "listAor",
        "mortgageCalculatorUrl",
        "photos",
        "publicRemarks",
        "listingId",
    ]
    private static let PROPERTY_LISTING_SPECIFIC_KEYS = PROPERTY_MODEL_KEYS + [
        "photos",
    ]

    // MARK: Search

    public func search(region region: PropertySearchRegion, sortBy: PropertySortOption, pageSize: Int) -> Promise<PropertySearchResultModel>
    {
        let path = "properties/search"
        let params = [
            "pageSize": String(pageSize),
            "fields": XomeService.PROPERTY_LISTING_SPECIFIC_KEYS.joinWithSeparator(",")
        ]
        let request = PropertyRequestModel(sortId: sortBy,
            searchMapNe: region.northEast,
            searchMapSw: region.southWest,
            searchFilter: region.filter)

        let body = NSDictionary( dictionary: Mapper().toJSON(request) ).xome_jsonData()

        return operationFactory.promise(OperationVerb.POST, path: path, queryParameters: params, bodyData: body)
    }

    public func search(query query: PropertySearchModel, filter: PropertySearchFilter, sortBy: PropertySortOption, pageSize: Int)  -> Promise<PropertySearchResultModel>
    {
        let path = "properties/search"
        let params = [
            "pageSize": String(pageSize),
            "fields": XomeService.PROPERTY_LISTING_SPECIFIC_KEYS.joinWithSeparator(",")
        ]
        let request : PropertyRequestModel

        if let boundaryModel = query as? PropertySearchResolvedBoundaryModel,
            let boundary = boundaryModel.boundary where boundary.isSingle
        {
            let region = boundary.boundingBoxRegion()
            let corners = region.corners
            request = PropertyRequestModel(sortId: sortBy,
                searchMapNe: corners.ne,
                searchMapSw: corners.sw,
                searchFilter: filter)
            boundary.applyTo(request)
        } else {
            request = PropertyRequestModel(sortId: sortBy, searchFilter: filter)
            let value: String
            let name = query.name ?? ""
            let city = query.city != nil ? ", \(query.city!)" : ""
            let state = query.state != nil ? ", \(query.state!)" : ""
            switch query.resolvedItemType {
            case .ListingNumber, .StreetName: value = "\(name)\(city)\(state)"
            case .City: value = "\(name)\(state)"
            default: value = name
            }

            request.setLocation(PropertyRequestQueryModel(name: value, type: PropertyQueryType(rawValue: query.type), value: value, invert: false))
        }

        let body = NSDictionary( dictionary: Mapper().toJSON(request) ).xome_jsonData()

        return operationFactory.promise(.POST, path: path, queryParameters: params, bodyData: body)
    }
    
    public func search(searchId id: String, page: Int, pageSize: Int) -> Promise<PropertySearchResultModel>
    {
        let path = "properties"
        let params = [
            "pageSize": String(pageSize),
            "page": String(page),
            "search": id,
            "fields": XomeService.PROPERTY_LISTING_SPECIFIC_KEYS.joinWithSeparator(",")
        ]

        return operationFactory.promise(.GET, path: path, queryParameters: params, bodyData: nil)
    }
    
    public func properties(listingKeys: [String]) -> Promise<PropertySearchResultModel> {
        guard listingKeys.count > 0 else {
            return Promise(PropertySearchResultModel())
        }

        let path = "properties"
        let params = [
            "listingKeys": listingKeys.joinWithSeparator(","),
            "fields": XomeService.PROPERTY_DETAILS_KEYS.joinWithSeparator(",")
        ]

        return operationFactory.promise(.GET, path: path, queryParameters: params, bodyData: nil)
    }
    
    // MARK: Property Details
    
    private func loadPropertyDetails(listingKey: String) -> Promise<PropertyDetailsModel>
    {
        let path = "properties/\(listingKey)"
        let params = [
            "fields": XomeService.PROPERTY_DETAILS_KEYS.joinWithSeparator(",")
        ]

        return operationFactory.promise(.GET, path: path, queryParameters: params, bodyData: nil)
    }
    
    private func loadPropertyWalkscore(propertyDetails: PropertyDetailsModel) -> Promise<PropertyWalkScoreModel> {
        let path = "http://api.walkscore.com/score" // todo: http doesn't work on ios9
        let params = [
            "format": "json",
            "wsapikey": "28c0b84aee0114bb96148e77f80ba04c",
            "lat": String(propertyDetails.lat),
            "lon": String(propertyDetails.lon),
            "address": propertyDetails.address ?? ""
        ]
        return operationFactory.promise(path: path, queryParameters: params, bodyData: nil)
    }
    
    private func loadListingPriceHistory(listingKey: String, listAor: String) -> Promise<[PropertyDetailsListingPriceHistoryModel]>
    {
        let path = "https://www.xome.com/include/ajax/api.aspx?op=GetListingPriceHistory&bypass=1&listingNumber=\(listingKey)&orgId=\(listAor)"
        return operationFactory.promise(.GET, path: path, queryParameters: nil, bodyData: nil)
    }
    
    public func completePropertyDetails(listingKey: String) -> Promise<(PropertyDetailsModel, PropertyWalkScoreModel, PropertyDirectionMapModel, [PropertyDetailsListingPriceHistoryModel])> {
        return loadPropertyDetails(listingKey).then { (details) in
           
            when(self.loadPropertyWalkscore(details), self.loadListingPriceHistory(details.listingId!, listAor: details.aor!)).then { (walkscore, listingPriceHistoryModel) in
                return self.mapToken().then { (mapModel) in
                    return (details, walkscore, mapModel, listingPriceHistoryModel)
                }
            }
        }
    }
   
    public func search(radius radius: Double, center: CLLocationCoordinate2D, sortBy: PropertySortOption? = .Nearest, pageSize: Int, filterModel: PropertyFilterModel?) -> Promise<PropertySearchResultModel>
    {
        let path = "properties"
        let params = [
            "pageSize": String(pageSize),
            "fields": XomeService.PROPERTY_MODEL_KEYS.joinWithSeparator(",")
        ]

        let request = PropertyRadiusSearchModel(radiusDistance: radius,
            radiusLat: center.latitude,
            radiusLong: center.longitude,
            sortId: sortBy?.rawValue,
            filterModel: filterModel)
        let requestDict  = NSDictionary(dictionary: Mapper().toJSON(request))
        let bodyData = requestDict.xome_jsonData()
        return operationFactory.promise(.POST, path: path, queryParameters: params, bodyData: bodyData)
    }

    public func autoCompleteLocations(query: String) -> Promise<[PropertySearchModel]> {
        let path = environment.webURL()!.URLByAppendingPathComponent("include/ajax/mapsearch/getlocations2.aspx").absoluteString
        let timeStamp = NSDate().timeIntervalSince1970
        let params = [
            "q": query,
            "bypass": "1",
            "ts": String(timeStamp),
            "limit": "50",
            "type": "uspszip,fulladdress,uspscity,neighborhood,streetname,uspscounty,school,schooldistrict,listingnumber"
        ]
        return operationFactory.promise(path: path, queryParameters: params, bodyData: nil)
    }
}