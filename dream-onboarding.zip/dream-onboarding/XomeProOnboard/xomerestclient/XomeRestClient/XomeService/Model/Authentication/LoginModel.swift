//
//  LoginModel.swift
//  XomeRestClient
//
//  Created by Brendan Farrington on 12/2/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class LoginModel: Mappable {
    public var username: String?
    public var password: String?
    public var deviceInfo: DeviceInfoModel?

    public init() {
        
    }

    required public init?(_ map: Map) {

    }

    public func mapping(map: Map) {
        username <- map["loginId"]
        password <- map["password"]
        deviceInfo <- map["deviceInfo"]
    }
}