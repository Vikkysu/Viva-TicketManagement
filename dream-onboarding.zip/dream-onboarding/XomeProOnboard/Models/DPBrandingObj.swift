//
//  DPBrandingObj.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/8/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrandingImageObj: NSObject {
    var isSet: Bool?
    var bioLogoImage : UIImage?
    //save the model for offline usage
    func encodeWithCoder(encoder: NSCoder) {
        encoder.encodeObject(self.bioLogoImage, forKey: "Logo")
        encoder.encodeObject(self.isSet, forKey: "isSet")
    }
    
    func initWithCoder(decoder: NSCoder)->AnyObject {
        self.bioLogoImage = decoder.decodeObjectForKey("Logo") as? UIImage
        self.isSet = decoder.decodeObjectForKey("isSet") as? Bool
        return self;
    }
}

class DPBrandingColorObj: NSObject {
    var isSet: Bool?
    var bioPrimaryColor: String?
    //save the model for offline usage
    func encodeWithCoder(encoder: NSCoder) {
        encoder.encodeObject(self.bioPrimaryColor, forKey: "PrimaryColor")
        encoder.encodeObject(self.isSet, forKey: "isSet")
    }
    
    func initWithCoder(decoder: NSCoder)->AnyObject {
        self.bioPrimaryColor = decoder.decodeObjectForKey("PrimaryColor") as? String
        self.isSet = decoder.decodeObjectForKey("isSet") as? Bool
        return self;
    }
}


class DPBrandingBioObj: NSObject {
    var bioStr : String?
    var isSet: Bool?

    //save the model for offline usage
    func encodeWithCoder(encoder: NSCoder) {
        encoder.encodeObject(self.bioStr, forKey: "Bio")
        encoder.encodeObject(self.isSet, forKey: "isSet")
    }
    
    func initWithCoder(decoder: NSCoder)->AnyObject {
        self.bioStr = decoder.decodeObjectForKey("Bio") as? String
        self.isSet = decoder.decodeObjectForKey("isSet") as? Bool
        return self;
    }
}

class DPBrandingWebsiteAddrObj: NSObject {
    var websiteAddressStr : String?
    var isSet: Bool?

    //save the model for offline usage
    func encodeWithCoder(encoder: NSCoder) {
        encoder.encodeObject(self.websiteAddressStr, forKey: "webSite")
        encoder.encodeObject(self.isSet, forKey: "isSet")
    }
    
    func initWithCoder(decoder: NSCoder)->AnyObject {
        self.websiteAddressStr = decoder.decodeObjectForKey("webSite") as? String
        self.isSet = decoder.decodeObjectForKey("isSet") as? Bool
        return self;
    }
}

