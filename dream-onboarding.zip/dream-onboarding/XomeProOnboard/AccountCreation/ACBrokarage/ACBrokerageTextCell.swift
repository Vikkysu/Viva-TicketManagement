//
//  ACBrokerageTextCell.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/4/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class ACBrokerageTextCell: UITableViewCell {
    
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String!)
    {
        super.init(style: UITableViewCellStyle.Value1, reuseIdentifier: reuseIdentifier)
        var labelText : UILabel
        labelText = UILabel()
        labelText.textAlignment = .Left
        labelText.tag=33
        labelText.font = UIFont(name: MuseoSansRounded100Font, size: 11.0)
        self.addSubview(labelText)
        
        let textField : UITextField = UITextField()
        textField.font = UIFont(name: MuseoSansRounded100Font, size: 20.0)
        textField.tag=32
        self.addSubview(textField)
        
        let displayPassword: UIButton = UIButton()
        displayPassword.setBackgroundImage(UIImageCustom().getImageFromString("showPassword"), forState: UIControlState.Normal)
        displayPassword.tag=30
        displayPassword.hidden=true
        displayPassword.addTarget(self, action: "displayPassword:", forControlEvents: .TouchUpInside)
        self.addSubview(displayPassword)
        
        let separatorLine: UIView = UIView()
        separatorLine.backgroundColor = UIColor.baoTableBorderColor()
        self.addSubview(separatorLine)
        
        labelText.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self).offset(5)
            make.leading.equalTo(self).offset(10)
            make.height.equalTo(25)
        }
        
        textField.snp_makeConstraints { (make) -> Void in
            make.bottom.equalTo(labelText).offset(20)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(10)
            make.height.equalTo(30)
        }
        
        displayPassword.snp_makeConstraints { (make) -> Void in
            make.height.equalTo(12)
            make.width.equalTo(18)
            make.centerY.equalTo(self)
            make.trailing.equalTo(self).offset(-10)
        }
        
        separatorLine.snp_makeConstraints {(make) -> Void in
            make.bottom.equalTo(textField).offset(4)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-1)
            make.height.equalTo(1)
        }
    }
    
    func displayPassword(sender : AnyObject) {
        let textField: UITextField? = self.viewWithTag(32) as? UITextField
        
        if let textField1 = textField {
            textField1.secureTextEntry = !textField1.secureTextEntry
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setSelected(selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
}
