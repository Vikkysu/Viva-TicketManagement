//
//  AuthenticationService.swift
//  XomeRestClient
//
//  Created by Vikas on 1/14/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper
import PromiseKit

let RegisterMessagableErrorCode = 10081

public extension XomeService {

    public func login(login: LoginModel) -> Promise<ResponseModel> {
        guard let loginData = Mapper().toJSONString(login)?.dataUsingEncoding(NSUTF8StringEncoding) else {
            return Promise(error: NSError(domain: "JSON Serialization", code: 0, userInfo: [NSLocalizedDescriptionKey:"Failed to serialize LoginModel"]))
        }

        return operationFactory.promise(.POST, path: "login", queryParameters: nil, bodyData: loginData).then { (promise: ResponseModel) -> ResponseModel in
            self.fixupAuthCookies()
            return promise
        }
    }

    public func register(register: RegisterModel) -> Promise<ResponseModel> {
        guard let registerData = Mapper().toJSONString(register)?.dataUsingEncoding(NSUTF8StringEncoding) else {
            return Promise(error: NSError(domain: "JSON Serialization", code: 0, userInfo: [NSLocalizedDescriptionKey:"Failed to serialize RegisterModel"]))
        }

        return operationFactory.promise(.POST, path: "contacts", queryParameters: nil, bodyData: registerData).then { (promise: ResponseModel) -> ResponseModel in
            self.fixupAuthCookies()
            return promise
        }

    }

    // api.xome.com and www.xome.com have conflicting setCookie domains and expirations
    func fixupAuthCookies() {
        for cookie in NSHTTPCookieStorage.sharedHTTPCookieStorage().cookies! {
            if cookie.name == XomeServiceEnv.sharedInstance.cookieName {
                var cookieProperties = cookie.properties!
                cookieProperties[NSHTTPCookieDomain] = XomeServiceEnv.sharedInstance.cookieHost()
                cookieProperties[NSHTTPCookieExpires] = NSDate(timeIntervalSinceNow: XomeServiceEnv.sharedInstance.cookieExpiration())
                NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(NSHTTPCookie(properties: cookieProperties)!)

                var webCookieProperties = cookieProperties
                webCookieProperties[NSHTTPCookieName] = XomeServiceEnv.sharedInstance.webCookieName
                webCookieProperties[NSHTTPCookieDomain] = XomeServiceEnv.sharedInstance.webCookieHost()
                NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(NSHTTPCookie(properties: webCookieProperties)!)

                NSHTTPCookieStorage.sharedHTTPCookieStorage().deleteCookie(cookie)
                break
            }
        }
    }

    public func forgotPassword(email: String) -> Promise<Void> {
        let forgotPasswordPath = "/mobile/v3/account/forgotpassword.aspx"
        let forgotPasswordUrl = NSURL(string: forgotPasswordPath, relativeToURL: XomeServiceEnv.sharedInstance.webURL())
        let queryParams = ["bypass" : "1", "send" : "1", "LoginName" : email]
        return operationFactory.promise(OperationVerb.GET, path: forgotPasswordUrl!.absoluteString, queryParameters: queryParams, bodyData: nil)
            // This forgotpassword request will result in an empty NSData response-- turning this into a Void to avoid confusion about the response
            .then() { _ -> Void in }
    }

    // TODO: This is currently configured for Facebook only
    public func socialLogin() {
        let urlComponents = NSURLComponents(string: XomeServiceEnv.sharedInstance.socialLoginURLString())!
        urlComponents.path = "/account/testsociallogin.aspx"
        urlComponents.queryItems = [
            NSURLQueryItem(name: "bypass", value: "1"),
            NSURLQueryItem(name: "p", value: "1"),
            NSURLQueryItem(name: "r", value: "100004"),
            NSURLQueryItem(name: "u", value: XomeServiceEnv.sharedInstance.socialLoginDomainParam()),
            NSURLQueryItem(name: "s", value: "rwmhs2")
        ]
        UIApplication.sharedApplication().openURL(urlComponents.URL!)
    }
    
    public func handleSocialLoginCredentials(socialLoginCredentials: SocialLoginCredentialsModel) -> Promise<Void> {
        return Promise { (resolve, reject) in
            guard let token = socialLoginCredentials.token else {
                reject(NSError(domain: "Missing Auth Token", code: 0, userInfo: nil))
                return
            }
            var cookieProperties: [String : AnyObject] = [:]
            cookieProperties[NSHTTPCookieName] = XomeServiceEnv.sharedInstance.cookieName
            cookieProperties[NSHTTPCookieValue] = token
            cookieProperties[NSHTTPCookieDomain] = XomeServiceEnv.sharedInstance.cookieHost()
            cookieProperties[NSHTTPCookiePath] = "/"
            cookieProperties[NSHTTPCookieExpires] = NSDate(timeIntervalSinceNow: XomeServiceEnv.sharedInstance.cookieExpiration())

            var webCookieProperties = cookieProperties
            webCookieProperties[NSHTTPCookieName] = XomeServiceEnv.sharedInstance.webCookieName
            webCookieProperties[NSHTTPCookieDomain] = XomeServiceEnv.sharedInstance.webCookieHost()

            NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(NSHTTPCookie(properties: cookieProperties)!)
            NSHTTPCookieStorage.sharedHTTPCookieStorage().setCookie(NSHTTPCookie(properties: webCookieProperties)!)
            resolve()
        }
    }

    public func logout() -> Promise<Void> {
        return Promise { (resolve, reject) in
            for cookie in NSHTTPCookieStorage.sharedHTTPCookieStorage().cookies! {
                if cookie.name == ".rwapiauth" || cookie.name == ".publicauth" {
                    NSHTTPCookieStorage.sharedHTTPCookieStorage().deleteCookie(cookie)
                }
            }
            resolve()
        }
    }
}
