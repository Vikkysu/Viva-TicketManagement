//
//  accountCreationStep1ViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 9/27/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class accountCreationStep1ViewController: DPAccountCreationBaseViewController {
    
    override func nextViewC1(sender: UIBarButtonItem) {
        print(self.childViewControllers)
        
        let accountViewCntrl = self.childViewControllers[0] as! CreateAccountViewController
        if accountViewCntrl.setProfileObj() == true {
            let sb = Global().spinUpBoard("accountCreationStoryboard")
            let initVC = sb?.instantiateViewControllerWithIdentifier("secondViewCntrl")
            self.navigationController?.pushViewController(initVC!, animated: true)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let backItem = UIBarButtonItem(title: "Cancel", style: .Plain, target: self, action: "closeView")
        self.navigationItem.leftBarButtonItem = backItem
        
        //set the font & color for navigation bar buttons
        let fontStyle : UIFont = UIFont(name: MuseoSansRounded300Font, size: 18.0)!
        let titleDict: NSDictionary = [NSForegroundColorAttributeName: UIColor.whiteColor(), NSFontAttributeName: fontStyle]
        self.navigationItem.leftBarButtonItem!.setTitleTextAttributes(titleDict as? [String : AnyObject], forState: .Normal)
        self.navigationItem.leftBarButtonItem?.tintColor = UIColor.whiteColor()
        self.navigationItem.rightBarButtonItem!.setTitleTextAttributes(titleDict as? [String : AnyObject], forState: .Normal)

        
        func closeView(sender: UIBarButtonItem) {
            if let navigationController = self.navigationController
            {
                navigationController.popViewControllerAnimated(true)
            }
        }        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func step2(sender: AnyObject) {
        //self.accountcreation2(sender)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
