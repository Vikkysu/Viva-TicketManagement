//
//  EditProfileVIew.swift
//  ProfessionalTools
//
//  Created by MACMINI4 on 23/10/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class EditProfileVIew: NSObject {
    
    var editProfileModel : EditProfileModel = EditProfileModel()
    
    var vwController                    :UIViewController!
    var vwMain                            :UIView!
    var vwSubview                            :UIView!

    var vwHeader                        :UIView!
    var vwHeaderRight                :UIImageView!
    
    var btnBackHeader                  :UIButton!
    var lblHeader                   :UILabel!
    var btnRtHeader                 :UIButton!
    
    var imgProfilePic               :UIImageView!
    var lblEditProfileHeader                  :UILabel!
    
    var dividerView1                  : UIView!
    var lblFirstNameHeader      : UILabel!
    var lblLastNameHeader       : UILabel!
    var tfFirstName                    : UITextField!
    var tfLastName                     : UITextField!
    
    var dividerView2                  : UIView!
    var lblEmailHeader      : UILabel!
    var tfEmail                    : UITextField!
    
    var dividerView3                  : UIView!
    var lblPhoneHeader      : UILabel!
    var tfPhone                    : UITextField!
    
    
    
    var cgScreenWidth               :CGFloat!
    var cgScreenHeight              :CGFloat!
    
    func loadEditProfileUI(inViewController :UIViewController, inEditProfileModel: EditProfileModel){
        
        vwController       = inViewController
        editProfileModel   = inEditProfileModel

        getScreenDimensions()
        createUIElements()
        setProperties()
        setProfileData()
        addElements2UI()
    }
    
    
    func getScreenDimensions(){
        
        let screenDimensions = UIScreen.mainScreen().bounds
        cgScreenWidth        = screenDimensions.width
        cgScreenHeight       = screenDimensions.height
    }
    
    func centreX(inWidth: CGFloat)->CGFloat{
        
        let tWidth:CGFloat  = cgScreenWidth - CGFloat(inWidth)
        let pX: CGFloat     = tWidth/2
        
        return pX
    }
    
    func centreY(inHeight: CGFloat)->CGFloat{
        
        let tHeight:CGFloat  = cgScreenHeight - CGFloat(inHeight)
        let pY: CGFloat      = tHeight/2
        
        return pY
    }
    
    func convert2Pixels(points:CGFloat)->CGFloat{
        
        let pixels  :CGFloat = points * 96 / 72
        return pixels
    }
    
    func createUIElements(){
        
        let hdrVwHeight :CGFloat = self.convert2Pixels(65)
        let hdrWidth    :CGFloat = self.convert2Pixels(32)
        let hdrHeight   :CGFloat = self.convert2Pixels(22)
        let hdRtWidth   :CGFloat = self.convert2Pixels(30)
        let hdRtHeight  :CGFloat = self.convert2Pixels(30)
        let hdRtX       :CGFloat = cgScreenWidth - hdRtWidth - 20 //constraint set to hdRtWidth
        let hdRTY       :CGFloat = self.convert2Pixels(31)
        let hdrX        :CGFloat = self.centreX(hdrWidth)
        let hdrY        :CGFloat = self.convert2Pixels(31)
        let vwDHeight   :CGFloat = self.convert2Pixels(150)
         let profX       :CGFloat = self.centreX(110)
        
        let profHY      :CGFloat = self.convert2Pixels(15)
        
        
        vwMain              = UIView(frame:CGRectMake(0, 0, cgScreenWidth, cgScreenHeight))
        
        vwSubview        = UIView(frame:CGRectMake(10, hdrVwHeight+10, cgScreenWidth-20, cgScreenHeight-hdrVwHeight-20))
        
        vwHeader            = UIView(frame:CGRectMake(0, 0, cgScreenWidth, hdrVwHeight))
        btnBackHeader          = UIButton(frame:CGRectMake(0, hdrY, hdRtWidth+20, hdRtHeight))
        lblHeader           = UILabel(frame:CGRectMake(hdrX, hdrY+2, hdrWidth, hdrHeight))
        btnRtHeader         = UIButton(frame:CGRectMake(hdRtX , hdRTY, hdRtWidth, hdRtHeight))
        
        
        imgProfilePic       = UIImageView(frame:CGRectMake(profX, profHY+40, 110, 110))
        lblEditProfileHeader          = UILabel(frame:CGRectMake(0, profHY, cgScreenWidth, 20))
        
        dividerView1        = UIView(frame: CGRectMake(0, profHY+170, cgScreenWidth-20, 2))
        lblFirstNameHeader = UILabel(frame: CGRectMake(5, profHY+175, cgScreenWidth-20/2, 20))
        lblLastNameHeader = UILabel(frame: CGRectMake(cgScreenWidth/2, profHY+175, cgScreenWidth/2, 20))
        tfFirstName              = UITextField(frame: CGRectMake(5, profHY+200, cgScreenWidth-20/2, 33))
        tfLastName = UITextField(frame: CGRectMake(cgScreenWidth/2, profHY+200, cgScreenWidth/2, 33))
        
        dividerView2        = UIView(frame: CGRectMake(0, profHY+250, cgScreenWidth-20, 2))
        lblEmailHeader = UILabel(frame: CGRectMake(5, profHY+255, cgScreenWidth-20/2, 20))
        tfEmail              = UITextField(frame: CGRectMake(5, profHY+280, cgScreenWidth-20/2, 33))
        

        dividerView3        = UIView(frame: CGRectMake(0, profHY+325, cgScreenWidth-20, 2))
        lblPhoneHeader = UILabel(frame: CGRectMake(5, profHY+330, cgScreenWidth-20/2, 20))
        tfPhone              = UITextField(frame: CGRectMake(5, profHY+355, cgScreenWidth-20/2, 33))
        


        
    }
    
    func setProperties(){
        
        vwMain.backgroundColor          = UIColor(red: 250/255, green: 250/255, blue: 250/255, alpha: 1)
        vwSubview.backgroundColor          = UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1)

        //setup header
        vwHeader.backgroundColor        = UIColor(red: 217/255, green: 2/255, blue: 9/255, alpha: 1)
        btnBackHeader.setTitle("Cancel", forState: UIControlState.Normal)
        btnBackHeader.addTarget(self, action: Selector("back"), forControlEvents: UIControlEvents.TouchUpInside)

        btnRtHeader.setTitle("Save", forState: UIControlState.Normal)
        btnRtHeader.addTarget(self, action: Selector("back"), forControlEvents: UIControlEvents.TouchUpInside)
        btnRtHeader.backgroundColor = UIColor.clearColor()
        
        lblHeader.text              = "Edit"
        let headerFont      :UIFont = UIFont(name: "MuseoSansRounded-300", size: 18.0)!
        lblHeader.font              = headerFont
        lblHeader.textColor         = UIColor.whiteColor()
        
        
        let pImage          :UIImage = UIImage(named:"profile.png")!
        imgProfilePic.image          = pImage
        imgProfilePic.image?.circleMask
        
        lblEditProfileHeader.textColor          = UIColor.blackColor()
        lblEditProfileHeader.textAlignment      = NSTextAlignment.Center
        let shopperFont      :UIFont  = UIFont(name: "MuseoSansRounded-300", size: 17.0)!
        lblEditProfileHeader.font               = shopperFont
        lblEditProfileHeader.text               = "Edit Your Profile."
        
        dividerView1.backgroundColor = UIColor(red: 232/255, green: 232/255, blue: 232/255, alpha: 1)
        
        lblFirstNameHeader.textColor               = UIColor(red: 159/255, green: 162/255, blue: 164/255, alpha: 1)
        lblFirstNameHeader.text                    = "FIRST NAME"
        let h1Font                  :UIFont = UIFont(name: "MuseoSansRounded-300", size: 10.0)!
        lblFirstNameHeader.font                    = h1Font
        
        lblLastNameHeader.textColor               = UIColor(red: 159/255, green: 162/255, blue: 164/255, alpha: 1)
        lblLastNameHeader.text                        = "LAST NAME"
        lblLastNameHeader.font                    = h1Font

        tfFirstName.textColor                                    = UIColor.blackColor()
        let t1Font                  :UIFont = UIFont(name: "MuseoSansRounded-300", size: 15.0)!
        tfFirstName.font                                            = t1Font
        tfFirstName.userInteractionEnabled             =   false

        tfLastName.textColor                                    = UIColor.blackColor()
        tfLastName.font                                            = t1Font
        tfLastName.userInteractionEnabled             =   false
        
        dividerView2.backgroundColor = UIColor(red: 232/255, green: 232/255, blue: 232/255, alpha: 1)
        lblEmailHeader.textColor               = UIColor(red: 159/255, green: 162/255, blue: 164/255, alpha: 1)
        lblEmailHeader.text                        = "EMAIL"
        lblEmailHeader.font                    = h1Font
        
        dividerView3.backgroundColor = UIColor(red: 232/255, green: 232/255, blue: 232/255, alpha: 1)
        tfEmail.textColor                                    = UIColor.blackColor()
        tfEmail.font                                            = t1Font
        tfEmail.userInteractionEnabled             =   false
        
        
        lblPhoneHeader.textColor               = UIColor(red: 159/255, green: 162/255, blue: 164/255, alpha: 1)
        lblPhoneHeader.text                        = "MOBILE NUMBER"
        lblPhoneHeader.font                    = h1Font
        
        tfPhone.textColor                                    = UIColor.blackColor()
        tfPhone.font                                            = t1Font
        tfPhone.userInteractionEnabled             =   false

    }
    
    func setProfileData(){

        tfFirstName.text  = editProfileModel.shopperFirstName
        tfLastName.text    = editProfileModel.shopperLastName
        tfEmail.text = editProfileModel.contactEmail
        tfPhone.text = editProfileModel.contactPhone
    }
    
    func addElements2UI(){
        
        vwController.view.addSubview(vwMain)
        vwMain.addSubview(vwHeader)
        vwMain.addSubview(vwSubview)
        
        vwHeader.addSubview(btnBackHeader)
        vwHeader.addSubview(lblHeader)
        vwHeader.addSubview(btnRtHeader)
        
        vwSubview.addSubview(imgProfilePic)
        vwSubview.addSubview(lblEditProfileHeader)
        
        
        vwSubview.addSubview(dividerView1)
        vwSubview.addSubview(lblFirstNameHeader)
        vwSubview.addSubview(lblLastNameHeader)
        vwSubview.addSubview(tfFirstName)
        vwSubview.addSubview(tfLastName)
        
        vwSubview.addSubview(dividerView2)
        vwSubview.addSubview(lblEmailHeader)
        vwSubview.addSubview(tfEmail)
        
        vwSubview.addSubview(dividerView3)
        vwSubview.addSubview(lblPhoneHeader)
        vwSubview.addSubview(tfPhone)
        
    }
    func back(){
        vwController.navigationController?.popViewControllerAnimated(true)
    }
    
    
}
