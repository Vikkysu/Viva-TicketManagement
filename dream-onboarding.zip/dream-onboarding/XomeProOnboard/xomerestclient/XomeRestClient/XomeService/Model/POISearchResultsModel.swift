//
//  POISearchResultsModel.swift
//  XomeRestClient
//
//  Created by Thomas De Leon on 3/2/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class POISearchResultsModel {
    public var items = [POIModel]()
    
    public init(items:[POIModel]) {
        self.items = items
    }
    
}
