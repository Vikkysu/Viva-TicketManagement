//
//  DPAgentOnBoardingModel.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/24/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

let keyAgentOnBoardingObj: String = "AgentOnBoardingObjKey"
let keyAgentBrandingWebsiteYoutubeObj: String = "AgentBrandingWebsiteYoutubeObjKey"
let keyAgentProfileObj: String = "AgentProfileObjkey"
let keyAgentLicenseObj: String = "AgentLicenseObjKey"
let keyAgentMLSObj: String = "AgentMLSObjKey"
let keyAgentBrandingBioObj: String = "AgentBrandingBioObjKey"

class DPAgentOnBoardingModel: NSObject {
    static let sharedInstance = DPAgentOnBoardingModel()
    
    //getter & setter for Broker License information
    var brokerLicenseObjModelObj : DPBrokerLicenseInfo!
    func getbrokerLicenseModelObj() ->DPBrokerLicenseInfo {
        return brokerLicenseObjModelObj
    }
    
    func brokerLicenseModelObj(LicenseModelObject :DPBrokerLicenseInfo) {
        brokerLicenseObjModelObj = LicenseModelObject
    }
    
    //getter & setter for Broker MLS information
    var brokerMLSObjModelObj : DPBrokerMLSInfo!
    func getbrokerMLSModelObj() ->DPBrokerMLSInfo {
        return brokerMLSObjModelObj
    }
    
    func brokerMLSModelObj(MLSModelObject :DPBrokerMLSInfo) {
        brokerMLSObjModelObj = MLSModelObject
    }
    
    //getter & setter for Broker website & youtube information
    var brokerageWebsiteYoutubeModelObj : DPBrandingWebsiteYoutubeAddrObj?
    
    func getBrokerageWebsiteyoutubeModelObj() ->DPBrandingWebsiteYoutubeAddrObj? {
        return self.brokerageWebsiteYoutubeModelObj
    }
    
    func BrokerageWebsiteYoutubeModelObj(brandingWebsiteYoutubeModelObject :DPBrandingWebsiteYoutubeAddrObj) {
        brokerageWebsiteYoutubeModelObj = brandingWebsiteYoutubeModelObject
    }
    
    //getter & setter for profile information
    var brokerProfileModelObj : DPBrokerProfileObj?
    
    func getBrokerProfileModelObj() ->DPBrokerProfileObj? {
        return self.brokerProfileModelObj
    }
    
    func BrokerProfileModelObj(brokerProfileModelObject :DPBrokerProfileObj) {
        brokerProfileModelObj = brokerProfileModelObject
    }
    
    
    //save the model for offline usage
    func encodeWithCoder(encoder: NSCoder) {
        encoder.encodeObject(self, forKey: keyAgentOnBoardingObj)
    }
    
    func initWithCoder(decoder: NSCoder)->AnyObject {
        return self;
    }
    
    //save Brokerage License Custom Object
    func saveBrokerLicenseCustomObject(object: DPBrokerLicenseInfo) {
        let encodedObject: NSData = NSKeyedArchiver.archivedDataWithRootObject(object);
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.setObject(encodedObject, forKey:keyAgentLicenseObj);
        defaults.synchronize();
        
    }
    
    func loadBrokerLicenseCustomObjectWithKey()->DPBrokerLicenseInfo? {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        if let encodedObject: NSData = defaults.objectForKey(keyAgentLicenseObj) as? NSData
        {
            if let object: DPBrokerLicenseInfo? = NSKeyedUnarchiver.unarchiveObjectWithData(encodedObject) as? DPBrokerLicenseInfo {
                return object;
            }
        }
        return nil
    }
    
    func removeBrokerLicenseSavedObj() {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.removeObjectForKey(keyAgentLicenseObj)
    }
    
    //save Brokerage MLS Custom Object
    func saveBrokerMLSCustomObject(object: DPBrokerMLSInfo) {
        let encodedObject: NSData = NSKeyedArchiver.archivedDataWithRootObject(object);
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.setObject(encodedObject, forKey:keyAgentMLSObj);
        defaults.synchronize();
        
    }
    
    func loadBrokerMLSCustomObjectWithKey()->DPBrokerMLSInfo? {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        if let encodedObject: NSData = defaults.objectForKey(keyAgentMLSObj) as? NSData
        {
            if let object: DPBrokerMLSInfo? = NSKeyedUnarchiver.unarchiveObjectWithData(encodedObject) as? DPBrokerMLSInfo {
                return object;
            }
        }
        return nil
    }
    
    func removeBrokerLMLSSavedObj() {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.removeObjectForKey(keyAgentMLSObj)
    }
    
    //getter & setter for Broker about us information
    var brokerBioModelObj : DPBrandingBioObj?
    
    func getBrokerBioModelObj() ->DPBrandingBioObj? {
        return self.brokerBioModelObj
    }
    
    func BrokerBioModelObj(brandingBioModelObject :DPBrandingBioObj) {
        brokerBioModelObj = brandingBioModelObject
    }
    
    //save Broker About us Custom Object
    func saveBrokerBrandingBioObject(object: DPBrandingBioObj) {
        let encodedObject: NSData = NSKeyedArchiver.archivedDataWithRootObject(object);
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.setObject(encodedObject, forKey:keyAgentBrandingBioObj);
        defaults.synchronize();
        
    }
    
    func loadBrokerBrandingBioObjectWithKey()->DPBrandingBioObj? {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        if let encodedObject: NSData = defaults.objectForKey(keyAgentBrandingBioObj) as? NSData
        {
            if let object: DPBrandingBioObj? = NSKeyedUnarchiver.unarchiveObjectWithData(encodedObject) as? DPBrandingBioObj {
                return object;
            }
        }
        return nil
    }
    
    func removeBrokerBrandingBioSavedObj() {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.removeObjectForKey(keyAgentBrandingBioObj)
    }
    
    //save Brokerage WEBSITE&YOUTUBE Custom Object
    func saveBrokerageBrandingWebsiteYoutubeObject(object: DPBrandingWebsiteYoutubeAddrObj) {
        let encodedObject: NSData = NSKeyedArchiver.archivedDataWithRootObject(object);
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.setObject(encodedObject, forKey:keyAgentBrandingWebsiteYoutubeObj);
        defaults.synchronize();
        
    }
    
    func loadBrokerageBrandingWebsiteYoutubeObjectWithKey()->DPBrandingWebsiteYoutubeAddrObj? {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        if let encodedObject: NSData = defaults.objectForKey(keyAgentBrandingWebsiteYoutubeObj) as? NSData
        {
            if let object: DPBrandingWebsiteYoutubeAddrObj? = NSKeyedUnarchiver.unarchiveObjectWithData(encodedObject) as? DPBrandingWebsiteYoutubeAddrObj {
                return object;
            }
        }
        return nil
    }
    
    func removeBrokerageBrandingWebsiteYoutubeSavedObj() {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.removeObjectForKey(keyAgentBrandingWebsiteYoutubeObj)
    }
    
    //set the profile broker object
    func saveBrokerProfileObject(object: DPBrokerProfileObj) {
        let encodedObject: NSData = NSKeyedArchiver.archivedDataWithRootObject(object);
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.setObject(encodedObject, forKey:keyAgentProfileObj);
        defaults.synchronize();
        
    }
    
    func loadBrokerProfileObjectWithKey()->DPBrokerProfileObj? {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        if let encodedObject: NSData = defaults.objectForKey(keyAgentProfileObj) as? NSData
        {
            if let object: DPBrokerProfileObj? = NSKeyedUnarchiver.unarchiveObjectWithData(encodedObject) as? DPBrokerProfileObj {
                return object;
            }
        }
        return nil
    }
    
    func removeBrokerProfileSavedObj() {
        let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults();
        defaults.removeObjectForKey(keyAgentProfileObj)
    }
    
    //temp return profile object ::: TODO:- Later to be removed
    func getProfileInfo() -> DPBrokeragePersonalInfoObj {
        
        let profileObj = DPBrokeragePersonalInfoObj()
        profileObj.brokerageName = "Meredith Fine Properties Group"
        profileObj.brokeragePhone = "(206) 381-9240"
        profileObj.brokerageAddress = "1234 Realty Road "
        profileObj.brokerageAddressOpt = "Suite 300"
        profileObj.brokerageCity = "Seattle"
        profileObj.brokerageState = "WA"
        profileObj.brokerageZipcode = "34569"
        
        return profileObj
        
    }
}

