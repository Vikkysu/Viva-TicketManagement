//
//  LeadsDetailModel.swift
//  DreamLeadInjection
//
//  Created by Developer on 22/10/15.
//  Copyright © 2015 Developer. All rights reserved.
//

import UIKit

class LeadsDetailModel: NSObject {
    
    var leadsDataArray          :NSMutableArray        = NSMutableArray()
    var leadDetailDictionary    :NSMutableDictionary   = NSMutableDictionary()
    
    func createAndGetDataSample(){
        
        
        leadDetailDictionary["leadOwner"]     = "Jennifer Smith"
        leadDetailDictionary["leadSource"]    = "FROM ZILLOW"
        leadDetailDictionary["leadType"]      = "Buyer"
        leadDetailDictionary["leadName"]      = "Marie Hayes"
        leadDetailDictionary["leadEmail"]     = "mariehayes@gmail.com"
        leadDetailDictionary["leadMobile"]    = "(206) 390-5555"
        leadDetailDictionary["leadPOI"]       = "222 101th Street NE\nBellevuew, WA 98004"
        leadDetailDictionary["ownerNote"]     = "Marie is interested in this property"
        leadDetailDictionary["updated"]       = "10/23/2015 10:45 AM"
        
        leadsDataArray.addObject(leadDetailDictionary)
        leadDetailDictionary = NSMutableDictionary(capacity: 0)
        
        leadDetailDictionary["leadOwner"]     = "Kim Patrick"
        leadDetailDictionary["leadSource"]    = "FROM XOME"
        leadDetailDictionary["leadType"]      = "Seller"
        leadDetailDictionary["leadName"]      = "Lena Rivera"
        leadDetailDictionary["leadEmail"]     = "lenarivera@gmail.com"
        leadDetailDictionary["leadMobile"]    = "(400) 336-6789"
        leadDetailDictionary["leadPOI"]       = "234 101th Street NE\nBellevuew, WA 98004"
        leadDetailDictionary["ownerNote"]     = "Lena is interested in this property and would like to know the implications"
        leadDetailDictionary["updated"]       = "10/23/2015 12:45 PM"
        
        
        leadsDataArray.addObject(leadDetailDictionary)
        leadDetailDictionary = NSMutableDictionary(capacity: 0)
        
        leadDetailDictionary["leadOwner"]     = "Ryan Gosling"
        leadDetailDictionary["leadSource"]    = "FROM Website"
        leadDetailDictionary["leadType"]      = "Unknown"
        leadDetailDictionary["leadName"]      = "Jason Fuller"
        leadDetailDictionary["leadEmail"]     = "jasonfuller@gmail.com"
        leadDetailDictionary["leadMobile"]    = "(300) 142-4352"
        leadDetailDictionary["leadPOI"]       = "244 101th Street NE\nBellevuew, WA 98004"
        leadDetailDictionary["ownerNote"]     = "Jason will be interested in this property after a month if it is still available"
        leadDetailDictionary["updated"]       = "10/23/2015 5:45 PM"
        
        leadsDataArray.addObject(leadDetailDictionary)
    }
    
    func fetchLeadData(leadName: String)->NSMutableArray{
        
        self.createAndGetDataSample()
        
        let tDataArray:NSMutableArray = leadsDataArray.mutableCopy() as! NSMutableArray
        let srchLead : NSPredicate!
        srchLead  = NSPredicate(format:"(SELF.leadName contains [cd] %@)",leadName)
        tDataArray.filterUsingPredicate(srchLead)
        print(tDataArray)
        return tDataArray
    }
    
}
