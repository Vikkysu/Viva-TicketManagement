//
//  PropertySearchResultModel.swift
//  XomeRestClient
//
//  Created by David Parton on 12/17/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class PropertySearchResultModel: Mappable {
    public var pagingId: String?
    public var pageIndex: Int?
    public var pageCount: Int?
    public var totalCount: Int = 0
    public var disclaimers: [String]?

    public var items = [PropertyModel]()

    public init() {

    }

    required public init?(_ map: Map) {

    }

    public func mapping(map: Map) {
        pagingId <- map["id"]
        pageIndex <- map["page"]
        pageCount <- map["pageCount"]
        totalCount <- map["totalCount"]
        items <- map["items"]
        disclaimers <- map["disclaimers"]
    }
}
