//
//  MakeAnOfferRequestModel.swift
//  XomeRestClient
//
//  Created by Shivakumar Chandramouli on 2/8/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class MakeAnOfferRequestModel: Mappable {

    public var listingId: String?
    public var firstName: String?
    public var lastName: String?
    public var email: String?
    public var phone: String?
    public var offerAmount: String?
    public var comments: String?
    
    public init() {
        
    }
    
    required public init?(_ map: Map) {
        
    }
    
    public func mapping(map: Map) {
        
        listingId <- map["listingId"]
        firstName <- map["firstName"]
        lastName <- map["lastName"]
        email <- map["email"]
        phone <- map["phone"]
        comments <- map["comments"]
    }
}
