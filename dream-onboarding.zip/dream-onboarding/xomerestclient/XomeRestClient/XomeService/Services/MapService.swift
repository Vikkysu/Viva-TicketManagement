//
//  MapService.swift
//  XomeRestClient
//
//  Created by Vikas on 3/22/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import PromiseKit
import ObjectMapper
import CoreLocation
import MapKit
import Typhoon

public extension XomeService {

    /**
     Fetch points of interest search results

     - parameter types: Array of integer values for POI types to fetch
     - parameter searchArea: A tuple of the northeast and southwest coordinates for the search area (bounding box)
     - returns: A Promise object representing the search results
     */
    public func pointsOfInterestResults(types: [Int], searchArea: (ne: CLLocationCoordinate2D, sw: CLLocationCoordinate2D)) -> Promise<[POITypeResultsModel]> {
        if types.count == 0 { return Promise([]) }

        let path = environment.webURL()!.URLByAppendingPathComponent("include/ajax/mapsearch/getpoi.aspx").absoluteString

        let params = [
            "bypass":"1",
            "types": types.map{String($0)}.joinWithSeparator(","),
            "swLat": String(searchArea.sw.latitude),
            "swLong": String(searchArea.sw.longitude),
            "neLat": String(searchArea.ne.latitude),
            "neLong": String(searchArea.ne.longitude)]

        return operationFactory.promise(path: path, queryParameters: params, bodyData: nil).recover { _ in
            return []
        }
    }

    private static var cachedMapToken: PropertyDirectionMapModel!
    public func mapToken() -> Promise<PropertyDirectionMapModel> {
        if XomeService.cachedMapToken != nil {
            return Promise(XomeService.cachedMapToken)
        }

        let path = "http://api.xome.com/v1/dmptokens"
        let params = [
            "format": "json",
            "wsapikey": "28c0b84aee0114bb96148e77f80ba04c"
        ]
        return operationFactory.promise(path: path, queryParameters: params, bodyData: nil).then { (token: PropertyDirectionMapModel) -> PropertyDirectionMapModel in
            XomeService.cachedMapToken = token
            return token
        }
    }

    public func layer(types: [PropertyMapLayerType],
        region: MKCoordinateRegion,
        imageSize: CGSize,
        zoomLevel: Int,
        mapToken: String)
        -> Promise<UIImage?>
    {
        let configs = mapLayerData.filter(types, zoomLevel: zoomLevel)
        if configs.count == 0 {
            return Promise(nil)
        }

        let path = "http://parcelstream.com/GetMap.aspx"

        // calc bounding box
        let halfLatDelta = region.span.latitudeDelta / 2.0
        let halfLonDelta = region.span.longitudeDelta / 2.0
        let northEast = CLLocationCoordinate2D(latitude: region.center.latitude + halfLatDelta,
            longitude: region.center.longitude + halfLonDelta)
        let southWest = CLLocationCoordinate2D(latitude: region.center.latitude - halfLatDelta,
            longitude: region.center.longitude - halfLonDelta)
        let boundingBox = (northEast, southWest)
        let bbox = "\(boundingBox.1.longitude),\(boundingBox.1.latitude),\(boundingBox.0.longitude),\(boundingBox.0.latitude)"

        let layers = configs.map { $0.toRESTLayerIdentifierWithZoomLevel(zoomLevel) }.joinWithSeparator(",")
        let sld = configs.map { $0.toRESTStyleIdentifierWithZoomLevel(zoomLevel) }.joinWithSeparator(",")

        let params = [
            "uid": "101164_294277",
            "width": String(Int(imageSize.width)),
            "height": String(Int(imageSize.height)),
            "SS_CANDY": mapToken,
            "bbox": bbox,
            "layers": layers,
            "sld": sld
        ]

        return imageService.imageForURL(NSURL(string: path)!, params: params)
    }

    public func boundary(model: PropertySearchModel) -> Promise<BoundaryModel> {
        enum Error: ErrorType {
            case NoBoundaries
        }
        guard let value = model.boundaryRequestValue,
              let type = model.boundaryRequestName
              else { return Promise(error: Error.NoBoundaries) }

        let params : [String:String] = [ "bypass": "1", "type": type, "state": model.state ?? "", "val": value ]
        let path = environment.webURL()!.URLByAppendingPathComponent("include/ajax/mapsearch/getboundary.aspx").absoluteString
        return operationFactory.promise(path: path, queryParameters: params, bodyData: nil).then { (models: [PolygonPointList]) -> BoundaryModel in
            if models.count == 0 { throw Error.NoBoundaries }
            return BoundaryModel(polygonPoints: models)
        }
    }
}