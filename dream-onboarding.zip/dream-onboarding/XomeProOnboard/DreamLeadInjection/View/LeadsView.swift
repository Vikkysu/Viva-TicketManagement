//
//  LeadsView.swift
//  ProfessionalTools
//
//  Created by MacMini5 on 21/10/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class LeadsView: NSObject, UITableViewDelegate, UITableViewDataSource {
    
    var bInitCntlr          :Bool!
    var cgScreenWidth       :CGFloat!
    var cgScreenHeight      :CGFloat!
    var tableValues         :NSMutableArray!
    var screenDimensions    :CGRect!

    var btnXheader      :UIButton!
    var lblHeader       :UILabel!
    var lblHeaderRight  :UILabel!
    var txtSearchBox    :UITextField!
    var btnSearchFind   :UIButton!
    var btnHome         :UIButton!
    var btnSearch       :UIButton!
    var btnAlerts       :UIButton!
    var btnAgents       :UIButton!
    var btnMore         :UIButton!
    
    var vwMain          :UIView!
    var vwHeader        :UIView!
    //var vwHeader      :LeadsHeaderWidget!
    var segOperations   :UISegmentedControl!
    var vwSearch        :UIView!
    var searchBar       :UISearchBar!
    
    var tblDataView     :UITableView!
    var vwController    :UIViewController!
    
    var vwFooterMenu    :UIView!
    
    func loadLeadsUI(inViewController:UIViewController, inDataArray:NSMutableArray, isInitialController:Bool){
        
        self.bInitCntlr = isInitialController
        self.getScreenDimensions()
        self.createUIElements()
        self.setProperties(inDataArray)
        self.addElements2UI(inViewController)
    }
    
    func getScreenDimensions(){
        
        let screenDimensions = UIScreen.mainScreen().bounds
        cgScreenWidth        = screenDimensions.width
        cgScreenHeight       = screenDimensions.height
        print(cgScreenWidth)
    }
    
    func centreX(inWidth: CGFloat)->CGFloat{
        
        let tWidth:CGFloat  = cgScreenWidth - CGFloat(inWidth)
        let pX: CGFloat     = tWidth/2
        
        return pX
    }
    
    func centreY(inHeight: CGFloat)->CGFloat{
        
        let tHeight:CGFloat  = cgScreenHeight - CGFloat(inHeight)
        let pY: CGFloat      = tHeight/2
        
        return pY
    }
    
    func convert2Pixels(points:CGFloat)->CGFloat{
    
        let pixels  :CGFloat = points * 96 / 72
        return pixels
    }
    
    func createUIElements(){
        
        let hdrVwHeight :CGFloat = self.convert2Pixels(65)
        let hdrWidth    :CGFloat = self.convert2Pixels(46)
        let hdrHeight   :CGFloat = self.convert2Pixels(22)
        let hdRtWidth   :CGFloat = self.convert2Pixels(44)
        let hdRtHeight  :CGFloat = self.convert2Pixels(18)
        let hdRtX       :CGFloat = cgScreenWidth - hdRtWidth //constraint set to hdRtWidth
        let hdRTY       :CGFloat = self.convert2Pixels(34)
        let hdrX        :CGFloat = self.centreX(hdrWidth)
        let hdrY        :CGFloat = self.convert2Pixels(31)
        let segMenuItems         = ["Active", "Archived"]
        let segWidth    :CGFloat = cgScreenWidth - 100 //constraint set to 100
        let segHeight   :CGFloat = self.convert2Pixels(30)
        let segX        :CGFloat = self.centreX(325)
        let segY        :CGFloat = hdrVwHeight+10
        let searchY     :CGFloat = segY+segHeight+10
        let findX       :CGFloat = cgScreenWidth-60
        let tblY        :CGFloat = self.convert2Pixels(searchY+10)
        let ftHeight    :CGFloat = self.convert2Pixels(50)
        let ftY         :CGFloat = cgScreenHeight-ftHeight
        let ftBtnWidth  :CGFloat = cgScreenWidth/5
        
        vwMain              = UIView(frame:CGRectMake(0, 0, cgScreenWidth, cgScreenHeight))
        vwHeader            = UIView(frame:CGRectMake(0, 0, cgScreenWidth, hdrVwHeight))
        btnXheader          = UIButton(frame:CGRectMake(0, hdrY, 33, 33))
        lblHeader           = UILabel(frame:CGRectMake(hdrX, hdrY, hdrWidth, hdrHeight))
        lblHeaderRight      = UILabel(frame:CGRectMake(hdRtX, hdRTY, hdRtWidth, hdRtHeight))
        segOperations       = UISegmentedControl(items: segMenuItems)
        segOperations.frame = CGRectMake(segX, segY	, segWidth, segHeight)
        searchBar           = UISearchBar(frame:CGRectMake(0, searchY, findX, 33))
        btnSearchFind       = UIButton(frame:CGRectMake(findX, searchY, 60, 33))
        tblDataView         = UITableView()
        tblDataView.frame   = CGRectMake(0, tblY, cgScreenWidth, cgScreenHeight - tblY - 10)
        vwFooterMenu        = UIView(frame:CGRectMake(0, ftY, cgScreenWidth, ftHeight))
        btnHome             = UIButton(frame:CGRectMake(0, 0, ftBtnWidth, ftHeight))
        btnSearch           = UIButton(frame:CGRectMake(ftBtnWidth,   0, ftBtnWidth, ftHeight))
        btnAlerts           = UIButton(frame:CGRectMake(2*ftBtnWidth, 0, ftBtnWidth, ftHeight))
        btnAgents           = UIButton(frame:CGRectMake(3*ftBtnWidth, 0, ftBtnWidth, ftHeight))
        btnMore             = UIButton(frame:CGRectMake(4*ftBtnWidth, 0, ftBtnWidth, ftHeight))
        print(ftBtnWidth)
    }
    
    func setProperties(inDataArray:NSMutableArray){
        
        //setup header
        vwHeader.backgroundColor        = UIColor(red: 217/255, green: 2/255, blue: 9/255, alpha: 1)
        let imgBtnImage     :UIImage    = UIImage(named:"btnSave3.png")!
        btnXheader.setImage(imgBtnImage, forState: .Normal)
        btnXheader.addTarget(self, action: Selector("back"), forControlEvents: UIControlEvents.TouchUpInside)
        
        lblHeader.text              = "Leads"
        lblHeaderRight.text         = "Create"
        
        let headerFont      :UIFont = UIFont(name: "MuseoSansRounded-300", size: 18.0)!
        let rtHeaderFont    :UIFont = UIFont(name: "MuseoSansRounded-300", size: 15.0)!
        lblHeader.font              = headerFont
        lblHeaderRight.font         = rtHeaderFont

        lblHeader.textColor         = UIColor.whiteColor()
        lblHeaderRight.textColor    = UIColor.whiteColor()
        
        //setup segmented menu
        segOperations.selectedSegmentIndex  = 0
        segOperations.tintColor             = UIColor(red: 217/255, green: 2/255, blue: 9/255, alpha: 1)
        segOperations.backgroundColor       = UIColor.whiteColor()
        
        //setup search bar
        searchBar.backgroundColor       = UIColor(red: 200/255, green: 200/255, blue: 200/255, alpha: 1)
        searchBar.placeholder           = "Search"
        btnSearchFind.setTitle("Find", forState: .Normal)
        btnSearchFind.titleLabel?.font  = rtHeaderFont
        btnSearchFind.backgroundColor   = UIColor(red: 200/255, green: 200/255, blue: 200/255, alpha: 1)
        
        //ready data for table view
        tableValues             = inDataArray
        tblDataView.dataSource  = self
        tblDataView.delegate    = self
        
        //setup footer menu
        vwFooterMenu.backgroundColor    = UIColor(red: 245/255, green: 245/255, blue: 245/255, alpha: 1)
        btnHome.backgroundColor         = UIColor.clearColor()
        btnSearch.backgroundColor       = UIColor.clearColor()
        btnAlerts.backgroundColor       = UIColor.clearColor()
        btnAgents.backgroundColor       = UIColor.clearColor()
        btnMore.backgroundColor         = UIColor.clearColor()
        
        btnHome.setTitle  ("Home",   forState: .Normal)
        btnSearch.setTitle("Search", forState: .Normal)
        btnAlerts.setTitle("Alerts", forState: .Normal)
        btnAgents.setTitle("Agents", forState: .Normal)
        btnMore.setTitle  ("More",   forState: .Normal)
        
        let footerFont    :UIFont   = UIFont(name: "MuseoSansRounded-300", size: 12)!
        btnHome.titleLabel?.font    = footerFont
        btnSearch.titleLabel?.font  = footerFont
        btnAlerts.titleLabel?.font  = footerFont
        btnAgents.titleLabel?.font  = footerFont
        btnMore.titleLabel?.font    = footerFont
        
        btnHome.setTitleColor   (UIColor.blackColor(), forState: .Normal)
        btnSearch.setTitleColor (UIColor.blackColor(), forState: .Normal)
        btnAlerts.setTitleColor (UIColor.blackColor(), forState: .Normal)
        btnAgents.setTitleColor (UIColor.blackColor(), forState: .Normal)
        btnMore.setTitleColor   (UIColor.blackColor(), forState: .Normal)
        
        //let image = UIImageCustom().getImageFromString("homeIcon.png") as UIImage?
        //btnHome.setImage(image, forState: .Normal)
    }
    
    func back(){
        
        //vwController.dismissViewControllerAnimated(true, completion: nil)
        vwController.navigationController?.popViewControllerAnimated(true)
    }
    
    func addElements2UI(inController:UIViewController){
        
        vwController = inController
        vwController.view.addSubview(vwMain)
        //vwHeader = LeadsHeaderWidget()
        //vwHeader.loadAndRenderWidget(screenDimensions)
        vwMain.addSubview(vwHeader)
        vwMain.addSubview(segOperations)
        vwMain.addSubview(searchBar)
        vwMain.addSubview(tblDataView)
        vwMain.addSubview(btnSearchFind)
        vwMain.addSubview(vwFooterMenu)
        

        vwHeader.addSubview(btnXheader)
        vwHeader.addSubview(lblHeader)
        vwHeader.addSubview(lblHeaderRight)
        
        vwFooterMenu.addSubview(btnHome)
        vwFooterMenu.addSubview(btnSearch)
        vwFooterMenu.addSubview(btnAlerts)
        vwFooterMenu.addSubview(btnAgents)
        vwFooterMenu.addSubview(btnMore)
    }
    
    func touchesBegan(touches: NSSet, withEvent event: UIEvent) {
        vwController.view.endEditing(true)
        btnSearchFind.resignFirstResponder()
    }
    func touchesDetermined(){
        vwController.view.endEditing(true)
        btnSearchFind.resignFirstResponder()

    }
    
    
    
    //////////////////////////////////////////////////////////////////////
    //TableView delegates for creating table size, populating and actions
    //////////////////////////////////////////////////////////////////////
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        let currentDictionary : NSMutableDictionary = tableValues.objectAtIndex(indexPath.row) as! NSMutableDictionary
        let leadName           :String = (currentDictionary.objectForKey("leadName") as? String)!
        let leadDetailObj = vwController.storyboard!.instantiateViewControllerWithIdentifier("LeadDetailViewController")as! LeadDetailViewController
       leadDetailObj.leadName = leadName
        vwController.navigationController?.pushViewController(leadDetailObj, animated: true)
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        
        return tableValues.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat{
        return 110
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
        
        //variable type is inferred
        var cell = tableView.dequeueReusableCellWithIdentifier("CELL")

        if cell == nil {
            cell = UITableViewCell(style: UITableViewCellStyle.Value1, reuseIdentifier: "CELL")
            let leadStatusView : UIImageView = UIImageView(frame: CGRectMake(15, 17, 15, 15))
            leadStatusView.image             = UIImageCustom().getImageFromString("green.png")
            leadStatusView.tag               = 6
            
            let leadSource  :UILabel    = UILabel(frame: CGRectMake(40, 15, 250, 20))
            leadSource.textColor        = UIColor(red: 61/255, green: 148/255, blue: 232/255, alpha: 1)
            leadSource.font             = UIFont.systemFontOfSize(14)
            leadSource.tag              = 1
            
            let leadType : UILabel      = UILabel(frame: CGRectMake(100, 40, 250, 20))
            leadType.textColor          = UIColor(red: 160/255, green: 160/255, blue: 160/255, alpha: 1)
            leadType.font               = UIFont.systemFontOfSize(18)
            leadType.tag                = 2
            
            let leadName : UILabel      = UILabel(frame: CGRectMake(40, 40, 250, 20))
            leadName.textColor          = UIColor(red: 32/255, green: 32/255, blue: 32/255, alpha: 1)
            leadName.font               = UIFont.boldSystemFontOfSize(18)
            leadName.tag                = 3
            
            let leadLegend : UILabel    = UILabel(frame: CGRectMake(40, 65, 300, 20))
            leadLegend.textColor        = UIColor(red: 240/255, green: 90/255, blue: 94/255, alpha: 1)
            leadLegend.font             = UIFont.systemFontOfSize(15)
            leadLegend.tag              = 4
            
            let lblTime : UILabel       = UILabel(frame: CGRectMake(vwController.view.frame.size.width-80, 15, 70, 20))
            lblTime.textColor           = UIColor(red: 194/255, green: 194/255, blue: 194/255, alpha: 1)
            lblTime.font                = UIFont.systemFontOfSize(12)
            lblTime.textAlignment       = .Right
            lblTime.tag                 = 5
            
            cell?.addSubview(leadSource)
            cell?.addSubview(leadType)
            cell?.addSubview(leadName)
            cell?.addSubview(leadLegend)
            cell?.addSubview(lblTime)
            cell?.addSubview(leadStatusView)
        }
        
        let currentDictionary : NSMutableDictionary = tableValues.objectAtIndex(indexPath.row) as! NSMutableDictionary
        let lblSource   :UILabel = cell?.viewWithTag(1) as! UILabel
        let lblType     :UILabel = cell?.viewWithTag(2) as! UILabel
        let lblName     :UILabel = cell?.viewWithTag(3) as! UILabel
        let lblLegend   :UILabel = cell?.viewWithTag(4) as! UILabel
        
        let lblTimeSince    :UILabel     = cell?.viewWithTag(5) as! UILabel
        let imgLeadStatus   :UIImageView = cell?.viewWithTag(6) as! UIImageView
        
        lblSource.text          = currentDictionary.objectForKey("leadSource") as? String
        lblTimeSince.text       = currentDictionary.objectForKey("timeSince") as? String
        lblName.text            = currentDictionary.objectForKey("leadName") as? String
        lblName.text            = lblName.text!+" - "
        
        lblName.sizeToFit()
        lblType.frame.origin.x  = lblName.frame.origin.x + lblName.frame.size.width+3
        lblType.text            = currentDictionary.objectForKey("leadType") as? String
        lblLegend.text          = currentDictionary.objectForKey("leadLegend") as? String
        
        let statusValue : Bool  = currentDictionary.objectForKey("status") as! Bool
        
        if statusValue == true{
            imgLeadStatus.hidden = false
        }else{
            imgLeadStatus.hidden = true
        }
        
        let lblLine = UILabel(frame: CGRectMake(0, 110, cgScreenWidth, 1))
        lblLine.text = ""
        lblLine.backgroundColor = UIColor.grayColor()
        cell!.addSubview(lblLine)
        
        return cell!
    }
    
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool{
        return true
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath){
        
    }
    
    func tableView(tableView: UITableView, editActionsForRowAtIndexPath indexPath: NSIndexPath) -> [UITableViewRowAction]?{
        
        let archiveAction : UITableViewRowAction = UITableViewRowAction(style: UITableViewRowActionStyle.Normal, title: "Archive") { (action, indexPath) -> Void in
            print("Fav is touched")
        }
        
        archiveAction.backgroundColor = UIColor(red: 146/255, green: 146/255, blue: 146/255, alpha: 1)
        
        let referAction : UITableViewRowAction = UITableViewRowAction(style: UITableViewRowActionStyle.Normal, title: "Refer") { (action, indexPath) -> Void in
            print("refer is touched")
        }
        
        referAction.backgroundColor = UIColor(red: 213/255, green: 213/255, blue: 213/255, alpha: 1)
        
        if indexPath.row%2 == 0 {
            return [referAction,archiveAction]
        }else {
            let declineAction : UITableViewRowAction = UITableViewRowAction(style: UITableViewRowActionStyle.Normal, title: "Decline") { (action, indexPath) -> Void in
                print("Delete is touched")
            }
            declineAction.backgroundColor = UIColor(red: 186/255, green: 186/255, blue: 186/255, alpha: 1)
            return [referAction,declineAction,archiveAction]
        }
    }
}
