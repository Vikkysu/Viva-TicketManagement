//
//  PropertyPhotosModel.swift
//  XomeRestClient
//
//  Created by Xome on 3/7/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import UIKit
import ObjectMapper
import PromiseKit

public class PropertyPhotosModel : Mappable {
    
    public var mediaUrl: NSURL?
    
    required public init?(_ map: Map) {
        
    }
    
    public func mapping(map: Map) {
        
        mediaUrl <- (map["mediaUrl"], URLTransform())
    }
}