//
//  PropertyDetailsListingPriceHistoryModel.swift
//  XomeRestClient
//
//  Created by Xome on 2/29/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class PropertyDetailsListingPriceHistoryModel: Mappable {
    
    public var orgId: String?
    public var price: Double?
    public var changeDate: String?
    public var description: String?
    public var changeRawDate: String?
    
    required public init?(_ map: Map) {
        
    }
    
    public func mapping(map: Map) {
        
        orgId <- map["OrgId"]
        price <- map["Price"]
        changeDate <- map["ChangeDate"]
        description <- map["Description"]
        changeRawDate <- map["ChangeDateRaw"]
    }
}