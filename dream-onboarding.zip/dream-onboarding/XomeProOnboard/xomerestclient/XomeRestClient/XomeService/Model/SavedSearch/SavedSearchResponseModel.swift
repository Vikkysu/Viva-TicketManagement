//
//  SavedSearchResponseModel.swift
//  XomeRestClient
//
//  Created by Xome on 1/27/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class SavedSearchResponseModel: Mappable {
    
    public var personId: String?
    public var savedSearchesKey: String?
    
    required public init?(_ map: Map) {
        
    }
    
    public func mapping(map: Map) {
        
        personId <- map["PersonId"]
        savedSearchesKey <- map["SavedSearchesKey"]
    }
}
