//
//  DPBrokerProfilePhotoTableViewCell.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/15/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrokerProfilePhotoTableViewCell: UITableViewCell {
    override init(style: UITableViewCellStyle, reuseIdentifier: String!)
    {
        super.init(style: UITableViewCellStyle.Value1, reuseIdentifier: reuseIdentifier)

        let profilePhoto : UIImageView = UIImageView()
        profilePhoto.tag = 150
        profilePhoto.image = UIImageCustom().getImageFromString("profilePhoto")
        self.addSubview(profilePhoto)
       
        var labelTextState : UILabel
        labelTextState = UILabel()
        labelTextState.textAlignment = .Center
        labelTextState.tag=142
        labelTextState.text = "ADD A PROFILE PHOTO"
        labelTextState.font = UIFont(name: MuseoSansRounded100Font, size: 11.0)
        self.addSubview(labelTextState)
        
        profilePhoto.snp_makeConstraints {(make) -> Void in
            make.centerY.equalTo(self).offset(0)
            make.centerX.equalTo(self).offset(0)
            make.width.equalTo(100)
            make.height.equalTo(100)
        }
        
        labelTextState.snp_makeConstraints {(make) -> Void in
            make.bottom.equalTo(self).offset(-10)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
        }
        
        let separatorLine: UIView = UIView()
        separatorLine.backgroundColor = UIColor.baoTableBorderColor()
        self.addSubview(separatorLine)
        
        separatorLine.snp_makeConstraints {(make) -> Void in
            make.bottom.equalTo(self).offset(-1)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
            make.height.equalTo(1)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setSelected(selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
    
}
