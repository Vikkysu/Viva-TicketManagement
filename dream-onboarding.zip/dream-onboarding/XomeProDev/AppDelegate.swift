//
//  AppDelegate.swift
//  XomeProDev
//
//  Created by Vikas on 10/28/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit
import XomeProOnboard

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        window = UIWindow(frame: UIScreen.mainScreen().bounds)
        window!.rootViewController = DPSignInViewController()
        window!.makeKeyAndVisible()
        
        return true
    }



}

