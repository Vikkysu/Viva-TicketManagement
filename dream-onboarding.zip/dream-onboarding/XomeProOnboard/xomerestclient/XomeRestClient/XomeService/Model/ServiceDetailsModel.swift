//
//  ServiceDetailsModel.swift
//  XomeRestClient
//
//  Created by David Parton on 3/13/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class ServiceDetailsModel: Mappable {
    public var activeListingCount: UInt
    public var activeListingCountFormatted: String
    public var brContactEmailAddress: String
    public var brContactName: String
    public var brContactPhone: String
    public var copyright: String
    public var csContactName: String
    public var csMessage: String
    public var csPhoneMessage: String
    public var displayName: String
    public var id: UInt
    public var legalDisclaimer: String
    public var name: String
    public var soldListingCount: UInt
    public var soldListingCountFormatted: String
    public var totalListingCount: UInt
    public var totalListingCountFormatted: String
    public var totalListingLastUpdatedDtm: String
    public var totalListingLastUpdatedSinceEpoch: Double

    required public init?(_ map: Map) {
        activeListingCount = map["activeListingCount"].valueOrFail()
        activeListingCountFormatted = map["activeListingCountFormatted"].valueOrFail()
        brContactEmailAddress = map["brContactEmailAddress"].valueOrFail()
        brContactName = map["brContactName"].valueOrFail()
        brContactPhone = map["brContactPhone"].valueOrFail()
        copyright = map["copyright"].valueOrFail()
        csContactName = map["csContactName"].valueOrFail()
        csMessage = map["csMessage"].valueOrFail()
        csPhoneMessage = map["csPhoneMessage"].valueOrFail()
        displayName = map["displayName"].valueOrFail()
        id = map["id"].valueOrFail()
        legalDisclaimer = map["legalDisclaimer"].valueOrFail()
        name = map["name"].valueOrFail()
        soldListingCount = map["soldListingCount"].valueOrFail()
        soldListingCountFormatted = map["soldListingCountFormatted"].valueOrFail()
        totalListingCount = map["totalListingCount"].valueOrFail()
        totalListingCountFormatted = map["totalListingCountFormatted"].valueOrFail()
        totalListingLastUpdatedDtm = map["totalListingLastUpdatedDtm"].valueOrFail()
        totalListingLastUpdatedSinceEpoch = map["totalListingLastUpdatedSinceEpoch"].valueOrFail()
        if !map.isValid { return nil }
    }

    public func mapping(map: Map) {
        activeListingCount <- map["activeListingCount"]
        activeListingCountFormatted <- map["activeListingCountFormatted"]
        brContactEmailAddress <- map["brContactEmailAddress"]
        brContactName <- map["brContactName"]
        brContactPhone <- map["brContactPhone"]
        copyright <- map["copyright"]
        csContactName <- map["csContactName"]
        csMessage <- map["csMessage"]
        csPhoneMessage <- map["csPhoneMessage"]
        displayName <- map["displayName"]
        id <- map["id"]
        legalDisclaimer <- map["legalDisclaimer"]
        name <- map["name"]
        soldListingCount <- map["soldListingCount"]
        soldListingCountFormatted <- map["soldListingCountFormatted"]
        totalListingCount <- map["totalListingCount"]
        totalListingCountFormatted <- map["totalListingCountFormatted"]
        totalListingLastUpdatedDtm <- map["totalListingLastUpdatedDtm"]
        totalListingLastUpdatedSinceEpoch <- (map["totalListingLastUpdatedSinceEpoch"], TransformOf<Double, Double>(
            // This nuggest found in Afx. server sends back info in CST, convert to UTC
            fromJSON: { (d: Double?) -> Double? in
                return d! + 3600 * 5
            }, toJSON: { (d: Double?) -> Double? in
                return d! - 3600 * 5
            })
        )
    }
}
