//
//  DPRedirectToXomeAppViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 9/18/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPRedirectToXomeAppViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backgroundImg: UIImageView =  UIImageView()
        backgroundImg.image = UIImageCustom().getImageFromString("backgroundImage")
        self.view.addSubview(backgroundImg)
        
        backgroundImg.snp_makeConstraints { (make) -> Void in
            make.edges.equalTo(self.view).inset(UIEdgeInsetsMake(0, 0, 0, 0))
        }
        
        let dimmUIView: UIView = UIView()
        dimmUIView.backgroundColor = UIColor.baoTwilightBlue20Color()
        self.view.addSubview(dimmUIView)
        
        dimmUIView.snp_makeConstraints { (make) -> Void in
            make.edges.equalTo(self.view).inset(UIEdgeInsetsMake(0, 0, 0, 0))
        }

        let closeButton: UIButton = UIButton()
        closeButton.setBackgroundImage(UIImageCustom().getImageFromString("closeButtonImage"), forState: .Normal)
        dimmUIView.addSubview(closeButton)
        closeButton.addTarget(self, action: "closeView:", forControlEvents: .TouchUpInside)
        
        let xomeHeader: UILabel = UILabel()
        xomeHeader.text = "BUYERS AND SELLERS"
        xomeHeader.numberOfLines=0
        xomeHeader.font = UIFont(name: MuseoSansRounded300Font, size: 25)
        xomeHeader.textColor = UIColor.whiteColor()
        dimmUIView.addSubview(xomeHeader)
        
        let xomeAddText: UILabel = UILabel()
        xomeAddText.text = "If you are not working with an agent then use Xome app to search for listings and find the right agent for you"
        xomeAddText.numberOfLines=0
        xomeAddText.textAlignment = .Center
        xomeAddText.font = UIFont(name: MuseoSansRounded300Font, size: 18)
        xomeAddText.textColor = UIColor.whiteColor()
        dimmUIView.addSubview(xomeAddText)

        let xomeAddSubText: UILabel = UILabel()
        xomeAddSubText.text = "Some of the many benefits of using Xome"
        xomeAddSubText.numberOfLines=0
        xomeAddSubText.font = UIFont(name: MuseoSansRounded300Font, size: 13)
        xomeAddSubText.textColor = UIColor.whiteColor()
        dimmUIView.addSubview(xomeAddSubText)
        
        let currencyImage: UIImageView = UIImageView()
        currencyImage.image = UIImageCustom().getImageFromString("xomeMoney")
        dimmUIView.addSubview(currencyImage)
        
        let currencyText: UILabel = UILabel()
        currencyText.text = "AGENTS THAT GET\nYOU THE BEST PRICE"
        currencyText.numberOfLines=0
        currencyText.textAlignment = .Center
        currencyText.font = UIFont(name: MuseoSansRounded300Font, size: 9)
        currencyText.textColor = UIColor.whiteColor()
        dimmUIView.addSubview(currencyText)

        let agentImage: UIImageView = UIImageView()
        agentImage.image = UIImageCustom().getImageFromString("contactsCopy")
        dimmUIView.addSubview(agentImage)
        
        let agentText: UILabel = UILabel()
        agentText.text = "AGENTS THAT\nCOMPETE FOR YOU"
        agentText.numberOfLines=0
        agentText.textAlignment = .Center
        agentText.font = UIFont(name: MuseoSansRounded300Font, size: 9)
        agentText.textColor = UIColor.whiteColor()
        dimmUIView.addSubview(agentText)
        
        let callcenterImage: UIImageView = UIImageView()
        callcenterImage.image = UIImageCustom().getImageFromString("conciergeCall")
        dimmUIView.addSubview(callcenterImage)
        
        let callcenterText: UILabel = UILabel()
        callcenterText.text = "24/7\nCONCIERGE"
        callcenterText.numberOfLines=0
        callcenterText.textAlignment = .Center
        callcenterText.font = UIFont(name: MuseoSansRounded300Font, size: 9)
        callcenterText.textColor = UIColor.whiteColor()
        dimmUIView.addSubview(callcenterText)
        
        let xomeAppStoreImage: UIButton = UIButton()
        xomeAppStoreImage.setBackgroundImage(UIImageCustom().getImageFromString("xomeAppStore"), forState: .Normal)
        dimmUIView.addSubview(xomeAppStoreImage)
        xomeAppStoreImage.addTarget(self, action: "launchXomeAppStore:", forControlEvents: .TouchUpInside)
        
        closeButton.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(dimmUIView).offset(30)
            make.leading.equalTo(dimmUIView).offset(20)
            make.height.equalTo(24)
            make.width.equalTo(24)
        }
        
        xomeAddText.snp_makeConstraints { (make) ->Void in
            make.centerY.equalTo(dimmUIView).offset(0)
            make.leading.equalTo(dimmUIView).offset(10)
            make.trailing.equalTo(dimmUIView).offset(-10)
        }
        
        xomeHeader.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(dimmUIView).offset(100)
            make.centerX.equalTo(dimmUIView)
        }
        
        xomeAddSubText.snp_makeConstraints { (make) ->Void in
            make.bottom.equalTo(xomeAddText).offset(30)
            make.centerX.equalTo(dimmUIView)
        }
        
        agentImage.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(xomeAddSubText).offset(30)
            make.centerX.equalTo(dimmUIView)
            make.height.equalTo(30)
            make.width.equalTo(30)
        }
        
        agentText.snp_makeConstraints { (make) ->Void in
            make.bottom.equalTo(agentImage).offset(30)
            make.centerX.equalTo(agentImage)
        }

        currencyImage.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(xomeAddSubText).offset(30)
            make.leading.equalTo(dimmUIView).offset(40)
            make.height.equalTo(30)
            make.width.equalTo(30)
            
        }
        
        currencyText.snp_makeConstraints { (make) ->Void in
            make.bottom.equalTo(currencyImage).offset(30)
            make.centerX.equalTo(currencyImage)
        }

        
        callcenterImage.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(xomeAddSubText).offset(30)
            make.trailing.equalTo(dimmUIView).offset(-40)
            make.height.equalTo(30)
            make.width.equalTo(30)
        }
        
        callcenterText.snp_makeConstraints { (make) ->Void in
            make.bottom.equalTo(callcenterImage).offset(30)
            make.centerX.equalTo(callcenterImage)
        }

        
        xomeAppStoreImage.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(agentText).offset(50)
            make.centerX.equalTo(dimmUIView).offset(0)
            make.height.equalTo(58)
            make.width.equalTo(203)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    func closeView(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil);
    }
    @IBAction func launchXomeAppStore(sender: AnyObject) {
        //launch the appstore with xome id
        UIApplication.sharedApplication().openURL(NSURL(string: "https://itunes.apple.com/us/app/xome-real-estate-buy-or-sell/id985489724?mt=8")!)
    }
}
