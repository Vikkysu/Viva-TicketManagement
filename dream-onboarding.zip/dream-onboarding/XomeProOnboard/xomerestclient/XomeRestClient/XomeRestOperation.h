//
//  XomeRestOperation.h
//  Xome
//
//  Created by David Parton on 6/26/15.
//  Copyright (c) 2015 Xome. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol XomeRestOperation;

NS_ASSUME_NONNULL_BEGIN

typedef void (^XomeRestOperationSuccessHandler)(NSData* data);
typedef void (^XomeRestOperationErrorHandler)(NSError* error);
typedef void (^XomeRestOperationFinallyHandler)(id<XomeRestOperation> operation);

@protocol XomeRestOperation <NSObject>

/** Attach a success handler to the operation for processing the NSData response
 * @return Self to allow method chaining
 */
- (instancetype)handleSuccess:(XomeRestOperationSuccessHandler)handler;
/** Attach an error handler to the operation.
 * @return Self to allow method chaining
 */
- (instancetype)handleError:(XomeRestOperationErrorHandler)handler;
/** Attach a handler that runs after every success or fail 
 * @return Self to allow for method chaining
 */
- (instancetype)finally:(XomeRestOperationFinallyHandler)handler;
/** Mark the operation handlers as requiring callback on the main UI thread
 * @return Self to allow method chaining
 */
- (instancetype)callbackOnMainThread;

/** Start the operation */
- (void)start;
/** Mark the operation as failed. This is useful in a success handler when the information received does not match an expected model. */
- (void)fail:(NSError*)error;

@end

NS_ASSUME_NONNULL_END
