//
//  XomeRestPropertyDataProvider.h
//  Xome
//
//  Created by Vikas on 8/22/15.
//  Copyright (c) 2015 Xome. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "XomeRestOperationFactory.h"

@interface XomeRestPropertyDataProvider : NSObject
@property (nonatomic) id<XomeRestOperationFactory> operationFactory;

typedef void (^XomeRestPropertyDataProviderHandler)(id objectOrArray, NSError* error);
- (void)singlePropertyModel:(Class)modelClass listingKey:(NSString*)listingKey handler:(XomeRestPropertyDataProviderHandler)handler;
- (void)singlePropertyFields:(NSString*)fields listingKey:(NSString*)listingKey handler:(XomeRestPropertyDataProviderHandler)handler;
- (void)searchPropertiesModel:(Class)modelClass criteria:(NSDictionary*)criteria handler:(XomeRestPropertyDataProviderHandler)handler;

@end
