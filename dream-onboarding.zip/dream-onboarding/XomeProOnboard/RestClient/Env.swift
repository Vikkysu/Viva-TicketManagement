
protocol Env: class {
    var apiUrl: String { get }
    var apiKey: String { get }
}


class CommonEnv {
    let apiKey = "6DCC4066-8571-4B71-90D1-4512A4CE132A"
    let apiUrl = "Brokerage/"
    
}

/**
Production environment
*/
final class ProdEnv {
}

/**
Staging environment
*/
final class StageEnv: Env {
    let apiKey = "6DCC4066-8571-4B71-90D1-4512A4CE132A"
    let apiUrl = "http://10.29.94.42:80/api/v1/"
}
