//
//  UIFontOptions.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/11/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

var MuseoSansRounded300Font : String = "MuseoSansRounded-300"
var MuseoSansRounded100Font : String = "MuseoSansRounded-100"
var MuseoSansRounded500Font : String = "MuseoSansRounded-500"
var MuseoSansRounded700Font : String = "MuseoSansRounded-700"

class UIFontOptions: NSObject {
    
}

