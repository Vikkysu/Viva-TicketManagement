//
//  CreateAccountViewController.swift
//  ProfessionalTools
//
//  Created by vikascg on 29/09/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class CreateAccountViewController: UITableViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    

    let picker = UIImagePickerController()
    
    @IBOutlet weak var profilePhotoImg: UIImageView!

    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var mobileTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var lastNametextField: UITextField!
    @IBOutlet weak var firstNametextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        picker.delegate = self
        
        let tapGesture = UITapGestureRecognizer(target: self, action: "handleTap:")
        tapGesture.numberOfTapsRequired = 1
        view.addGestureRecognizer(tapGesture)
        
        self.profilePhotoImg.userInteractionEnabled=true
        let tapProfilePhoto = UITapGestureRecognizer(target: self, action: "uploadProfilePhoto:")
        tapProfilePhoto.numberOfTapsRequired = 1
        self.profilePhotoImg.addGestureRecognizer(tapProfilePhoto)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func handleTap(recognizer: UITapGestureRecognizer) {
        
        self.view.endEditing(true)
    }
    
    
    //photo upload functions
    func uploadProfilePhoto(recognizer: UITapGestureRecognizer) {
        print("Upload an photo")
        picker.allowsEditing = false //2
        picker.sourceType = .PhotoLibrary //3
        presentViewController(picker, animated: true, completion: nil)//4
    }
    
    //MARK: Delegates
    func imagePickerController(
        picker: UIImagePickerController,
        didFinishPickingMediaWithInfo info: [String : AnyObject])
    {
        let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage //2
        self.profilePhotoImg.contentMode = .ScaleAspectFit //3
        self.profilePhotoImg.image = chosenImage //4
        dismissViewControllerAnimated(true, completion: nil) //5
    }
    
    func imagePickerControllerDidCancel(picker: UIImagePickerController) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    //textField funcs
    func setProfileObj() -> Bool {
        
        var isDataValid: Bool = true
        
        let profileObj: profileModel! = profileModel()
        
        if (firstNametextField.text != "") {
            profileObj?.firstNameStr = firstNametextField.text
        }
        else
        {
            isDataValid = false
            let alertView = UIAlertView(title: "", message: NSLocalizedString("First Name not found", comment:"First name field cannot be empty"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
            alertView.show()
            return isDataValid
        }
        
        if (lastNametextField.text != "")  {
            profileObj?.lastNameStr = lastNametextField.text
        }
        else
        {
            isDataValid = false

            let alertView = UIAlertView(title: "", message: NSLocalizedString("Last Name not found", comment:"Last name field cannot be empty"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
            alertView.show()
            return isDataValid

        }
        
        if (emailTextField.text != "")  {
            profileObj?.emailStr = emailTextField.text
        }
        else
        {
            isDataValid = false

            let alertView = UIAlertView(title: "", message: NSLocalizedString("Email not found", comment:"Email field cannot be empty"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
            alertView.show()
            return isDataValid

        }
        
        if (mobileTextField.text != "")  {
            profileObj?.mobileNumStr = mobileTextField.text
        }
        else
        {
            isDataValid = false

            let alertView = UIAlertView(title: "", message: NSLocalizedString("Mobile Number not found", comment:"Mobile Number field cannot be empty"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
            alertView.show()
            return isDataValid

        }
        
        if (passwordTextField.text != "")  {
            profileObj?.passwordStr = passwordTextField.text
        }
        else
        {
            isDataValid = false

            let alertView = UIAlertView(title: "", message: NSLocalizedString("Password field not found", comment:"Password field not found field cannot be empty"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
            alertView.show()
            return isDataValid

        }
        
        if isDataValid == true {
            agentOnboardingModel.sharedInstance.profileModelObj(profileObj)
        }
        return isDataValid
    }
}