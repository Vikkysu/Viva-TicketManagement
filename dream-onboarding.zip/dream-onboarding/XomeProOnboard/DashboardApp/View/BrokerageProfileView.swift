//
//  BrokerageProfileView.swift
//  ProfessionalTools
//
//  Created by BharatMeda on 10/24/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class BrokerageProfileView: NSObject {
    
    var vwController : UIViewController!
    var cgScreenWidth : CGFloat!
    var cgScreenHeight : CGFloat!
    var hdrVwHeight : CGFloat!
    
    var vwMain : UIScrollView = UIScrollView()
    var vwHeader : UIView = UIView()
    var vwOverview : UIView = UIView()
    var segOperationsView : UISegmentedControl = UISegmentedControl()
    var vwLogo : UIView = UIView()
    var vwColor : UIView = UIView()
    var vwAbout : UIView = UIView()
    var lblBrokerageName : UILabel = UILabel()
    var lblBrokerageSubTxt1 : UILabel = UILabel()
    var lblBrokerageSubTxt2 : UILabel = UILabel()
    
    let segMenuItems         = ["Branding", "Brokerage", "Statistics"]
    
    func loadBrokerageProfile(inViewController :UIViewController){
        vwController            = inViewController
        createUIElements()
        setTopLevelViewProperties()
        serHeaderViewProperties()
        setProfileData()
        addElements2UI()
    }
    
    func createUIElements() {
        
        segOperationsView   = UISegmentedControl(items: segMenuItems)
    }
    
    func setTopLevelViewProperties() {
        
        vwMain.backgroundColor     = UIColor.baoWhite55Color()
        vwHeader.backgroundColor   = UIColor.baoHeaderRedColor()
        vwOverview.backgroundColor = UIColor.baoWhiteColor()
        vwLogo.backgroundColor  = UIColor.baoWhiteColor()
        vwColor.backgroundColor = UIColor.baoWhiteColor()
        vwAbout.backgroundColor = UIColor.baoWhiteColor()
        
        //setup segmented menu
        segOperationsView.selectedSegmentIndex  = 0
        segOperationsView.tintColor             = UIColor.baoHeaderRedColor()
        segOperationsView.backgroundColor       = UIColor.baoWhiteColor()
        
        segOperationsView.layer.cornerRadius = 5;
    }
    
    func serHeaderViewProperties() {
        lblBrokerageSubTxt1.textColor = UIColor.baoHeaderRedColor()
    }
    
    func setProfileData() {
        
        lblBrokerageSubTxt1.text = "MEREDITH"
    }
    
    func addElements2UI() {
        
        vwController.view.addSubview(vwMain)
        vwMain.addSubview(vwHeader)
        //vwHeader.addSubview(lblBrokerageSubTxt2);
        
        vwMain.addSubview(vwOverview)
        vwMain.addSubview(segOperationsView)
        vwMain.addSubview(vwLogo)
        vwMain.addSubview(vwColor)
        vwMain.addSubview(vwAbout)
        
        vwMain.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(0.0)
            make.bottom.equalTo(0.0)
            make.leading.equalTo(0.0)
            make.trailing.equalTo(0.0)
        }
        
        vwHeader.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(vwMain).offset(0)
            make.leading.equalTo(vwMain).offset(0)
            make.height.equalTo(65)
            make.width.equalTo(vwMain)
        }
        
        vwOverview.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(vwHeader).offset(65)
            make.height.equalTo(155)
            make.width.equalTo(vwMain)
        }
        
        segOperationsView.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(vwOverview).offset(165)
            make.height.equalTo(30)
            make.leading.equalTo(vwMain).offset(25)
        }
        
        vwLogo.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(segOperationsView).offset(40)
            make.height.equalTo(155)
            make.width.equalTo(vwMain)
        }
        
        vwColor.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(vwLogo).offset(164)
            make.height.equalTo(155)
            make.width.equalTo(vwMain)
        }
        
        vwAbout.snp_makeConstraints { (make) ->Void in
            make.top.equalTo(vwColor).offset(164)
            make.height.equalTo(155)
            make.width.equalTo(vwMain)
        }
        
        vwOverview.addSubview(lblBrokerageSubTxt1);
        lblBrokerageSubTxt1.snp_makeConstraints { (make) -> Void in
            make.leading.equalTo(vwOverview).offset(130)
            make.trailing.equalTo(vwOverview).offset(130)
            make.top.equalTo(vwOverview).offset(20)
            make.bottom.equalTo(vwOverview).offset(103)
        }
    }
}