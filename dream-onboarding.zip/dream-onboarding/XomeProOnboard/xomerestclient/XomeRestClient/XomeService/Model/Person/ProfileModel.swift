//
//  ProfileModel.swift
//  XomeRestClient
//
//  Created by Brendan Farrington on 12/2/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class ProfileModel: Mappable {
    public var contactKey: String?
    public var contactLoginId: String?
    public var email: String?
    public var firstName: String?
    public var middleName: String?
    public var lastName: String?
    public var phoneNumber: String?

    public init() {

    }

    required public init?(_ map: Map) {

    }

    public func mapping(map: Map) {
        contactKey <- map["items.0.contactKey"]
        contactLoginId <- map["items.0.contactLoginId"]
        email <- map["items.0.email"]
        firstName <- map["items.0.firstName"]
        middleName <- map["items.0.middleName"]
        lastName <- map["items.0.lastName"]
        phoneNumber <- map["items.0.mobilePhone"]
    }
}
