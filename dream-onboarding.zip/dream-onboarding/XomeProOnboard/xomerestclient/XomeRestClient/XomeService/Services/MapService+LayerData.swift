//
//  MapService+LayerData.swift
//  XomeRestClient
//
//  Created by David Parton on 3/22/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import Typhoon

public extension XomeServiceAssembly {
    dynamic func mapLayerDataConfig() -> AnyObject {
        return TyphoonDefinition.configDefinitionWithName("MapLayers.config.properties", bundle: NSBundle(forClass: XomeRestClientAssembly.self))
    }

    dynamic func mapLayerData() -> AnyObject {
        return TyphoonDefinition.withClass(MapLayerData.self, configuration: { (definition: TyphoonDefinition!) in
            definition.scope = .LazySingleton

            let typeKeyTuples: [(PropertyMapLayerType, String)] = [
                (.Subdivisions, "Subdivisions"),
                (.Neighborhoods, "Neighborhoods"),
                (.HighSchools, "HighSchools"),
                (.MiddleSchools, "MiddleSchools"),
                (.ElementarySchools, "ElementarySchools"),
                (.ParcelLines, "ParcelLines")
            ]
            typeKeyTuples.forEach { (type, key) in
                let LayerConfig: String -> AnyObject! = { TyphoonConfig(key + "." + $0) }
                definition.injectMethod("layerType:name:sld:minZoom:labelZoom:") {
                    $0.injectParameterWith(type.rawValue)
                    $0.injectParameterWith(LayerConfig("layerName"))
                    $0.injectParameterWith(LayerConfig("sld"))
                    $0.injectParameterWith(LayerConfig("minZoomLevel"))
                    $0.injectParameterWith(LayerConfig("labelZoomLevel"))
                }
            }
        })
    }
}

@objc public class MapLayerData : NSObject {
    struct MapLayerConfig {
        let name: String
        let sld: String
        let minZoom: Int
        let labelZoom: Int

        func toRESTLayerIdentifierWithZoomLevel(zoomLevel: Int) -> String {
            return String(format: "%@%@%@", name,
                zoomLevel >= labelZoom ? "," : "",
                zoomLevel >= labelZoom ? name : "");
        }

        func toRESTStyleIdentifierWithZoomLevel(zoomLevel: Int) -> String {
            return String(format: "%@%@%@",
                    "\(sld)/Default.sld.xml",
                    zoomLevel >= labelZoom ? "," : "",
                    zoomLevel >= labelZoom ? "\(sld)/Labels.sld.xml" : "");
        }
    }

    private lazy var layerInfo: [(PropertyMapLayerType, MapLayerConfig)] = []
    @objc public func layerType(type: PropertyMapLayerType, name: String, sld: String, minZoom: Int, labelZoom: Int) {
        layerInfo.append((type, MapLayerConfig(name: name, sld: sld, minZoom: minZoom, labelZoom: labelZoom)))
    }

    func filter(types: [PropertyMapLayerType], zoomLevel: Int) -> [MapLayerConfig] {
        return layerInfo.filter { types.contains($0.0) && $0.1.minZoom <= zoomLevel }.map { $0.1 }
    }
    
}