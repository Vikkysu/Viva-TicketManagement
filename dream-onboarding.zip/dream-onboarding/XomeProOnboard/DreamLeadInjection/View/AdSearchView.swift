//
//  AdSearchView.swift
//  DreamLeadInjection
//
//  Created by MacMini5 on 23/10/15.
//  Copyright © 2015 Developer. All rights reserved.
//

import UIKit

class AdSearchView: NSObject {

}
