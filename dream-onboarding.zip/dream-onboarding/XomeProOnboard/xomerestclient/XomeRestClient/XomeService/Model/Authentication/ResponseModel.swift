//
//  ResponseModel.swift
//  XomeRestClient
//
//  Created by Brendan Farrington on 2/2/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class ResponseModel: MessageModel {
    public var errors: [ErrorModel]?

    public override func mapping(map: Map) {
        super.mapping(map)
        errors <- map["errors"]
    }
}