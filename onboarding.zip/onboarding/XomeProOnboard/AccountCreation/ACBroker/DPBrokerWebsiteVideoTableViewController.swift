//
//  DPBrokerWebsiteVideoTableViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/15/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrokerWebsiteVideoTableViewController: UITableViewController, UITextFieldDelegate {
    var brokerWebSiteInfo: UITextField!
    var brokerYoutubeInfo: UITextField!
    
    func setDataFields() -> Bool
    {
        let brokerWebsiteInfoObj: DPBrandingWebsiteYoutubeAddrObj = DPBrandingWebsiteYoutubeAddrObj()
        
        if brokerWebSiteInfo.text != "" && brokerWebSiteInfo.text != " " {
            brokerWebsiteInfoObj.websiteAddressStr = brokerWebSiteInfo.text
            brokerWebsiteInfoObj.YoutubeStr = brokerYoutubeInfo.text
            if UtilitiesFunc.isValidURL(brokerWebsiteInfoObj.websiteAddressStr!) == false {
                let alertView: UIAlertView = UIAlertView(title: "", message: "Not an valid Website URL", delegate: nil, cancelButtonTitle: "OK")
                alertView.show()
                return false
            }
            if UtilitiesFunc.isValidURL(brokerWebsiteInfoObj.YoutubeStr!) == false {
                let alertView: UIAlertView = UIAlertView(title: "", message: "Not an valid Video URL", delegate: nil, cancelButtonTitle: "OK")
                alertView.show()
                return false
            }
            brokerWebsiteInfoObj.isSet = true
        }
        else {
            brokerWebsiteInfoObj.isSet = false
            brokerWebsiteInfoObj.websiteAddressStr = " "
            brokerWebsiteInfoObj.YoutubeStr = " "
        }
        

        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            let agentOnboardingInfo: DPAgentOnBoardingModel = DPAgentOnBoardingModel.sharedInstance
            agentOnboardingInfo.BrokerageWebsiteYoutubeModelObj(brokerWebsiteInfoObj)
            agentOnboardingInfo.saveBrokerageBrandingWebsiteYoutubeObject(brokerWebsiteInfoObj)
        }
        else
        {
            let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
            brokerOnboardingInfo.BrokerageWebsiteYoutubeModelObj(brokerWebsiteInfoObj)
            brokerOnboardingInfo.saveBrokerageBrandingWebsiteYoutubeObject(brokerWebsiteInfoObj)
        }
        return true
    }
    
    func fetchWebsiteData () -> String {
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            let agentOnboardingInfo: DPAgentOnBoardingModel = DPAgentOnBoardingModel.sharedInstance
            if let brokerBrandingWebsiteInfo: DPBrandingWebsiteYoutubeAddrObj = agentOnboardingInfo.loadBrokerageBrandingWebsiteYoutubeObjectWithKey() {
                return brokerBrandingWebsiteInfo.websiteAddressStr!
            }
        }
        let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
        var websiteAdd = ""
        if let brokerBrandingWebsiteInfo: DPBrandingWebsiteYoutubeAddrObj = brokerOnboardingInfo.loadBrokerageBrandingWebsiteYoutubeObjectWithKey(
        ){
            websiteAdd = brokerBrandingWebsiteInfo.websiteAddressStr!
        }
        return websiteAdd
    }
    
    func fetchVideoLinkData () -> String {
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            let agentOnboardingInfo: DPAgentOnBoardingModel = DPAgentOnBoardingModel.sharedInstance
            if let brokerBrandingWebsiteInfo: DPBrandingWebsiteYoutubeAddrObj = agentOnboardingInfo.loadBrokerageBrandingWebsiteYoutubeObjectWithKey() {
                
                return brokerBrandingWebsiteInfo.YoutubeStr!
            }
        }
        let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
        var websiteAdd = ""
        if let brokerBrandingWebsiteInfo: DPBrandingWebsiteYoutubeAddrObj = brokerOnboardingInfo.loadBrokerageBrandingWebsiteYoutubeObjectWithKey(
            ){
                websiteAdd = brokerBrandingWebsiteInfo.YoutubeStr!
        }
        return websiteAdd
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        tableView.delegate=self
        tableView.dataSource=self
        tableView.showsHorizontalScrollIndicator=false
        tableView.showsVerticalScrollIndicator=false
        tableView.separatorStyle = .None
        tableView.registerClass(ACBrokerageStep1HeaderCell.self, forCellReuseIdentifier: "reuseIdentifier")
        tableView.registerClass(ACBrokerageTextCell.self, forCellReuseIdentifier: "DPBrandingWSCellIdentiifer")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Tableview delegates
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 3
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 100
        }
        return 80
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        // fill the fields if saved offline
        if(indexPath.row == 0)
        {
            let cell: ACBrokerageStep1HeaderCell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath) as! ACBrokerageStep1HeaderCell
            let label: UILabel? = cell.viewWithTag(34) as? UILabel
            
            label!.text = "Provide Your Website and Video Link"
            
            cell.selectionStyle = .None
            return cell
        }
        
        else if indexPath.row == 1 {
            //DPBrandingBioCell
            let cell: ACBrokerageTextCell = tableView.dequeueReusableCellWithIdentifier("DPBrandingWSCellIdentiifer", forIndexPath: indexPath) as! ACBrokerageTextCell
            
            let label: UILabel = cell.viewWithTag(33) as! UILabel
            label.text = "PERSONAL BROKER WEBSITE"
            
            let textFieldInfo : UITextField? = cell.viewWithTag(32) as? UITextField
            
            brokerWebSiteInfo = textFieldInfo
            brokerWebSiteInfo.keyboardType = .URL
            brokerWebSiteInfo.returnKeyType = .Next
            brokerWebSiteInfo.text = fetchWebsiteData()
            brokerWebSiteInfo.delegate=self
            cell.selectionStyle = .None
            
            return cell
        }
        
        //DPBrandingBioCell
        let cell: ACBrokerageTextCell = tableView.dequeueReusableCellWithIdentifier("DPBrandingWSCellIdentiifer", forIndexPath: indexPath) as! ACBrokerageTextCell
        
        let label: UILabel = cell.viewWithTag(33) as! UILabel
        label.text = "YOU TUBE LINK"
        
        let textFieldInfo : UITextField? = cell.viewWithTag(32) as? UITextField
        
        brokerYoutubeInfo = textFieldInfo
        brokerYoutubeInfo.keyboardType = .URL
        brokerYoutubeInfo.returnKeyType = .Done
        brokerYoutubeInfo.text = fetchVideoLinkData()
        brokerYoutubeInfo.delegate=self
        cell.selectionStyle = .None
        
        return cell
    }
    
    func textFieldDidEndEditing(textField: UITextField) // may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
    {
        textField.resignFirstResponder()
        if !textField.text!.isEmpty {
            let parentViewC : DPBrokerWebsiteViewController =  self.parentViewController as! DPBrokerWebsiteViewController
            parentViewC.createNextbutton(NEXTBUTTON)
        }
        return
    }
    
    func textFieldDidBeginEditing(textField: UITextField) // may be called if forced even if shouldEndEditing returns NO (e.g. view removed from window) or endEditing:YES called
    {
        let parentViewC : DPBrokerWebsiteViewController =  self.parentViewController as! DPBrokerWebsiteViewController
        parentViewC.createNextbutton(NEXTBUTTON)
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool
    {
        if textField == brokerWebSiteInfo {
            brokerYoutubeInfo.becomeFirstResponder()
        }
        textField.resignFirstResponder()
        let parentViewC : DPBrokerWebsiteViewController =  self.parentViewController as! DPBrokerWebsiteViewController
        
        if !textField.text!.isEmpty {
            parentViewC.createNextbutton(NEXTBUTTON)
        }
        else
        {
            parentViewC.createSkipbutton()
            
        }
        return true
    }
    
}