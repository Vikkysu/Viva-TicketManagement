//
//  ImageService.swift
//  XomeRestClient
//
//  Created by David Parton on 1/18/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import PromiseKit
import DreamLogging

@objc public protocol ImageServiceCache: class {
    func put(url: NSURL, image: UIImage)
    func get(url: NSURL) -> UIImage?
}

class DefaultImageCache : NSObject, ImageServiceCache {
    private let container = NSCache()

    func put(url: NSURL, image: UIImage) {
        container.setObject(image, forKey: url.absoluteString)
    }

    func get(url: NSURL) -> UIImage? {
        return container.objectForKey(url.absoluteString) as? UIImage
    }
}

public class ImageService : NSObject {
    public enum ImageServiceError : ErrorType {
        case DataCodingError
    }

    var operationFactory : XomeRestOperationFactory!
    private var cache : ImageServiceCache

    @objc public init(cache: ImageServiceCache) {
        self.cache = cache
    }

    public func hasCachedVersion(url: NSURL) -> Bool {
        return self.cache.get(url) != nil
    }

    public func imageForURL(url: NSURL) -> Promise<UIImage> {
        if hasCachedVersion(url) {
            return Promise(self.cache.get(url)!)
        }

        let promise = operationFactory.promise(.GET, path: url.absoluteString, queryParameters: nil, bodyData: nil) {
            $0.addValue("image/jpeg, image/png, image/gif", forHTTPHeaderField: "Accept")
        }
        return promise
            .then { (data: NSData) -> UIImage in
                guard let image = UIImage(data: data) else {
                    throw ImageServiceError.DataCodingError
                }
                return image
            }.then { (networkImage: UIImage) -> UIImage in
                self.cache.put(url, image: networkImage)
                return networkImage
            }
    }
    
    public func imageForURL(url: NSURL, params: [String: String]) -> Promise<UIImage?> {
        // no image caching for this call, because of params
        
        let promise = operationFactory.promise(.GET, path: url.absoluteString, queryParameters: params, bodyData: nil) {
            $0.addValue("image/jpeg, image/png, image/gif", forHTTPHeaderField: "Accept")
            }
            .recover { (error: ErrorType) -> NSData in
                DRLogWarn("error: \(error) when loading image: \(url.description)")
                return NSData()
        }
        
        return promise.then { (data: NSData) -> UIImage? in
            guard let image = UIImage(data: data) else {
                return nil
            }
            return image
        }.recover { _ -> UIImage? in return nil }
    }
}