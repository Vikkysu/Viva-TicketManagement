//
//  RegisterModel.swift
//  XomeRestClient
//
//  Created by Brendan Farrington on 2/2/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class RegisterModel: LoginModel {
    public var firstName: String?
    public var lastName: String?
    public var savedPropertyNotifyEndPointsEmail: NSNumber = true
    public var savedSearchNotifyEndPointsEmail: NSNumber = true
    public var savedSearchEmailInterval: NSNumber = 1440
    public var clientStatus: String = "Active"
    public var passwordHint: String = "pass"
    public var mobilePhone: String?

    public override func mapping(map: Map) {
        username <- map["email"]
        password <- map["contactPassword"]
        deviceInfo <- map["deviceInfo"]
        firstName <- map["firstName"]
        lastName <- map["lastName"]
        savedPropertyNotifyEndPointsEmail <- map["savedPropertyNotifyEndPointsEmail"]
        savedSearchEmailInterval <- map["savedSearchEmailInterval"]
        savedSearchNotifyEndPointsEmail <- map["savedSearchNotifyEndPointsEmail"]
        clientStatus <- map["clientStatus"]
        passwordHint <- map["passwordHint"]
        mobilePhone <- map["mobilePhone"]
    }
}