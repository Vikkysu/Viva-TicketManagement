import ObjectMapper
import XomeFoundation

public class PropertyFilterModel: NSObject, Mappable {
    public enum Status: Int {
        case Any
        case ForSale
        case Pending
        case Closed
    }

    public enum PropertyType: Int {
        case Any
        case Residential
        case Commercial
        case Land
        case MultiFamily
        case Rental
    }

    public enum DaysOnXome: Int, CustomStringConvertible {
        case Any
        case OneDay
        case ThreeDays
        case Week
        case Month

        // This initializer is *NOT* the same as rawValue. We use ranged looked up to find the nearest match in this case in order to best approximate saved searches that might originate from outside of this application.
        init(daysOnMarket: Int) {
            self = .Any
            if daysOnMarket >= 1 { self = .OneDay }
            if daysOnMarket >= 3 { self = .ThreeDays }
            if daysOnMarket >= 7 { self = .Week }
            if daysOnMarket >= 28 { self = .Month } // we use 31, but we can't guarantee that other apps do.
        }

        static let stringMapping : [DaysOnXome : String] = [
            .Any: "Any",
            .OneDay: "One Day",
            .ThreeDays: "Three Days",
            .Week: "A week",
            .Month: "A month"
        ]

        public init?(string: String) {
            if let (key, _) = DaysOnXome.stringMapping.filter({ $1 == string }).first {
                self = key
            } else {
                return nil
            }
        }

        public var description : String {
            return DaysOnXome.stringMapping[self] ?? "Any"
        }
    }

    public enum OpenHouse: Int, CustomStringConvertible {
        case None
        case InThreeDays
        case InSevenDays
        case InFourteenDays

        // This initializer is *NOT* the same as rawValue. We use ranged looked up to find the nearest match in this case in order to best approximate saved searches that might originate from outside of this application.
        init(openHouseDays: Int) {
            self = .None
            if openHouseDays >= 3 { self = .InThreeDays }
            if openHouseDays >= 7 { self = .InSevenDays }
            if openHouseDays >= 14 { self = .InFourteenDays }
        }

        static let stringMapping : [OpenHouse : String] = [
            .None: "None",
            .InThreeDays: "Within 3 days",
            .InSevenDays: "Within 7 days",
            .InFourteenDays: "Within 14 days",
        ]

        public init?(string: String) {
            if let (key, _) = OpenHouse.stringMapping.filter({ $1 == string }).first {
                self = key
            } else {
                return nil
            }
        }

        public var description : String {
            return OpenHouse.stringMapping[self] ?? "Any"
        }
    }

    public enum ResidentialType: UInt64, CustomStringConvertible {
        case SingleFamily   = 0x000000000000002
        case Condo          = 0x000000000000004
        case Townhouse      = 0x000000000000008
        case Twinhome       = 0x000000000100000
        case Farm           = 0x000000000000800
        case Other          = 0x200018194098030
        public static let AllTypes: [ResidentialType] = [.SingleFamily, .Condo, .Townhouse, .Twinhome, .Farm, .Other]

        public var description: String {
            switch self {
            case .SingleFamily: return "Single Family"
            case .Condo: return "Condo"
            case .Townhouse: return "Townhouse"
            case .Twinhome: return "Twinhome"
            case .Farm: return "Farm"
            case .Other: return "Other"
            }
        }

        public var propertyTypeId: String {
            let outLength = 24
            let hexString = String(self.rawValue, radix: 16).uppercaseString
            let padZeroes = repeated("0", times: outLength - hexString.characters.count).joinWithSeparator("")
            return "0x" + padZeroes + hexString
        }
    }
    public struct ResidentialTypes: OptionSetType, CustomStringConvertible {
        public let rawValue: UInt64
        public init(rawValue: UInt64) { self.rawValue = rawValue }
        public init(_ residentialType: ResidentialType) { self.rawValue = residentialType.rawValue }
        public static func from(propertyTypeIds ids: String?) -> ResidentialTypes? {
            guard let id = ids where id.hasPrefix("0x") else { return nil }
            guard let hexInt = UInt64(id.substringFromIndex(id.startIndex.advancedBy(2)), radix: 16) else { return nil }

            let types = ResidentialType.AllTypes.filter { hexInt & $0.rawValue == $0.rawValue }
            return self.init(rawValue: types.reduce(0) { return $0 | $1.rawValue })
        }


        public static let SingleFamily = ResidentialTypes(.SingleFamily)
        public static let Condo        = ResidentialTypes(.Condo)
        public static let Townhouse    = ResidentialTypes(.Townhouse)
        public static let Twinhome     = ResidentialTypes(.Twinhome)
        public static let Farm         = ResidentialTypes(.Farm)
        public static let Other        = ResidentialTypes(.Other)
        
        public static let HomeTypes: ResidentialTypes = [.SingleFamily, .Condo, .Townhouse, .Twinhome]
        public static let AllTypes: ResidentialTypes  = [.HomeTypes, .Farm, .Other]

        public var asArray: [ResidentialType] {
            return ResidentialType.AllTypes.filter { self.contains(ResidentialTypes($0)) }
        }

        public var description: String {
            let array = asArray
            switch array.count {
            case 0: return ""
            case 1: return array.first!.description
            default: return "\(array.count) selected"
            }
        }

        public var propertyTypeIds: String {
            return asArray.flatMap { $0.propertyTypeId }.joinWithSeparator(",")
        }
    }

    // MARK: - Properties

    public var status: Status = .Any

    public var type: PropertyType = .Any {
        didSet {
            if type != .Residential {
                residentialType = nil
            }
        }
    }

    // non-nil only when type == .Residential
    public var residentialType: ResidentialTypes? = nil {
        didSet {
            if residentialType != nil {
                type = .Residential
            }
        }
    }

    public var minBeds: Int? = 0
    public var minBaths: Int? = 0

    public var minPrice: Int = 0
    public var maxPrice: Int? = nil
    
    public var structureSize: Int? = nil
    public var minLotSize: Int? = nil
    public var maxLotSize: Int? = nil
    
    public var minYearBuilt: Int? = nil
    public var maxYearBuilt: Int? = nil
    
    public var daysOnXome: DaysOnXome = .Any
    public var openHouse: OpenHouse = .None

    public override init() {
        super.init()
        reset()
    }

    public init(criteria c: SavedSearchCriteriaModel) {
        super.init()
        reset()

        type = PropertyType(rawValue: c.listingTypeId ?? type.rawValue) ?? type
        minBeds = c.minBedrooms ?? minBeds
        minBaths = c.minBaths ?? minBaths
        minPrice = c.minPrice ?? minPrice
        maxPrice = c.maxPrice ?? maxPrice
        minLotSize = c.minAcreage?.RoundedInt()
        maxLotSize = c.maxAcreage?.RoundedInt()
        minYearBuilt = c.minYearBuilt
        maxYearBuilt = c.maxYearBuilt
        structureSize = c.minSquareFootage
        if type == .Residential {
            residentialType = .from(propertyTypeIds: c.propertyTypeIds)
        }

        if let daysOnMarket = c.cumulativeDaysOnMarket {
            daysOnXome = DaysOnXome(daysOnMarket: daysOnMarket)
        }
        if let openHouseDays = c.openHouseNextXDays {
            openHouse = OpenHouse(openHouseDays: openHouseDays)
        }
    }

    required public init?(_ map: Map) {

    }

    public func mapping(map: Map) {
        status <- map["status"]
        type <- map["type"]
        residentialType <- map["residentialType"]
        minBeds <- map["minBeds"]
        minBaths <- map["minBaths"]
        minPrice <- map["minPrice"]
        maxPrice <- map["maxPrice"]
        structureSize <- map["structureSize"]
        minLotSize <- map["minLotSize"]
        maxLotSize <- map["maxLotSize"]
        minYearBuilt <- map["minYearBuilt"]
        maxYearBuilt <- map["maxYearBuilt"]
        daysOnXome <- map["daysOnXome"]
        openHouse <- map["openHouse"]
    }

    public func reset() {
        status = .ForSale
        type = .Residential
        residentialType = ResidentialTypes(rawValue: 0)
        minBeds = 0
        minBaths = 0
        minPrice = 0
        maxPrice = nil
        structureSize = nil
        minLotSize = nil
        maxLotSize = nil
        minYearBuilt = nil
        maxYearBuilt = nil
        daysOnXome = .Any
        openHouse = .None
    }


    // MARK: - Computed Properties

    public var singleFamily: Bool {
        guard let type = residentialType else {
            return false
        }
        return type.contains(.SingleFamily)
    }
    
    public var condo: Bool {
        guard let type = residentialType else {
            return false
        }
        return type.contains(.Condo)
    }
    
    public var townhouse: Bool {
        guard let type = residentialType else {
            return false
        }
        return type.contains(.Townhouse)
    }
    
    public var twinhome: Bool {
        guard let type = residentialType else {
            return false
        }
        return type.contains(.Twinhome)
    }
    
    public var farm: Bool {
        guard let type = residentialType else {
            return false
        }
        return type.contains(.Farm)
    }
    
    public var other: Bool {
        guard let type = residentialType else {
            return false
        }
        return type.contains(.Other)
    }
}

extension PropertySearchFilter {
    public convenience init(filterModel: PropertyFilterModel?) {
        
        // status
        // 0 - Listing Transfer
        // 1 - Active
        // 2 - Closed
        // 3 - Expired
        // 4 - Off Market
        // 5 - Pending
        // 6 - Contingent
        // 7 - Fell Through
        // 8 - Zapped
        // 9 - Rented
        // 10 - ActiveContingent
        // 11 - Backup Offers

        let status: String
        switch filterModel?.status {
        case .Any?:
            status = "1,6,10,11,5"
        case .ForSale?:
            status = "1,6,10,11"
        case .Pending?:
            status = "5"
        case .Closed?:
            status = "2"
        default:
            status = "1,6,10,11,5"
        }

        // type
        
        let listingType: String?
        switch filterModel?.type {
        case .Any?:
            listingType = nil
        case .Residential?:
            listingType = "1"
        case .Commercial?:
            listingType = "2"
        case .Land?:
            listingType = "3"
        case .MultiFamily?:
            listingType = "4"
        case .Rental?:
            listingType = "5"
        default:
            listingType = nil
        }
        
        let residentialType: String? = filterModel?.residentialType?.propertyTypeIds
        
        let minBeds = filterModel?.minBeds
        let minBaths = filterModel?.minBaths
        let minPrice = filterModel?.minPrice
        let maxPrice = filterModel?.maxPrice
        
        let minSquareFootage = filterModel?.structureSize
        let minAcreage = filterModel?.minLotSize == 0 ? nil : filterModel?.minLotSize
        let maxAcreage = filterModel?.maxLotSize == 0 ? nil : filterModel?.maxLotSize
        let minYearBuilt = filterModel?.minYearBuilt
        let maxYearBuilt = filterModel?.maxYearBuilt

        let daysOnMarket: Int?
        switch filterModel?.daysOnXome {
        case .Any?:
            daysOnMarket = nil
        case .OneDay?:
            daysOnMarket = 1
        case .ThreeDays?:
            daysOnMarket = 3
        case .Week?:
            daysOnMarket = 7
        case .Month?:
            daysOnMarket = 31
        default:
            daysOnMarket = nil
        }
        
        let openHouseInDays: Int?
        switch filterModel?.openHouse {
        case .None?:
            openHouseInDays = nil
        case .InThreeDays?:
            openHouseInDays = 3
        case .InSevenDays?:
            openHouseInDays = 7
        case .InFourteenDays?:
            openHouseInDays = 14
        default:
            openHouseInDays = nil
        }

        self.init(status: status,
            listingType: listingType,
            minBeds: minBeds,
            minBaths: minBaths,
            minPrice: minPrice,
            maxPrice: maxPrice,
            residentialType: residentialType,
            minSquareFootage: minSquareFootage,
            minAcreage: minAcreage,
            maxAcreage: maxAcreage,
            minYearBuilt: minYearBuilt,
            maxYearBuilt: maxYearBuilt,
            daysOnMarket: daysOnMarket,
            openHouseInDays: openHouseInDays)
    }
}
