//
//  DPAgentAccountCreationWelcomeViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/24/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPAgentAccountCreationWelcomeViewController: UIViewController {
    
    func startCreatingBrokerageAccount(sender: AnyObject) {
        let nextViewController: DPAgentProfileViewController = DPAgentProfileViewController()
        self.navigationItem.backBarButtonItem?.title = " "
        self.navigationController?.pushViewController(nextViewController, animated: true)
    }
    
    func closeView(sender: UIBarButtonItem) {
        self.dismissViewControllerAnimated(true, completion: nil);
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        let viewBackGround: UIView  = UIView()
        viewBackGround.backgroundColor = UIColor.whiteColor()
        self.view.addSubview(viewBackGround)
        
        viewBackGround.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self.view).offset(68)
            make.leading.equalTo(self.view).offset(5)
            make.trailing.equalTo(self.view).offset(-5)
            make.bottom.equalTo(self.view).offset(-50)
        }
        
        let headerSubLbl: UILabel = UILabel()
        headerSubLbl.numberOfLines = 0
        headerSubLbl.textAlignment = .Center
        // Embed in a <span> for font attributes:
        let html = "<html><head><title></title></head><body><p style=\"color: rgb(51, 51, 51); text-align: center; font-family: MuseoSansRounded-100; font-size: 13px; line-height: 20.8px;\"><span style=\"font-family:MuseoSansRounded-100;\">Welcome Jennifer &ndash; Courtney Abbott has Invited You to Try Xome Pro.</span></p><p style=\"color: rgb(51, 51, 51); font-family: MuseoSansRounded-300; font-size: 13px; line-height: 20.8px;\"><span style=\"font-family:MuseoSansRounded-300;\">We are excited to have you here. The next few steps will walk you though creating a brokerage account and your managing broker profile.</span></p><p style=\"color: rgb(51, 51, 51); font-family:MuseoSansRounded-300; font-size: 13px; line-height: 20.8px;\"><span style=\"font-family:MuseoSansRounded-500;\">What you brokerage provided:</span></p><p style=\"color: rgb(51, 51, 51); font-family: MuseoSansRounded-300; font-size: 13px; line-height: 20.8px;\"><span style=\"font-family:MuseoSansRounded-300\">&nbsp;&nbsp; &nbsp;&bull;&nbsp;&nbsp; &nbsp;Brokerage Licenses<br />&nbsp;&nbsp; &nbsp;&bull;&nbsp;&nbsp; &nbsp;Brokerage MLS Memberships<br />&nbsp;&nbsp; &nbsp;&bull;&nbsp;&nbsp; &nbsp;Brokerage MLS IDs</span></p><p style=\"color: rgb(51, 51, 51); font-family: MuseoSansRounded-300; font-size: 13px; line-height: 20.8px;\"><span style=\"font-family:MuseoSansRounded-500;\">What you will need to create your agent profile:</span></p><p style=\"color: rgb(51, 51, 51); font-family: MuseoSansRounded-300; font-size: 13px; line-height: 20.8px;\"><span style=\"font-family:MuseoSansRounded-300;\">&nbsp;&nbsp; &nbsp;&bull;&nbsp;&nbsp; &nbsp;Your Licenses<br />&nbsp;&nbsp; &nbsp;&bull;&nbsp;&nbsp; &nbsp;Your MLS Memberships<br />&nbsp;&nbsp; &nbsp;&bull;&nbsp;&nbsp; &nbsp;Your MLS IDs</span></p></body></html>"
        let attributedString = UtilitiesFunc.convertText(html)
        
        headerSubLbl.attributedText = attributedString
        headerSubLbl.textColor = UIColor(red: 51.0/255.0, green: 51.0/255.0, blue: 51.0/255.0, alpha: 1.0)
        viewBackGround.addSubview(headerSubLbl)
        
        let continueOnBoarding: UIButton = UIButton()
        continueOnBoarding.backgroundColor = UIColor.baoGunmetalColor()
        continueOnBoarding.setTitle("Let’s Start", forState: .Normal)
        continueOnBoarding.titleLabel?.font = UIFont(name: MuseoSansRounded300Font, size: 16.0)
        continueOnBoarding.setTitleColor(UIColor.whiteColor(), forState: .Normal)
        continueOnBoarding.addTarget(self, action: "startCreatingBrokerageAccount:", forControlEvents: .TouchUpInside)
        self.view.addSubview(continueOnBoarding)
        
        headerSubLbl.snp_makeConstraints {(make) ->Void in
            make.centerY.equalTo(viewBackGround).offset(0)
            make.leading.equalTo(viewBackGround).offset(10)
            make.trailing.equalTo(viewBackGround).offset(-10)
        }
        
        continueOnBoarding.snp_makeConstraints {(make) ->Void in
            make.leading.equalTo(self.view).offset(0)
            make.trailing.equalTo(self.view).offset(0)
            make.bottom.equalTo(self.view).offset(0)
            make.height.equalTo(50)
        }
        
        //set navigation options
        // creating next button view
        UINavigationBar.appearance().backgroundColor = UIColor.baoPrimaryColor()
        UINavigationBar.appearance().barTintColor = UIColor.baoPrimaryColor()
        UINavigationBar.appearance().tintColor = UIColor.whiteColor()
        
        let fontStyle : UIFont = UIFont(name: MuseoSansRounded300Font, size: 18.0)!
        
        let titleDict: NSDictionary = [NSForegroundColorAttributeName: UIColor.whiteColor(), NSFontAttributeName: fontStyle]
        
        
        self.navigationItem.title = "Create an Account"
        let backItem = UIBarButtonItem(title: "Cancel", style: .Plain, target: self, action: "closeView:")
        self.navigationItem.leftBarButtonItem = backItem
        
        self.navigationItem.leftBarButtonItem!.setTitleTextAttributes(titleDict as? [String : AnyObject], forState: .Normal)
        self.navigationItem.leftBarButtonItem?.tintColor = UIColor.whiteColor()
        self.view.backgroundColor = UIColor.lightGrayColor()
        self.navigationController?.navigationBar.titleTextAttributes = titleDict as? [String: AnyObject]
        
        
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: .Plain, target: nil, action: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
