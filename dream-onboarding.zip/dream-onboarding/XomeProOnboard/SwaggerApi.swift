//
//  SwaggerApi.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/22/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
let apiKey = "6DCC4066-8571-4B71-90D1-4512A4CE132A"
let domain = "http://10.29.94.42:80/api/v1/Brokerage/"
let stageDomain = "http://10.29.94.42:80/api/v1/"

class SwaggerApi:NSObject {
    struct ApiHeaders {
        static let SWAGGER_BASIC_HDRS = [
            "Content-Type":"application/json",
            "Accept":"application/json"
        ]
    }
    struct ApiEndpoints {
        static let SWAGGER_LOGIN = "http://10.29.94.42:80/api/v1/Login"
    }
}