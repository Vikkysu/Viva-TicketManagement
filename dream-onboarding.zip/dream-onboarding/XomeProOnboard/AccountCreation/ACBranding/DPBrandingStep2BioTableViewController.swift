//
//  DPBrandingStep2BioTableViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/8/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrandingStep2BioTableViewController: UITableViewController, UITextViewDelegate {
    var brokerBioInfo: UITextView!

    func setDataFields() -> Bool
    {
        let brokerBioInfoObj: DPBrandingBioObj = DPBrandingBioObj()

        if let brokerField = brokerBioInfo {
            if brokerField.text != "" && brokerField.text != " " {
                brokerBioInfoObj.bioStr = brokerField.text
                brokerBioInfoObj.isSet = true
            }
            else {
                brokerBioInfoObj.isSet = false
                brokerBioInfoObj.bioStr = " "
            }
        }
        
        // save the data based on the user role
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            let agentOnboardingInfo: DPAgentOnBoardingModel = DPAgentOnBoardingModel.sharedInstance
            agentOnboardingInfo.BrokerBioModelObj(brokerBioInfoObj)
            agentOnboardingInfo.saveBrokerBrandingBioObject(brokerBioInfoObj)
        }
        else
        {
            let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
            let parentViewC : DPBrandingStep2BioViewController =  self.parentViewController as! DPBrandingStep2BioViewController
            let eState: flowState = parentViewC.geteState()
            if eState == flowState.BROKERAGE {
                brokerOnboardingInfo.BrokerageBioModelObj(brokerBioInfoObj)
                brokerOnboardingInfo.saveBrokerageBrandingBioObject(brokerBioInfoObj)
            }
            else
            {
                brokerOnboardingInfo.BrokerBioModelObj(brokerBioInfoObj)
                brokerOnboardingInfo.saveBrokerBrandingBioObject(brokerBioInfoObj)
            }
        }

        return true
    }
    
    
    func fetchBioSavedData() -> String {
        var brokerBioInfo = ""
        if userRoleInfo.getUserRole() == userType.InvitedAgent {
            let brokerOnboardingInfo: DPAgentOnBoardingModel = DPAgentOnBoardingModel.sharedInstance
            if let brokerPersonalInfoInfo: DPBrandingBioObj = brokerOnboardingInfo.loadBrokerBrandingBioObjectWithKey() {
                brokerBioInfo = brokerPersonalInfoInfo.bioStr!
            }
            return brokerBioInfo
        }
        else
        {
            let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
            let parentViewC : DPBrandingStep2BioViewController =  self.parentViewController as! DPBrandingStep2BioViewController
            let eState: flowState = parentViewC.geteState()
            if eState == flowState.BROKERAGE {
                if let brokerPersonalInfoInfo: DPBrandingBioObj = brokerOnboardingInfo.loadBrokerageBrandingBioObjectWithKey() {
                    brokerBioInfo = brokerPersonalInfoInfo.bioStr!
                }
            }
            else {
                if let brokerPersonalInfoInfo: DPBrandingBioObj = brokerOnboardingInfo.loadBrokerBrandingBioObjectWithKey() {
                    brokerBioInfo = brokerPersonalInfoInfo.bioStr!
                }
            }
            
        }
        return brokerBioInfo

    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        tableView.delegate=self
        tableView.dataSource=self
        tableView.showsHorizontalScrollIndicator=false
        tableView.showsVerticalScrollIndicator=false
        tableView.separatorStyle = .None
        tableView.registerClass(ACBrokerageStep1HeaderCell.self, forCellReuseIdentifier: "reuseIdentifier")
        tableView.registerClass(DPBrandingBioCell.self, forCellReuseIdentifier: "DPBrandingBioCellIdentiifer")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Tableview delegates
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 2
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 100
        }
        return tableView.frame.height-100
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        // fill the fields if saved offline
        if(indexPath.row == 0)
        {
            let cell: ACBrokerageStep1HeaderCell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath) as! ACBrokerageStep1HeaderCell
            let label: UILabel? = cell.viewWithTag(34) as? UILabel
            
            label!.text = "Tell Clients More About Yourself."
            
            cell.selectionStyle = .None
            return cell
        }
        
        //DPBrandingBioCell
        let cell: DPBrandingBioCell = tableView.dequeueReusableCellWithIdentifier("DPBrandingBioCellIdentiifer", forIndexPath: indexPath) as! DPBrandingBioCell
        
        let textFieldInfo : UITextView? = cell.viewWithTag(60) as? UITextView

        brokerBioInfo = textFieldInfo
        brokerBioInfo.attributedText = NSAttributedString()
        brokerBioInfo.textColor = UIColor.baoGunmetalColor()
        brokerBioInfo.text = fetchBioSavedData()
        brokerBioInfo.delegate=self
        cell.selectionStyle = .None
        
        return cell
    }
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        if text == "\n" {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    func textViewDidEndEditing(textView: UITextView) {
        let parentViewC : DPBrandingStep2BioViewController =  self.parentViewController as! DPBrandingStep2BioViewController
        if !textView.text.isEmpty {
            parentViewC.createNextbutton(NEXTBUTTON)
        }
        else {
            parentViewC.createSkipbutton()
        }
    }
    
    func textViewDidBeginEditing(textView: UITextView) {
        if textView.text.rangeOfString("Tap here to start writing") != nil{
            textView.attributedText = NSAttributedString()
        }
        textView.textColor = UIColor.baoGunmetalColor()
        let parentViewC : DPBrandingStep2BioViewController =  self.parentViewController as! DPBrandingStep2BioViewController
        parentViewC.createNextbutton(NEXTBUTTON)

    }
}
