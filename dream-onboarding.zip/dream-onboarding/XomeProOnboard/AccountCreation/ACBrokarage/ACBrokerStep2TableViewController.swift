//
//  ACBrokerStep2TableViewController.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/2/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class ACBrokerStep2TableViewController: UITableViewController, UITextFieldDelegate {
    @IBOutlet weak var brokerNameTextField: UITextField!
    @IBOutlet weak var brokerPhoneTextField: UITextField!
    @IBOutlet weak var brokerAddressTextField: UITextField!
    @IBOutlet weak var brokerAddressOptTextField: UITextField?
    @IBOutlet weak var brokerCityTextField: UITextField!
    @IBOutlet weak var brokerStateTextField: UITextField!
    @IBOutlet weak var brokerZipCodeTextField: UITextField!
    
    func setDataFields() -> Bool
    {
        var isValidated: Bool = false
        let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
        let brokerPersonalInfoInfo: DPBrokeragePersonalInfoObj = DPBrokeragePersonalInfoObj()
        
        if brokerNameTextField.text != "" {
            brokerPersonalInfoInfo.brokerageName = brokerNameTextField.text
            isValidated = true
        }
        else
        {
            let alertView = UIAlertView(title: "", message: NSLocalizedString("Please enter Broker Name", comment:"Please enter Broker Name"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
            alertView.show()
            return false
        }
        
        if brokerPhoneTextField.text != "" {
            brokerPersonalInfoInfo.brokeragePhone = brokerPhoneTextField.text
            isValidated = true
        }
        else
        {
            let alertView = UIAlertView(title: "", message: NSLocalizedString("Phone field cannot be empty", comment:"Phone field cannot be empty"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
            alertView.show()
            return false
        }
        
        if brokerAddressTextField.text != "" {
            brokerPersonalInfoInfo.brokerageAddress = brokerAddressTextField.text
            isValidated = true
        }
        else
        {
            let alertView = UIAlertView(title: "", message: NSLocalizedString("Address field cannot be empty", comment:"Address field cannot be empty"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
            alertView.show()
            return false
        }
        
        brokerPersonalInfoInfo.brokerageAddressOpt = brokerAddressOptTextField!.text
        
        if let cityText = brokerCityTextField {
            if cityText.text != "" {
                brokerPersonalInfoInfo.brokerageCity = brokerCityTextField.text
                isValidated = true
            }
            else
            {
                let alertView = UIAlertView(title: "", message: NSLocalizedString("City field cannot be empty", comment:"City field cannot be empty"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
                alertView.show()
                return false
            }
        }
        
        
        if let stateText = brokerStateTextField {
            if stateText.text != "" {
                brokerPersonalInfoInfo.brokerageState = brokerStateTextField.text
                isValidated = true
            }
            else
            {
                let alertView = UIAlertView(title: "", message: NSLocalizedString("State field cannot be empty", comment:"State field cannot be empty"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
                alertView.show()
                return false
            }
        }
        
        
        if let zipCodeText = brokerZipCodeTextField {
            if zipCodeText.text  != "" {
                brokerPersonalInfoInfo.brokerageZipcode = brokerZipCodeTextField.text
                isValidated = true
            }
            else
            {
                let alertView = UIAlertView(title: "", message: NSLocalizedString("Zip Code field cannot be empty", comment:"Zip Code field cannot be empty"), delegate: nil, cancelButtonTitle: NSLocalizedString("Ok", comment: "Ok"))
                alertView.show()
                return false
            }
        }
        
        if isValidated == true {
            brokerOnboardingInfo.brokeragePersonalInfoModelObj (brokerPersonalInfoInfo)
            brokerOnboardingInfo.saveBrokerageCustomObject(brokerPersonalInfoInfo)
        }
        return isValidated
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        tableView.delegate=self
        tableView.dataSource=self
        tableView.showsHorizontalScrollIndicator=false
        tableView.showsVerticalScrollIndicator=false
        tableView.separatorStyle = .None
        tableView.registerClass(ACBrokerageStep1HeaderCell.self, forCellReuseIdentifier: "reuseIdentifier")
        tableView.registerClass(ACBrokerageTextCell.self, forCellReuseIdentifier: "textHeader")
        tableView.registerClass(ACBrokerageCityStateCellView.self, forCellReuseIdentifier: "ACBrokerageCityStateCellView1")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Tableview delegates
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 6
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if indexPath.row == 0 {
            return 100
        }
        else if indexPath.row == 5 {
            return 100
        }
        return 60
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        // fill the fields if saved offline
        let brokerOnboardingInfo: DPBrokerOnBoardingModel = DPBrokerOnBoardingModel.sharedInstance
        
        let brokerObj: DPBrokeragePersonalInfoObj? = brokerOnboardingInfo.loadBrokerageCustomObjectWithKey()

        
        if(indexPath.row == 0)
        {
            let cell: ACBrokerageStep1HeaderCell = tableView.dequeueReusableCellWithIdentifier("reuseIdentifier", forIndexPath: indexPath) as! ACBrokerageStep1HeaderCell
            let label: UILabel? = cell.viewWithTag(34) as? UILabel
            
            label!.text = "Provide Brokerage Information."
            
            cell.selectionStyle = .None
            return cell
        }
        else if indexPath.row == 5 {
            let cellState: ACBrokerageCityStateCellView = tableView.dequeueReusableCellWithIdentifier("ACBrokerageCityStateCellView1", forIndexPath: indexPath) as! ACBrokerageCityStateCellView
            self.brokerCityTextField = cellState.viewWithTag(41) as? UITextField
            self.brokerStateTextField = cellState.viewWithTag(43) as? UITextField
            self.brokerZipCodeTextField = cellState.viewWithTag(45) as? UITextField
            
            self.brokerCityTextField?.delegate=self
            self.brokerStateTextField?.delegate=self
            self.brokerZipCodeTextField?.delegate=self
            self.brokerZipCodeTextField.keyboardType = .NumberPad
            
            if let brokerModelObj = brokerObj {
                self.brokerCityTextField.text = brokerModelObj.brokerageCity
                self.brokerStateTextField.text = brokerModelObj.brokerageState
                self.brokerZipCodeTextField.text = brokerModelObj.brokerageZipcode
            }
            else
            {
                // leave it empty
            }
            
            cellState.selectionStyle = .None
            return cellState
        }
        let cell: ACBrokerageTextCell = tableView.dequeueReusableCellWithIdentifier("textHeader", forIndexPath: indexPath) as! ACBrokerageTextCell
        
        let label: UILabel? = cell.viewWithTag(33) as? UILabel
        let textField : UITextField? = cell.viewWithTag(32) as? UITextField
        textField?.delegate=self
        if indexPath.row == 1 {
            label!.text = "BROKERAGE NAME"
            textField?.keyboardType = .EmailAddress
            self.brokerNameTextField = textField;
            if let brokerModelObj = brokerObj {
                self.brokerNameTextField.text = brokerModelObj.brokerageName
            }
            else
            {
                // leave it empty
            }
        }
        else if indexPath.row == 2 {
            label!.text = "BROKERAGE PHONE NUMBER"
            textField?.keyboardType = .PhonePad
            self.brokerPhoneTextField = textField
            if let brokerModelObj = brokerObj {
                self.brokerPhoneTextField.text = brokerModelObj.brokeragePhone
            }
            else
            {
                // leave it empty
            }
        }
        else if indexPath.row == 3 {
            label!.text = "BROKERAGE ADDRESS 1"
            textField?.keyboardType = .Default
            self.brokerAddressTextField = textField
            if let brokerModelObj = brokerObj {
                self.brokerAddressTextField.text = brokerModelObj.brokerageAddress
            }
            else
            {
                // leave it empty
            }
        }
        else if indexPath.row == 4 {
            label!.text = "BROKERAGE ADDRESS 2 (OPTIONAL)"
            textField?.keyboardType = .Default
            self.brokerAddressOptTextField = textField
            if let brokerModelObj = brokerObj {
                self.brokerAddressOptTextField!.text = brokerModelObj.brokerageAddressOpt
            }
            else
            {
                // leave it empty
            }
        }
        cell.selectionStyle = .None
        return cell
    }
    
    
    //MARK:- custom text field methods
    func endEditingNow(){
        self.view.endEditing(true)
    }
   
    func addKeypadToolBar(textField: UITextField) {
        // Create a button bar for the number pad
        let keyboardDoneButtonView = UIToolbar()
        keyboardDoneButtonView.sizeToFit()
        
        // Setup the buttons to be put in the system.
        let item = UIBarButtonItem(title: "Done", style: UIBarButtonItemStyle.Plain, target: self, action: Selector("endEditingNow") )
        let toolbarButtons = [item]
        
        //Put the buttons into the ToolBar and display the tool bar
        keyboardDoneButtonView.setItems(toolbarButtons, animated: false)
        textField.inputAccessoryView = keyboardDoneButtonView
    }

    
    //MARK: - text field delegates
    func textFieldShouldBeginEditing(textField: UITextField) -> Bool {
        if textField == brokerPhoneTextField {
            addKeypadToolBar(textField)
        }
        else if textField == brokerZipCodeTextField {
            addKeypadToolBar(textField)
        }

        return true
    }
    
    
    func textField(textField: UITextField, shouldChangeCharactersInRange range: NSRange, replacementString string: String) -> Bool {
        if textField == brokerStateTextField {
            let countLen = textField.text!.characters.count + string.characters.count
            if countLen > 2 {
                return false
            }
        }
        else if textField == brokerPhoneTextField {
            let countLen = textField.text!.characters.count + string.characters.count
            if countLen > 13 {
                return false
            }
        }
        else if textField == brokerZipCodeTextField {
            let countLen = textField.text!.characters.count + string.characters.count
            if countLen > 5 {
                return false
            }
        }
        return true
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        if textField == brokerStateTextField {
            brokerStateTextField.text = textField.text?.uppercaseString
            brokerStateTextField.resignFirstResponder()
            brokerZipCodeTextField.becomeFirstResponder()
        }
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool
    {
        if textField == brokerNameTextField {
            brokerNameTextField.resignFirstResponder()
            brokerPhoneTextField.becomeFirstResponder()
        }
        else if textField == brokerPhoneTextField {
            brokerPhoneTextField.resignFirstResponder()
            brokerAddressTextField.becomeFirstResponder()
        }
        else if textField == brokerAddressTextField {
            brokerAddressTextField.resignFirstResponder()
            brokerAddressOptTextField?.becomeFirstResponder()
        }
        else if textField == brokerAddressOptTextField {
            brokerAddressOptTextField?.resignFirstResponder()
            brokerCityTextField.becomeFirstResponder()
        }
        else if textField == brokerCityTextField {
            brokerCityTextField.resignFirstResponder()
            brokerStateTextField.becomeFirstResponder()
        }
        else if textField == brokerStateTextField {
            brokerStateTextField.text = textField.text?.uppercaseString
            brokerStateTextField.resignFirstResponder()
            brokerZipCodeTextField.becomeFirstResponder()
        }
        else if textField == brokerZipCodeTextField {
            brokerZipCodeTextField.resignFirstResponder()
        }
        return true;
    }

}
