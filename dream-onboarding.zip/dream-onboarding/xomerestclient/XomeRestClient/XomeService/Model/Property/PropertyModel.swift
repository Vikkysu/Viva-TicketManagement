//
//  PropertyModel.swift
//  XomeRestClient
//
//  Created by Vikas on 12/17/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import Foundation
import ObjectMapper
import PromiseKit

class XomeBadDateStringTransform: TransformType {
    typealias JSON = String
    typealias Object = NSDate

    let innerTransform = XomeValueFormatters.redDateFormatter()

    func transformFromJSON(value: AnyObject?) -> NSDate? {
        guard let str = value as? JSON  else { return nil }
        return innerTransform.dateFromString(str)
    }
    func transformToJSON(value: NSDate?) -> JSON? {
        guard let value = value else { return nil }
        return innerTransform.stringFromDate(value)
    }
}

public enum PropertyStatus: String {
    case Active, Pending, Contingent, BackupOffers = "Backup Offers", Unknown
}

public enum PropertyType: String {
    case Residential = "Residential"
    case Commercial  = "Commercial"
    case Land        = "Land Lot"
    case MultiFamily = "Residential Income"
    case Rental      = "Rental"
}

public enum PropertyKind: CustomStringConvertible {
    case ForSale, ForRent, Pending, Contingent, BackupOffers, Unknown
    public var description: String {
        switch self {
        case ForSale:       return "For Sale"
        case ForRent:       return "For Rent"
        case Pending:       return "Pending"
        case BackupOffers:  return "Backup Offers"
        case Contingent:    return "Contingent"
        case Unknown:       return "Unknown"
        }
    }
}

public enum PropertyModelError: ErrorType {
    case Unknown, ImageURLNotSet
}

@objc public class PropertyModel: NSObject, Mappable {
    public var id: String
    public var lat: Double
    public var lon: Double

    public var status: PropertyStatus?
    public var price: Double?
    public var address: String?
    public var city: String?
    public var state: String?
    public var zip: String?
    public var office: String?
    public var bedrooms: Double?
    public var bathrooms: Double?
    public var area: Double?
    public var areaUnits: String?
    public var type: PropertyType?
    public var imageUrl: NSURL?
    public var savedPropertyKey: String?
    public var closeDate: String?
    public var modifiedTimeStamp: String?
    public var photos: [PropertyPhotosModel]?

    public var openHouseStartDate: NSDate?
    public var openHouseEndDate: NSDate?
    public var openHouse2StartDate: NSDate?
    public var openHouse2EndDate: NSDate?
    public var hasOpenHouse: Bool {
        return openHouseStartDate != nil || openHouse2StartDate != nil
    }

    public var allPhotoURLs: [NSURL] {
        let optionalUrls = [imageUrl] + (photos?.map { $0.mediaUrl } ?? [])
        return optionalUrls.flatMap { $0 }
    }

    public var kind: PropertyKind {
        switch status {
        case .Pending?: return .Pending
        case .Active?: return type == .Rental ? .ForRent : .ForSale
        case .Contingent?: return .Contingent
        case .BackupOffers?: return .BackupOffers
        default: return .Unknown
        }
    }

    // TODO: This is not technically correct, since a model can exist longer than the key.
    // E.g. Favorites -> Details (unfavorite) -> Back
    public var favorite: Bool { return savedPropertyKey != nil }

    required public init?(_ map: Map) {
        id = map["listingKey"].valueOrFail()
        lat = map["latitude"].valueOrFail()
        lon = map["longitude"].valueOrFail()
        super.init()
        if !map.isValid {
            return nil
        }
    }

    public func mapping(map: Map) {
        id <- map["listingKey"]
        
        status <- (map["standardStatus"], TransformOf<PropertyStatus, String>(
            fromJSON: { PropertyStatus(rawValue: $0!) ?? .Unknown },
            toJSON: { $0!.rawValue }
        ))

        price <- map["listPrice"]
        address <- map["unstructuredAddress"]
        city <- map["city"]
        state <- map["stateOrProvince"]
        zip <- map["postalCode"]
        lat <- map["latitude"]
        lon <- map["longitude"]
        office <- map["listOfficeName"]
        bedrooms <- map["bedroomsTotal"]
        bathrooms <- (map["bathroomsText"], TransformOf<Double, String>(fromJSON: { Double($0!) ?? 0 }, toJSON: { String($0!) ?? "0" }))
        area <- map["buildingAreaTotal"]
        areaUnits <- (map["buildingAreaUnits"], TransformOf<String, String>(fromJSON: { ($0 ?? "SQ FT.").uppercaseString }, toJSON: { ($0 ?? "SQ. FT.").uppercaseString }))
        type <- (map["propertyType"], TransformOf<PropertyType, String>(fromJSON: { PropertyType(rawValue: $0!) }, toJSON: { $0!.rawValue }))
        imageUrl <- (map["imageFilePath"], URLTransform())
        savedPropertyKey <- (map["savedPropertyKey"], TransformOf<String, Int>(
            fromJSON: { $0 == 0 ? nil : "\($0)" },
            toJSON: { Int($0 ?? "0") }))
        closeDate <- map["closeDate"]
        modifiedTimeStamp <- map["modificationTimestamp"]
        photos <- map["photos"]

        // It's entirely possibly that the service is sending back local times which is why it doesn't end in Z.
        let dateTransform = XomeBadDateStringTransform()
        openHouseStartDate <- (map["openHouseStartTimestamp"], dateTransform)
        openHouseEndDate <- (map["openHouseStopTimestamp"], dateTransform)
        openHouse2StartDate <- (map["openHouse2StartTimestamp"], dateTransform)
        openHouse2EndDate <- (map["openHouse2StopTimestamp"], dateTransform)
    }

    public func promisedImaged(fromService service: ImageService) -> Promise<UIImage> {
        guard let url = imageUrl else {
            return Promise(error: PropertyModelError.ImageURLNotSet)
        }
        return service.imageForURL(url)
    }
}
