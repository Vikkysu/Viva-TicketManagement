//
//  XomeRestOperationFactoryDefault.h
//  Xome
//
//  Created by Vikas on 6/26/15.
//  Copyright (c) 2015 Xome. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "XomeRestClient.h"

@interface XomeRestOperationFactoryDefault : NSObject <XomeRestOperationFactory>
@property (nonatomic) id<XomeRestClientServiceEnvironment> environment;
@end
