//
//  XomeRestPagedArrayResult.m
//  Xome
//
//  Created by David Parton on 8/23/15.
//  Copyright (c) 2015 Xome. All rights reserved.
//

#import "XomeRestClient.h"

@implementation XomeRestPagedArrayResult

@end
