//
//  PasscodeEntryView.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/22/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

protocol PasscodeEntryDelegate {
    func passcodeEntered(passcode:String)
}

class PasscodeEntryView: UIView {

    var titleLabel: UILabel!
    var passcodeTextField: UITextField!
    
    var delegate:PasscodeEntryDelegate?
    
}

extension PasscodeEntryView: UITextFieldDelegate {
    func textFieldDidEndEditing(textField: UITextField) {
        guard textField.text != nil && textField.text?.characters.count == 4 else {
            return
        }
        delegate?.passcodeEntered(textField.text!)
    }
    
}
