//
//  DPBrandingInviteTableViewCell.swift
//  ProfessionalTools
//
//  Created by Vikas on 10/20/15.
//  Copyright © 2015 Xome. All rights reserved.
//

import UIKit

class DPBrandingInviteTableViewCell: UITableViewCell {
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String!)
    {
        super.init(style: UITableViewCellStyle.Value1, reuseIdentifier: reuseIdentifier)
        var labelTextBL : UITextView
        labelTextBL = UITextView()
        labelTextBL.tag=60
        labelTextBL.backgroundColor=UIColor.clearColor()
        labelTextBL.font = UIFont(name: MuseoSansRounded300Font, size: 14.0)
        labelTextBL.returnKeyType = UIReturnKeyType.Done
        
        let html = "<html><head><title></title></head><body><font color=\"#C8C8C8\"><h2>Tap here to start entering email addres</h2><br />You can even copy paste bulk email address.<br /></font><br /></body></html>"
        
        let attributedString = UtilitiesFunc.convertText(html)
        
        labelTextBL.attributedText = attributedString
        
        //        labelTextBL.text = "Tell your clients more about your experience and expertise. You may want to highlight:"
        self.addSubview(labelTextBL)
        
        labelTextBL.snp_makeConstraints { (make) -> Void in
            make.top.equalTo(self).offset(5)
            make.leading.equalTo(self).offset(10)
            make.trailing.equalTo(self).offset(-10)
            make.bottom.equalTo(-5)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
