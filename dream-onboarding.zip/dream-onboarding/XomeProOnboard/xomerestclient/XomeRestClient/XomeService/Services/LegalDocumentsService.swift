//
//  LegalDocumentsService.swift
//  XomeRestClient
//
//  Created by Shivakumar Chandramouli on 3/31/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import UIKit
import ObjectMapper
import PromiseKit

public extension XomeService {
    
    public func checkConsent() -> Promise<[LegalConsentDocuments]> {
        
        let path = "UserLegalDisclosure/CheckConsent?docTypes=0&docTypes=1&docTypes=2&docTypes=3"
        return operationFactory.promise(.GET, path: path, queryParameters: nil, bodyData: nil)
    }
 
    public func updateConsent(requestModel: [UpdateConsentRequestModel]) -> Promise<UpdateConsentResponse>{
        
        let path = "UserLegalDisclosure/UpdateConsent"
        guard let postData = Mapper().toJSONString(requestModel)?.dataUsingEncoding(NSUTF8StringEncoding) else {
            return Promise(error: NSError(domain: "JSON Serialization", code: 0, userInfo: [NSLocalizedDescriptionKey:"Failed to serialize UpdateConsentRequestModel"]))
        }
        return operationFactory.promise(.POST, path: path, queryParameters: nil, bodyData: postData)

    }
}
