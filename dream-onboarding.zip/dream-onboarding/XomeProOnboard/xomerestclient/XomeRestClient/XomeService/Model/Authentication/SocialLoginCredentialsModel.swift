//
//  SocialLoginCredentialsModel.swift
//  XomeRestClient
//
//  Created by Brendan Farrington on 3/7/16.
//  Copyright © 2016 Xome. All rights reserved.
//

import Foundation
import ObjectMapper

public class SocialLoginCredentialsModel: Mappable {
    public var id: String?
    public var fullName: String?
    public var email: String?
    public var userName: String?
    public var diplayName: String?
    public var provider: String?
    public var providerType: Int?
    public var token: String?

    public init() {

    }

    required public init?(_ map: Map) {

    }

    public func mapping(map: Map) {
        id <- map["id"]
        fullName <- map["fullName"]
        email <- map["email"]
        userName <- map["userName"]
        diplayName <- map["diplayName"]
        provider <- map["provider"]
        providerType <- map["providerType"]
        token <- map["token"]
    }
}